import { j as jsxRuntimeExports } from "../_libs/react.mjs";
function SectionHeading({ eyebrow, title, sub }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full text-center mb-8 md:mb-12 px-1", children: [
    eyebrow && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] sm:text-xs font-semibold uppercase tracking-[0.25em] sm:tracking-[0.3em] text-secondary mb-2 sm:mb-3", children: eyebrow }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl sm:text-4xl lg:text-5xl font-display text-primary leading-tight", children: title }),
    sub && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 sm:mt-4 text-sm sm:text-base text-muted-foreground max-w-lg mx-auto", children: sub })
  ] });
}
export {
  SectionHeading as S
};
