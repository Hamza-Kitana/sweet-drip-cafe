import { Q as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { Q as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { c as createRouter, a as createRootRouteWithContext, u as useRouter, L as Link, H as HeadContent, S as Scripts, b as createFileRoute, l as lazyRouteComponent, d as useRouterState, O as Outlet, e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { I as redirect } from "../_libs/tanstack__router-core.mjs";
import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { i as initShopSync, u as useShop, a as useCart, b as useAdmin, f as fmt } from "./store-C3jzrryZ.mjs";
import { R as Root, C as Close, P as Portal, a as Content, T as Title, D as Description, O as Overlay } from "../_libs/radix-ui__react-dialog.mjs";
import { c as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { S as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { c as cva } from "../_libs/class-variance-authority.mjs";
import { R as Root$1 } from "../_libs/radix-ui__react-label.mjs";
import { T as Toaster$1, t as toast } from "../_libs/sonner.mjs";
import { S as ShoppingBag, M as Menu, X, a as MapPin, P as Phone, C as Clock, I as Instagram, F as Facebook, L as Lock, b as LoaderCircle, c as Sparkles, d as Minus, e as Plus, T as Trash2 } from "../_libs/lucide-react.mjs";
import { A as AnimatePresence, m as motion } from "../_libs/framer-motion.mjs";
import { o as objectType, s as stringType } from "../_libs/zod.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "node:stream";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "../_libs/zustand.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const appCss = "/assets/styles-DpG5_lBQ.css";
const favicon = "/assets/Sweet_Drip_Logo.-C69f0URr.png";
const CAFE_ADDRESS = "1658 E 53rd St, Chicago, IL 60615";
const CAFE_EMAIL = "admin@sweetdripcafe.com";
const CAFE_HOURS = "10:00 AM – 9:00 PM";
const CAFE_HOURS_FOOTER = `Mon–Sun · ${CAFE_HOURS}`;
const CAFE_HERO_OPENS = "10AM";
const CAFE_MAPS_URL = "https://maps.app.goo.gl/1EB8RsLy8dxLGQ5J9";
const CAFE_MAP_EMBED = "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2972.783956788756!2d-87.5843009!3d41.7997416!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x880e2973fc31e439%3A0xf20e5a87cf07ead2!2s1658%20E%2053rd%20St%2C%20Chicago%2C%20IL%2060615!5e0!3m2!1sen!2sus!4v1749000000000!5m2!1sen!2sus";
const logo = "/assets/Sweet_Drip_Logo.-C69f0URr.png";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}
const Dialog = Root;
const DialogPortal = Portal;
const DialogOverlay = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Overlay,
  {
    ref,
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props
  }
));
DialogOverlay.displayName = Overlay.displayName;
const DialogContent = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogPortal, { children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx(DialogOverlay, {}),
  /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Content,
    {
      ref,
      className: cn(
        "fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Close, { className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Close" })
        ] })
      ]
    }
  )
] }));
DialogContent.displayName = Content.displayName;
const DialogHeader = ({ className, ...props }) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className), ...props });
DialogHeader.displayName = "DialogHeader";
const DialogTitle = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Title,
  {
    ref,
    className: cn("text-lg font-semibold leading-none tracking-tight", className),
    ...props
  }
));
DialogTitle.displayName = Title.displayName;
const DialogDescription = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Description,
  {
    ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props
  }
));
DialogDescription.displayName = Description.displayName;
const Input = reactExports.forwardRef(
  ({ className, type, ...props }, ref) => {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      "input",
      {
        type,
        className: cn(
          "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm",
          className
        ),
        ref,
        ...props
      }
    );
  }
);
Input.displayName = "Input";
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium cursor-pointer transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground shadow hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground shadow-sm hover:bg-destructive/90",
        outline: "border border-input bg-background shadow-sm hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground shadow-sm hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2",
        sm: "h-8 rounded-md px-3 text-xs",
        lg: "h-10 rounded-md px-8",
        icon: "h-9 w-9"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
const Button = reactExports.forwardRef(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Comp, { className: cn(buttonVariants({ variant, size, className })), ref, ...props });
  }
);
Button.displayName = "Button";
const labelVariants = cva(
  "text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
);
const Label = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(Root$1, { ref, className: cn(labelVariants(), className), ...props }));
Label.displayName = Root$1.displayName;
const API_URL = "";
const isApiMode = Boolean(API_URL);
const TOKEN_KEY = "sweetdrip-admin-token";
function setAdminToken(token) {
  if (typeof sessionStorage === "undefined") return;
  if (token) sessionStorage.setItem(TOKEN_KEY, token);
  else sessionStorage.removeItem(TOKEN_KEY);
}
class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.status = status;
    this.body = body;
    this.name = "ApiError";
  }
  status;
  body;
}
async function apiFetch(path, init = {}) {
  throw new ApiError("API URL is not configured", 0);
}
async function fetchCatalog() {
  return apiFetch();
}
async function loginAdmin(username, password) {
  return apiFetch("/api/auth/login", {
    body: JSON.stringify({ username, password })
  });
}
async function updateAdminCredentials(input) {
  return apiFetch("/api/auth/credentials", {
    body: JSON.stringify(input)
  });
}
async function fetchOrders() {
  return apiFetch();
}
async function fetchOrder(id) {
  return apiFetch();
}
async function checkoutOrder(input) {
  return apiFetch("/api/orders/checkout", { body: JSON.stringify(input) });
}
async function confirmOrderPayment(orderId, paymentIntentId) {
  return apiFetch(`/api/orders/${orderId}/confirm-payment`, {
    body: JSON.stringify({ paymentIntentId })
  });
}
async function updateOrderStatusApi(orderId, status) {
  return apiFetch(`/api/orders/${orderId}/status`, {
    body: JSON.stringify({ status })
  });
}
async function submitCatering(input) {
  return apiFetch("/api/catering", {
    body: JSON.stringify(input)
  });
}
async function fetchCatering() {
  return apiFetch();
}
async function updateCateringStatusApi(id, status) {
  return apiFetch(`/api/catering/${id}/status`, {
    body: JSON.stringify({ status })
  });
}
async function saveTaxRate(taxRatePercent) {
  return apiFetch("/api/admin/settings/tax-rate", {
    body: JSON.stringify({ taxRatePercent })
  });
}
async function saveOffersVisible(visible) {
  return apiFetch("/api/admin/settings/offers-visible", {
    body: JSON.stringify({ visible })
  });
}
async function saveHero(hero) {
  return apiFetch("/api/admin/hero", {
    body: JSON.stringify(hero)
  });
}
async function createCategory(category) {
  return apiFetch("/api/admin/categories", {
    body: JSON.stringify(category)
  });
}
async function updateCategory(category) {
  return apiFetch(`/api/admin/categories/${category.id}`, {
    body: JSON.stringify(category)
  });
}
async function deleteCategoryApi(id) {
  return apiFetch(`/api/admin/categories/${id}`, {});
}
async function createProduct(product) {
  return apiFetch("/api/admin/products", {
    body: JSON.stringify(product)
  });
}
async function updateProduct(product) {
  return apiFetch(`/api/admin/products/${product.id}`, {
    body: JSON.stringify(product)
  });
}
async function deleteProductApi(id) {
  return apiFetch(`/api/admin/products/${id}`, {});
}
async function createOffer(offer) {
  return apiFetch("/api/admin/offers", {
    body: JSON.stringify(offer)
  });
}
async function updateOffer(offer) {
  return apiFetch(`/api/admin/offers/${offer.id}`, {
    body: JSON.stringify(offer)
  });
}
async function deleteOfferApi(id) {
  return apiFetch(`/api/admin/offers/${id}`, {});
}
async function hydrateShopFromApi() {
  if (!isApiMode) return;
  const catalog = await fetchCatalog();
  useShop.setState({
    categories: catalog.categories,
    products: catalog.products,
    offers: catalog.offers,
    hero: catalog.hero,
    taxRatePercent: catalog.taxRatePercent,
    offersSectionVisible: catalog.offersSectionVisible
  });
}
async function refreshAdminDataFromApi() {
  if (!isApiMode) return;
  const [orders, catering] = await Promise.all([fetchOrders(), fetchCatering()]);
  useShop.setState({
    orders: orders.map(mapApiOrder),
    largeOrders: catering
  });
}
function mapApiOrder(o) {
  return {
    ...o,
    status: o.status,
    paymentStatus: o.paymentStatus
  };
}
function AdminLoginDialog({ open, onOpenChange }) {
  const { isAdmin, setAdmin, login } = useAdmin();
  const navigate = useNavigate();
  const [u, setU] = reactExports.useState("");
  const [p, setP] = reactExports.useState("");
  const [loading, setLoading] = reactExports.useState(false);
  const signOut = () => {
    setAdminToken(null);
    setAdmin(false);
    toast.success("Signed out");
  };
  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (isApiMode) {
        const result = await loginAdmin(u, p);
        setAdminToken(result.token);
        setAdmin(true);
        await refreshAdminDataFromApi();
        toast.success("Welcome back, Admin");
        onOpenChange(false);
        navigate({ to: "/admin" });
        setU("");
        setP("");
        return;
      }
      if (login(u, p)) {
        toast.success("Welcome back, Admin");
        onOpenChange(false);
        navigate({ to: "/admin" });
        setU("");
        setP("");
      } else {
        toast.error("Invalid credentials");
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Invalid credentials");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "sm:max-w-sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogHeader, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto w-12 h-12 rounded-full gradient-choco flex items-center justify-center text-primary-foreground mb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "w-5 h-5" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogTitle, { className: "text-center", children: "Admin Access" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(DialogDescription, { className: "text-center", children: "Sign in to manage your cafe." })
    ] }),
    isAdmin ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground text-center", children: "You are signed in." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "flex-1", onClick: () => {
          onOpenChange(false);
          navigate({ to: "/admin" });
        }, children: "Open dashboard" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "outline", onClick: signOut, children: "Sign out" })
      ] })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: submit, className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "u", children: "Username" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "u", value: u, onChange: (e) => setU(e.target.value), autoFocus: true })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "p", children: "Password" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "p", type: "password", value: p, onChange: (e) => setP(e.target.value) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", className: "w-full", disabled: loading, children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
        "Signing in…"
      ] }) : "Sign in" })
    ] })
  ] }) });
}
const OFFERS_MENU_FILTER = "offers";
const DEFAULT_OFFER_PRODUCTS = {
  o1: ["p1", "p5", "p3"],
  o2: ["p6", "p7"]
};
function getOfferProductIds(offer) {
  if (offer.productIds?.length) return offer.productIds;
  return DEFAULT_OFFER_PRODUCTS[offer.id] ?? [];
}
function resolveOfferProducts(offer, products) {
  const ids = getOfferProductIds(offer);
  return ids.map((id) => products.find((p) => p.id === id)).filter((p) => Boolean(p));
}
function isOffersMenuFilter(cat) {
  return cat === OFFERS_MENU_FILTER;
}
function isLiveOffer(o) {
  if (!o.active) return false;
  const now = /* @__PURE__ */ new Date();
  if (o.startAt && new Date(o.startAt) > now) return false;
  if (o.endAt && new Date(o.endAt) < now) return false;
  return true;
}
function offerCartProductId(offerId) {
  return `offer:${offerId}`;
}
function isOfferCartItem(productId) {
  return productId.startsWith("offer:");
}
const Sheet = Root;
const SheetClose = Close;
const SheetPortal = Portal;
const SheetOverlay = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Overlay,
  {
    className: cn(
      "fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0",
      className
    ),
    ...props,
    ref
  }
));
SheetOverlay.displayName = Overlay.displayName;
const sheetVariants = cva(
  "fixed z-50 gap-4 bg-background p-6 shadow-lg transition ease-in-out data-[state=closed]:duration-300 data-[state=open]:duration-500 data-[state=open]:animate-in data-[state=closed]:animate-out",
  {
    variants: {
      side: {
        top: "inset-x-0 top-0 border-b data-[state=closed]:slide-out-to-top data-[state=open]:slide-in-from-top",
        bottom: "inset-x-0 bottom-0 border-t data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom",
        left: "inset-y-0 left-0 h-full w-3/4 border-r data-[state=closed]:slide-out-to-left data-[state=open]:slide-in-from-left sm:max-w-sm",
        right: "inset-y-0 right-0 h-full w-3/4 border-l data-[state=closed]:slide-out-to-right data-[state=open]:slide-in-from-right sm:max-w-sm"
      }
    },
    defaultVariants: {
      side: "right"
    }
  }
);
const SheetContent = reactExports.forwardRef(({ side = "right", className, overlayClassName, showOverlay = true, hideClose = false, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(SheetPortal, { children: [
  showOverlay && /* @__PURE__ */ jsxRuntimeExports.jsx(SheetOverlay, { className: overlayClassName }),
  /* @__PURE__ */ jsxRuntimeExports.jsxs(Content, { ref, className: cn(sheetVariants({ side }), className), ...props, children: [
    !hideClose && /* @__PURE__ */ jsxRuntimeExports.jsxs(Close, { className: "absolute right-4 top-4 z-10 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-secondary", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "sr-only", children: "Close" })
    ] }),
    children
  ] })
] }));
SheetContent.displayName = Content.displayName;
const SheetHeader = ({ className, ...props }) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn("flex flex-col space-y-2 text-center sm:text-left", className), ...props });
SheetHeader.displayName = "SheetHeader";
const SheetTitle = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Title,
  {
    ref,
    className: cn("text-lg font-semibold text-foreground", className),
    ...props
  }
));
SheetTitle.displayName = Title.displayName;
const SheetDescription = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Description,
  {
    ref,
    className: cn("text-sm text-muted-foreground", className),
    ...props
  }
));
SheetDescription.displayName = Description.displayName;
function CartDrawer() {
  const { items, setQty, remove, drawerOpen, setDrawerOpen } = useCart();
  const navigate = useNavigate();
  const count = items.reduce((s, i) => s + i.qty, 0);
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const goToCheckout = () => {
    setDrawerOpen(false);
    navigate({ to: "/checkout" });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Sheet, { open: drawerOpen, onOpenChange: setDrawerOpen, modal: false, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    SheetContent,
    {
      side: "right",
      hideClose: true,
      showOverlay: true,
      overlayClassName: "z-[60] pointer-events-none bg-[oklch(0.62_0.12_350/0.28)] backdrop-blur-[3px]",
      onPointerDownOutside: (e) => e.preventDefault(),
      onInteractOutside: (e) => e.preventDefault(),
      className: "z-[70] inset-y-auto bottom-4 right-4 top-[calc(var(--site-header-height)+1rem)] flex h-auto max-h-[calc(100svh-var(--site-header-height)-2rem)] w-[min(calc(100vw-2rem),19rem)] flex-col gap-0 overflow-hidden rounded-3xl border border-[oklch(0.72_0.09_350/0.35)] bg-[oklch(0.99_0.02_350/0.58)] p-0 shadow-[0_16px_48px_oklch(0.55_0.12_350/0.22),0_4px_20px_oklch(0_0_0/0.1)] backdrop-blur-xl sm:right-5",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pointer-events-none absolute inset-0 overflow-hidden", "aria-hidden": true, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-8 top-12 h-28 w-28 rounded-full bg-[oklch(0.84_0.11_350/0.12)] blur-3xl" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -left-6 bottom-24 h-24 w-24 rounded-full bg-[oklch(0.88_0.09_348/0.1)] blur-3xl" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(SheetHeader, { className: "relative z-[2] border-b border-[oklch(0.72_0.09_350/0.2)] px-4 pb-3 pt-5 text-left", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            SheetClose,
            {
              onClick: () => setDrawerOpen(false),
              className: "absolute right-3 top-3 z-10 flex h-7 w-7 items-center justify-center rounded-full border border-[oklch(0.72_0.09_350/0.3)] bg-white/70 text-primary opacity-100 transition hover:bg-white hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring",
              "aria-label": "Close cart",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-3.5 w-3.5" })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2.5 pr-8", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-9 w-9 items-center justify-center rounded-xl bg-[oklch(0.72_0.09_350/0.15)] text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingBag, { className: "h-4 w-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(SheetTitle, { className: "font-display text-xl text-primary", children: "Your cart" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(SheetDescription, { className: "text-xs text-muted-foreground", children: count > 0 ? `${count} sweet item${count === 1 ? "" : "s"} ready to go` : "Add something delicious" })
            ] })
          ] })
        ] }),
        items.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-[1] flex flex-col items-center justify-center px-4 py-10 text-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-[oklch(0.72_0.09_350/0.12)]", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "h-7 w-7 text-primary/70" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-display text-lg text-primary", children: "Your cart is empty" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1.5 text-xs text-muted-foreground", children: "Treat yourself — browse our menu." }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              size: "sm",
              className: "mt-5 rounded-full gradient-choco text-primary-foreground",
              onClick: () => {
                setDrawerOpen(false);
                navigate({ to: "/menu" });
              },
              children: "Browse menu"
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative z-[1] min-h-0 flex-1 space-y-2.5 overflow-y-auto px-4 py-3", children: items.map((it) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "div",
            {
              className: "flex gap-2.5 rounded-xl border border-[oklch(0.72_0.09_350/0.2)] bg-white/45 p-2.5 shadow-soft backdrop-blur-md",
              children: [
                it.image && /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: it.image,
                    alt: it.name,
                    className: "h-14 w-14 shrink-0 rounded-lg object-cover"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start justify-between gap-2", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "truncate text-sm font-semibold text-primary", children: it.name }),
                      isOfferCartItem(it.productId) && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "mt-0.5 inline-block rounded-full bg-accent/25 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-primary", children: "Offer" })
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "shrink-0 text-sm font-semibold text-primary", children: fmt(it.price * it.qty) })
                  ] }),
                  it.noteChoice && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-0.5 text-xs text-muted-foreground", children: [
                    "Option: ",
                    it.noteChoice
                  ] }),
                  it.note && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs italic text-muted-foreground", children: [
                    "“",
                    it.note,
                    "”"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-1 rounded-full border border-[oklch(0.72_0.09_350/0.25)] bg-white/50 p-0.5", children: [
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setQty(it.uid, it.qty - 1),
                          className: "flex h-6 w-6 items-center justify-center rounded-full transition hover:bg-[oklch(0.72_0.09_350/0.12)]",
                          "aria-label": "Decrease quantity",
                          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Minus, { className: "h-3 w-3" })
                        }
                      ),
                      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-4 text-center text-xs font-medium", children: it.qty }),
                      /* @__PURE__ */ jsxRuntimeExports.jsx(
                        "button",
                        {
                          type: "button",
                          onClick: () => setQty(it.uid, it.qty + 1),
                          className: "flex h-6 w-6 items-center justify-center rounded-full transition hover:bg-[oklch(0.72_0.09_350/0.12)]",
                          "aria-label": "Increase quantity",
                          children: /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "h-3 w-3" })
                        }
                      )
                    ] }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx(
                      "button",
                      {
                        type: "button",
                        onClick: () => remove(it.uid),
                        className: "rounded-full p-1.5 text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive",
                        "aria-label": "Remove item",
                        children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3.5 w-3.5" })
                      }
                    )
                  ] })
                ] })
              ]
            },
            it.uid
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-[1] border-t border-[oklch(0.72_0.09_350/0.22)] bg-white/40 px-4 py-4 backdrop-blur-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between font-display text-base text-primary", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Subtotal" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: fmt(subtotal) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 text-[11px] text-muted-foreground", children: "Tip & tax added at checkout." }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button,
              {
                className: "mt-3 w-full rounded-full gradient-choco text-primary-foreground shadow-soft",
                size: "sm",
                onClick: goToCheckout,
                children: "Continue to checkout"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Link,
              {
                to: "/menu",
                onClick: () => setDrawerOpen(false),
                className: "mt-2 block w-full text-center text-xs text-muted-foreground transition hover:text-primary",
                children: "Keep shopping"
              }
            )
          ] })
        ] })
      ]
    }
  ) });
}
function PinkBackgroundAccents() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pointer-events-none fixed inset-0 -z-10 overflow-hidden", "aria-hidden": true, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-20 top-[18%] h-80 w-80 rounded-full bg-[oklch(0.84_0.11_350/0.20)] blur-3xl" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -left-24 top-[38%] h-72 w-72 rounded-full bg-[oklch(0.88_0.09_10/0.16)] blur-3xl" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute right-[12%] bottom-[8%] h-64 w-64 rounded-full bg-[oklch(0.90_0.07_355/0.18)] blur-3xl" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-[35%] top-[72%] h-48 w-48 rounded-full bg-[oklch(0.92_0.05_340/0.14)] blur-2xl" })
  ] });
}
const NAV = [
  { to: "/", label: "Home" },
  { to: "/menu", label: "Menu" },
  { to: "/catering", label: "Catering" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" }
];
function TikTokIcon({ className = "" }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "currentColor", className, "aria-hidden": true, children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M19.5 6.6a5.6 5.6 0 0 1-3.3-1V15a5.7 5.7 0 1 1-5.7-5.7c.3 0 .6 0 .9.1v2.9a2.8 2.8 0 1 0 2 2.7V2h2.8a5.6 5.6 0 0 0 3.3 4.6Z" }) });
}
function PageLoader() {
  const [show, setShow] = reactExports.useState(true);
  reactExports.useEffect(() => {
    const t = setTimeout(() => setShow(false), 1400);
    return () => clearTimeout(t);
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: show && /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 1 },
      exit: { opacity: 0, y: -40 },
      transition: { duration: 0.6 },
      className: "page-loader-bg fixed inset-0 z-[100] flex items-center justify-center overflow-hidden",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pointer-events-none absolute inset-0", "aria-hidden": true, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-16 top-[12%] h-72 w-72 rounded-full bg-[oklch(0.84_0.11_350/0.22)] blur-3xl" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -left-20 bottom-[10%] h-64 w-64 rounded-full bg-[oklch(0.88_0.09_348/0.18)] blur-3xl" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute left-1/2 top-1/2 h-80 w-80 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[oklch(0.9_0.07_355/0.14)] blur-3xl" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          motion.div,
          {
            initial: { scale: 0.6, opacity: 0 },
            animate: { scale: 1, opacity: 1 },
            transition: { duration: 0.7, ease: "easeOut" },
            className: "relative z-[1] flex flex-col items-center gap-6",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                motion.img,
                {
                  src: logo,
                  alt: "Sweet Drip",
                  className: "w-40 sm:w-56 drop-shadow-xl",
                  animate: { y: [0, -8, 0] },
                  transition: { duration: 1.6, repeat: Infinity }
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex gap-1.5", children: [0, 1, 2].map((i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
                motion.span,
                {
                  className: "h-2.5 w-2.5 rounded-full bg-[oklch(0.62_0.12_348)]",
                  animate: { y: [0, -10, 0] },
                  transition: { duration: 0.7, repeat: Infinity, delay: i * 0.15 }
                },
                i
              )) })
            ]
          }
        )
      ]
    }
  ) });
}
function Layout() {
  const items = useCart((s) => s.items);
  const setDrawerOpen = useCart((s) => s.setDrawerOpen);
  const { isAdmin } = useAdmin();
  const headerRef = reactExports.useRef(null);
  const [open, setOpen] = reactExports.useState(false);
  const [adminOpen, setAdminOpen] = reactExports.useState(false);
  const [scrolled, setScrolled] = reactExports.useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const count = items.reduce((s, i) => s + i.qty, 0);
  reactExports.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll);
    document.documentElement.dataset.headerScrolled = window.scrollY > 24 ? "true" : "false";
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  reactExports.useEffect(() => {
    document.documentElement.dataset.headerScrolled = scrolled ? "true" : "false";
  }, [scrolled]);
  reactExports.useEffect(() => {
    const el = headerRef.current;
    if (!el) return;
    const syncHeaderHeight = () => {
      document.documentElement.style.setProperty("--site-header-height", `${el.offsetHeight}px`);
    };
    syncHeaderHeight();
    const ro = new ResizeObserver(syncHeaderHeight);
    ro.observe(el);
    window.addEventListener("resize", syncHeaderHeight);
    window.addEventListener("scroll", syncHeaderHeight, { passive: true });
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", syncHeaderHeight);
      window.removeEventListener("scroll", syncHeaderHeight);
    };
  }, [pathname]);
  reactExports.useEffect(() => {
    setOpen(false);
    window.scrollTo({ top: 0 });
  }, [pathname]);
  reactExports.useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative min-h-screen flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(PinkBackgroundAccents, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(PageLoader, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx("header", { ref: headerRef, className: `fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? "py-2" : "py-3 sm:py-4"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `section-inner transition-all duration-500 ${scrolled ? "glass shadow-soft md:rounded-b-2xl" : "bg-transparent shadow-none backdrop-blur-none"}`,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 sm:gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "flex shrink-0 items-center min-w-0 transition hover:opacity-90", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: logo,
              alt: "Sweet Drip",
              className: `w-auto object-contain transition-all duration-500 ${scrolled ? "h-14 max-w-[200px] sm:h-16 sm:max-w-[240px] md:h-[4.5rem] md:max-w-[280px]" : "h-16 max-w-[220px] sm:h-20 sm:max-w-[300px] md:h-24 md:max-w-[360px] lg:h-28 lg:max-w-[420px]"}`
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "hidden md:flex items-center gap-1", children: NAV.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            Link,
            {
              to: n.to,
              className: "px-4 py-2 rounded-full text-sm font-medium text-foreground/80 hover:text-primary hover:bg-accent/30 transition-colors",
              activeProps: { className: "text-primary bg-accent/40" },
              children: n.label
            },
            n.to
          )) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "button",
              {
                type: "button",
                onClick: () => setDrawerOpen(true),
                className: "relative rounded-full p-2.5 transition hover:bg-accent/40",
                "aria-label": "Open cart",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingBag, { className: "w-5 h-5" }),
                  count > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute -top-1 -right-1 bg-primary text-primary-foreground text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center", children: count })
                ]
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setOpen(true), className: "md:hidden p-2.5 rounded-full hover:bg-accent/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Menu, { className: "w-5 h-5" }) })
          ] })
        ] })
      }
    ) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AnimatePresence, { children: open && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.button,
        {
          type: "button",
          initial: { opacity: 0 },
          animate: { opacity: 1 },
          exit: { opacity: 0 },
          "aria-label": "Close menu",
          className: "fixed inset-0 z-[55] bg-black/50 md:hidden",
          onClick: () => setOpen(false)
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: { x: "100%" },
          animate: { x: 0 },
          exit: { x: "100%" },
          transition: { type: "spring", damping: 26 },
          className: "fixed inset-y-0 right-0 z-[60] w-[min(100%,20rem)] bg-card shadow-glow p-6 pt-[max(1.5rem,env(safe-area-inset-top))] flex flex-col gap-1 md:hidden",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setOpen(false), className: "self-end p-2 -mr-2", "aria-label": "Close", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, {}) }),
            NAV.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              Link,
              {
                to: n.to,
                className: "py-3.5 px-4 rounded-xl hover:bg-accent/30 text-lg font-medium",
                onClick: () => setOpen(false),
                children: n.label
              },
              n.to
            ))
          ]
        }
      )
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("main", { className: `flex-1 ${pathname === "/" ? "pt-0" : "pt-[5.5rem] sm:pt-28 lg:pt-32"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Outlet, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("footer", { className: "site-footer relative mt-auto overflow-hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-1 w-full gradient-gold", "aria-hidden": true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_80%_60%_at_50%_-20%,oklch(0.88_0.08_355/0.28),transparent)]",
          "aria-hidden": true
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_50%_40%_at_100%_50%,oklch(0.78_0.1_10/0.16),transparent)]",
          "aria-hidden": true
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner relative py-14 md:py-16 lg:py-20", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-start gap-10 lg:grid-cols-4 lg:gap-x-10 lg:gap-y-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-col items-center text-center lg:items-start lg:text-left", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "inline-block transition hover:opacity-90", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: logo,
            alt: "Sweet Drip",
            className: "h-24 w-auto drop-shadow-md md:h-32 lg:h-36"
          }
        ) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-10 sm:grid-cols-3 lg:col-span-3 lg:gap-8", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center text-center sm:items-start sm:text-left", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "footer-heading", children: "Visit" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "w-full space-y-3 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "a",
                {
                  href: CAFE_MAPS_URL,
                  target: "_blank",
                  rel: "noreferrer",
                  className: "footer-link flex items-start gap-3 text-left",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "footer-icon-box", children: /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-4 w-4" }) }),
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "min-w-0 pt-1.5 leading-snug", children: CAFE_ADDRESS })
                  ]
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: "tel:+17739664332", className: "footer-link flex items-center gap-3 text-left", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "footer-icon-box", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "h-4 w-4" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "min-w-0 leading-snug", children: "+1 (773) 966-4332" })
              ] }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "footer-link flex items-center gap-3 text-left", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "footer-icon-box", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-4 w-4" }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "min-w-0 leading-snug", children: CAFE_HOURS_FOOTER })
              ] }) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center text-center sm:items-start sm:text-left", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "footer-heading", children: "Explore" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "w-full space-y-2.5 text-sm", children: NAV.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: n.to, className: "footer-link inline-block transition hover:translate-x-0.5", children: n.label }) }, n.to)) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center text-center sm:items-start sm:text-left", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "footer-heading", children: "Legal" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "w-full space-y-2.5 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/privacy", className: "footer-link inline-block transition hover:translate-x-0.5", children: "Privacy Policy" }) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/terms", className: "footer-link inline-block transition hover:translate-x-0.5", children: "Terms & Conditions" }) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6 flex items-center justify-center gap-2 sm:justify-start", children: [
              { href: "https://www.instagram.com/sweetdrip_desserts/", label: "Instagram", Icon: Instagram },
              { href: "https://www.facebook.com/profile.php?id=61557068464580", label: "Facebook", Icon: Facebook },
              { href: "https://www.tiktok.com/@sweet.drip.cafe", label: "TikTok", Icon: TikTokIcon }
            ].map(({ href, label, Icon }) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "a",
              {
                href,
                target: "_blank",
                rel: "noreferrer",
                "aria-label": label,
                className: "flex h-10 w-10 items-center justify-center rounded-full border border-[oklch(0.32_0.08_40/0.2)] bg-[oklch(0.32_0.08_40/0.08)] text-[var(--footer-fg)] transition hover:border-[oklch(0.32_0.08_40/0.4)] hover:bg-[oklch(0.32_0.08_40/0.18)] hover:text-[var(--footer-heading)]",
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-4 w-4" })
              },
              href
            )) })
          ] })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "site-footer-bar", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner relative flex flex-col items-center gap-3 py-5 sm:min-h-[3.25rem] sm:justify-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "w-full text-center text-xs text-white/95", children: [
          "© ",
          (/* @__PURE__ */ new Date()).getFullYear(),
          " Sweet Drip Dessert Cafe. All rights reserved."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            type: "button",
            onClick: () => setAdminOpen(true),
            className: "inline-flex items-center gap-1.5 rounded-full border border-[oklch(0.32_0.08_40/0.2)] px-3 py-1.5 text-xs text-[var(--footer-muted)] transition hover:border-[oklch(0.32_0.08_40/0.35)] hover:text-[var(--footer-fg)] sm:absolute sm:right-0 sm:top-1/2 sm:-translate-y-1/2",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "h-3 w-3" }),
              " ",
              isAdmin ? "Admin" : "Staff"
            ]
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(AdminLoginDialog, { open: adminOpen, onOpenChange: setAdminOpen }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CartDrawer, {})
  ] });
}
const Toaster = ({ ...props }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Toaster$1,
    {
      className: "toaster group",
      toastOptions: {
        classNames: {
          toast: "group toast group-[.toaster]:bg-background group-[.toaster]:text-foreground group-[.toaster]:border-border group-[.toaster]:shadow-lg",
          description: "group-[.toast]:text-muted-foreground",
          actionButton: "group-[.toast]:bg-primary group-[.toast]:text-primary-foreground",
          cancelButton: "group-[.toast]:bg-muted group-[.toast]:text-muted-foreground"
        }
      },
      ...props
    }
  );
};
const SITE_DOMAIN = "sweetdrip.cafe";
const SITE_URL = `https://${SITE_DOMAIN}`;
function NotFoundComponent() {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-7xl font-bold text-foreground", children: "404" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mt-4 text-xl font-semibold text-foreground", children: "Page not found" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "The page you're looking for doesn't exist or has been moved." }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-6", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Link,
      {
        to: "/",
        className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
        children: "Go home"
      }
    ) })
  ] }) });
}
function ErrorComponent({ error, reset }) {
  console.error(error);
  const router2 = useRouter();
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex min-h-screen items-center justify-center bg-background px-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-md text-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-xl font-semibold tracking-tight text-foreground", children: "This page didn't load" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm text-muted-foreground", children: "Something went wrong on our end. You can try refreshing or head back home." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap justify-center gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => {
            router2.invalidate();
            reset();
          },
          className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
          children: "Try again"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "a",
        {
          href: "/",
          className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
          children: "Go home"
        }
      )
    ] })
  ] }) });
}
const Route$e = createRootRouteWithContext()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Sweet Drip Dessert Cafe — Chicago" },
      { name: "description", content: "Sweet Drip Dessert Cafe in Chicago — premium cakes, ice cream, drinks and pastries." },
      { name: "author", content: "Sweet Drip" },
      { property: "og:title", content: "Sweet Drip Dessert Cafe" },
      { property: "og:description", content: "Where every bite is a sweet escape." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: SITE_URL },
      { name: "twitter:card", content: "summary" }
    ],
    links: [
      { rel: "icon", href: favicon, type: "image/png" },
      { rel: "apple-touch-icon", href: favicon },
      {
        rel: "stylesheet",
        href: appCss
      },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Playfair+Display:wght@500;700&family=Dancing+Script:wght@600;700&family=Inter:wght@400;500;600;700&display=swap" }
    ]
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent
});
function RootShell({ children }) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("html", { lang: "en", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("head", { children: /* @__PURE__ */ jsxRuntimeExports.jsx(HeadContent, {}) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("body", { children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Scripts, {})
    ] })
  ] });
}
function RootComponent() {
  const { queryClient } = Route$e.useRouteContext();
  reactExports.useEffect(() => {
    initShopSync();
    if (isApiMode) void hydrateShopFromApi();
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(QueryClientProvider, { client: queryClient, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Layout, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Toaster, { richColors: true, position: "top-center" })
  ] });
}
const $$splitComponentImporter$c = () => import("./terms-Dl2O2_eZ.mjs");
const Route$d = createFileRoute("/terms")({
  head: () => ({
    meta: [{
      title: "Terms & Conditions — Sweet Drip"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$c, "component")
});
const $$splitComponentImporter$b = () => import("./privacy-C4n9_7z1.mjs");
const Route$c = createFileRoute("/privacy")({
  head: () => ({
    meta: [{
      title: "Privacy Policy — Sweet Drip"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$b, "component")
});
function isCategoryVisible(c) {
  return c.visible !== false;
}
function visibleCategories(categories) {
  return categories.filter(isCategoryVisible);
}
function isOffersSectionVisible(visible) {
  return visible !== false;
}
const Route$b = createFileRoute("/offers")({
  beforeLoad: () => {
    const { offersSectionVisible } = useShop.getState();
    throw redirect({
      to: "/menu",
      search: isOffersSectionVisible(offersSectionVisible) ? { cat: OFFERS_MENU_FILTER } : {}
    });
  }
});
const $$splitComponentImporter$a = () => import("./menu-NSj3Kvj0.mjs");
const searchSchema = objectType({
  cat: stringType().optional()
});
const Route$a = createFileRoute("/menu")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [{
      title: "Menu — Sweet Drip"
    }, {
      name: "description",
      content: "Browse our full dessert menu."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$a, "component")
});
const $$splitComponentImporter$9 = () => import("./invoice-C8bJQpaw.mjs");
const Route$9 = createFileRoute("/invoice")({
  head: () => ({
    meta: [{
      title: "Your Invoice — Sweet Drip"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$9, "component")
});
const $$splitComponentImporter$8 = () => import("./contact-BVzaA-Ef.mjs");
const Route$8 = createFileRoute("/contact")({
  head: () => ({
    meta: [{
      title: "Contact — Sweet Drip"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
const $$splitComponentImporter$7 = () => import("./checkout-0RLPLQqF.mjs");
const Route$7 = createFileRoute("/checkout")({
  head: () => ({
    meta: [{
      title: "Checkout — Sweet Drip"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
const $$splitComponentImporter$6 = () => import("./catering-BqyKyAEv.mjs");
const Route$6 = createFileRoute("/catering")({
  head: () => ({
    meta: [{
      title: "Catering — Sweet Drip"
    }, {
      name: "description",
      content: "Request catering and large dessert orders for your event."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
const $$splitComponentImporter$5 = () => import("./cart-BUXhFzaV.mjs");
const Route$5 = createFileRoute("/cart")({
  head: () => ({
    meta: [{
      title: "Your Cart — Sweet Drip"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
const $$splitComponentImporter$4 = () => import("./admin-BEGZsj33.mjs");
const Route$4 = createFileRoute("/admin")({
  head: () => ({
    meta: [{
      title: "Admin · Sweet Drip"
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
const $$splitComponentImporter$3 = () => import("./about-Dky0D_61.mjs");
const Route$3 = createFileRoute("/about")({
  head: () => ({
    meta: [{
      title: "About — Sweet Drip"
    }, {
      name: "description",
      content: "Our story, our values, and the Hyde Park cafe behind every sweet bite."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
const $$splitComponentImporter$2 = () => import("./index-Byqbq3lm.mjs");
const Route$2 = createFileRoute("/")({
  head: () => ({
    meta: [{
      title: "Sweet Drip Dessert Cafe — Chicago"
    }, {
      name: "description",
      content: "Premium desserts, ice cream and drinks in Chicago."
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
const $$splitNotFoundComponentImporter = () => import("./product._id-ChQ5A0Z4.mjs");
const $$splitComponentImporter$1 = () => import("./product._id-BZLHPPJ8.mjs");
const Route$1 = createFileRoute("/product/$id")({
  component: lazyRouteComponent($$splitComponentImporter$1, "component"),
  notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent")
});
const $$splitComponentImporter = () => import("./offer._id-BJr3rK79.mjs");
const Route = createFileRoute("/offer/$id")({
  head: ({
    params
  }) => ({
    meta: [{
      title: `Offer — Sweet Drip`
    }]
  }),
  component: lazyRouteComponent($$splitComponentImporter, "component")
});
const TermsRoute = Route$d.update({
  id: "/terms",
  path: "/terms",
  getParentRoute: () => Route$e
});
const PrivacyRoute = Route$c.update({
  id: "/privacy",
  path: "/privacy",
  getParentRoute: () => Route$e
});
const OffersRoute = Route$b.update({
  id: "/offers",
  path: "/offers",
  getParentRoute: () => Route$e
});
const MenuRoute = Route$a.update({
  id: "/menu",
  path: "/menu",
  getParentRoute: () => Route$e
});
const InvoiceRoute = Route$9.update({
  id: "/invoice",
  path: "/invoice",
  getParentRoute: () => Route$e
});
const ContactRoute = Route$8.update({
  id: "/contact",
  path: "/contact",
  getParentRoute: () => Route$e
});
const CheckoutRoute = Route$7.update({
  id: "/checkout",
  path: "/checkout",
  getParentRoute: () => Route$e
});
const CateringRoute = Route$6.update({
  id: "/catering",
  path: "/catering",
  getParentRoute: () => Route$e
});
const CartRoute = Route$5.update({
  id: "/cart",
  path: "/cart",
  getParentRoute: () => Route$e
});
const AdminRoute = Route$4.update({
  id: "/admin",
  path: "/admin",
  getParentRoute: () => Route$e
});
const AboutRoute = Route$3.update({
  id: "/about",
  path: "/about",
  getParentRoute: () => Route$e
});
const IndexRoute = Route$2.update({
  id: "/",
  path: "/",
  getParentRoute: () => Route$e
});
const ProductIdRoute = Route$1.update({
  id: "/product/$id",
  path: "/product/$id",
  getParentRoute: () => Route$e
});
const OfferIdRoute = Route.update({
  id: "/offer/$id",
  path: "/offer/$id",
  getParentRoute: () => Route$e
});
const rootRouteChildren = {
  IndexRoute,
  AboutRoute,
  AdminRoute,
  CartRoute,
  CateringRoute,
  CheckoutRoute,
  ContactRoute,
  InvoiceRoute,
  MenuRoute,
  OffersRoute,
  PrivacyRoute,
  TermsRoute,
  OfferIdRoute,
  ProductIdRoute
};
const routeTree = Route$e._addFileChildren(rootRouteChildren)._addFileTypes();
const getRouter = () => {
  const queryClient = new QueryClient();
  const router2 = createRouter({
    routeTree,
    context: { queryClient },
    scrollRestoration: true,
    defaultPreloadStaleTime: 0
  });
  return router2;
};
const router = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  getRouter
}, Symbol.toStringTag, { value: "Module" }));
export {
  saveHero as A,
  Button as B,
  CAFE_EMAIL as C,
  setAdminToken as D,
  isCategoryVisible as E,
  updateAdminCredentials as F,
  Dialog as G,
  DialogContent as H,
  Input as I,
  DialogHeader as J,
  DialogTitle as K,
  Label as L,
  logo as M,
  CAFE_MAPS_URL as N,
  OFFERS_MENU_FILTER as O,
  CAFE_ADDRESS as P,
  CAFE_HOURS_FOOTER as Q,
  Route$a as R,
  CAFE_HERO_OPENS as S,
  offerCartProductId as T,
  CAFE_MAP_EMBED as U,
  resolveOfferProducts as V,
  router as W,
  isOffersMenuFilter as a,
  isOffersSectionVisible as b,
  isApiMode as c,
  CAFE_HOURS as d,
  cn as e,
  fetchOrder as f,
  checkoutOrder as g,
  confirmOrderPayment as h,
  isLiveOffer as i,
  updateCateringStatusApi as j,
  updateCategory as k,
  hydrateShopFromApi as l,
  deleteCategoryApi as m,
  deleteProductApi as n,
  updateProduct as o,
  createProduct as p,
  saveOffersVisible as q,
  refreshAdminDataFromApi as r,
  submitCatering as s,
  updateOffer as t,
  updateOrderStatusApi as u,
  visibleCategories as v,
  deleteOfferApi as w,
  createOffer as x,
  saveTaxRate as y,
  createCategory as z
};
