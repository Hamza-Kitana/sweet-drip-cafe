import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useShop, h as activeBackgroundSlides, j as heroDessert, k as float1, l as float2, m as float3, o as aboutCafe } from "./store-C3jzrryZ.mjs";
import { v as visibleCategories, i as isLiveOffer, b as isOffersSectionVisible, O as OFFERS_MENU_FILTER, d as CAFE_HOURS, Q as CAFE_HOURS_FOOTER, S as CAFE_HERO_OPENS } from "./router-CypnlrKc.mjs";
import { M as MapLocationBox } from "./MapLocationBox-BWvUIGZ5.mjs";
import { O as OfferCard } from "./OfferCard-wJkNCRWl.mjs";
import { P as ProductCard } from "./ProductCard-BalCHwJH.mjs";
import { S as SectionHeading } from "./SectionHeading-C_mqZXgB.mjs";
import "../_libs/sonner.mjs";
import { m as motion, u as useScroll, a as useTransform } from "../_libs/framer-motion.mjs";
import { a as MapPin, P as Phone, C as Clock, N as Award, c as Sparkles, Y as ChefHat, G as Heart, D as ArrowRight, Q as Cake, W as Coffee, _ as Cookie, V as IceCreamCone, $ as Cherry, a0 as Croissant, a1 as Candy, a2 as CupSoda, a3 as Milk } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/zod.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const MOBILE_BREAKPOINT = 768;
function useIsMobile() {
  const [isMobile, setIsMobile] = reactExports.useState(void 0);
  reactExports.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };
    mql.addEventListener("change", onChange);
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    return () => mql.removeEventListener("change", onChange);
  }, []);
  return !!isMobile;
}
const FALLBACK_SLIDES = [
  { image: heroDessert, caption: "" },
  { image: aboutCafe, caption: "" },
  {
    image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=1400&q=80",
    caption: ""
  },
  {
    image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=1400&q=80",
    caption: ""
  },
  {
    image: "https://images.unsplash.com/photo-1488900128323-21503983a07e?w=1400&q=80",
    caption: ""
  }
];
function HeroRotatingBackground({
  slides,
  intervalMs = 5500
}) {
  const resolved = reactExports.useMemo(() => {
    const custom = (slides ?? []).filter((s) => s.image);
    if (custom.length > 0) return custom.slice(0, 5);
    return FALLBACK_SLIDES.slice(0, 5);
  }, [slides]);
  const [index, setIndex] = reactExports.useState(0);
  const [reduceMotion, setReduceMotion] = reactExports.useState(false);
  reactExports.useEffect(() => {
    setReduceMotion(window.matchMedia("(prefers-reduced-motion: reduce)").matches);
  }, []);
  reactExports.useEffect(() => {
    if (reduceMotion || resolved.length <= 1) return;
    const timer = window.setInterval(
      () => setIndex((i) => (i + 1) % resolved.length),
      intervalMs
    );
    return () => window.clearInterval(timer);
  }, [resolved.length, intervalMs, reduceMotion]);
  const active = reduceMotion ? 0 : index;
  const activeCaption = resolved[active]?.caption?.trim();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pointer-events-none absolute inset-0 overflow-hidden", "aria-hidden": true, children: [
    resolved.map((slide, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      motion.div,
      {
        className: "absolute inset-0",
        initial: false,
        animate: {
          opacity: i === active ? 1 : 0,
          scale: i === active ? 1.04 : 1.1
        },
        transition: { duration: 1.8, ease: [0.4, 0, 0.2, 1] },
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "img",
          {
            src: slide.image,
            alt: "",
            className: "h-full w-full object-cover",
            loading: i === 0 ? "eager" : "lazy"
          }
        )
      },
      `${i}-${slide.image.slice(0, 32)}`
    )),
    activeCaption ? /* @__PURE__ */ jsxRuntimeExports.jsx(
      motion.div,
      {
        initial: { opacity: 0, y: 12 },
        animate: { opacity: 1, y: 0 },
        transition: { duration: 0.8 },
        className: "absolute bottom-16 left-1/2 z-[1] max-w-lg -translate-x-1/2 px-6 text-center md:bottom-24",
        children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rounded-2xl glass border px-5 py-3 font-display text-lg text-primary shadow-soft md:text-2xl", children: activeCaption })
      },
      activeCaption
    ) : null,
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overlay-pink-hero-vertical absolute inset-0" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overlay-pink-hero-side absolute inset-0" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overlay-pink-hero-tint absolute inset-0 mix-blend-multiply" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_30%_20%,oklch(0.92_0.06_350/0.32),transparent_55%)]" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_88%_12%,oklch(0.84_0.11_350/0.28),transparent_42%)]" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_8%_78%,oklch(0.88_0.09_348/0.22),transparent_38%)]" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 bg-[radial-gradient(ellipse_at_50%_100%,oklch(0.9_0.07_355/0.2),transparent_45%)]" })
  ] });
}
function Hero3D() {
  const ref = reactExports.useRef(null);
  const { hero, offersSectionVisible } = useShop();
  const bgSlides = reactExports.useMemo(
    () => activeBackgroundSlides(hero.backgroundSlides),
    [hero.backgroundSlides]
  );
  const floats = hero.floatingImages ?? [];
  const badge = hero.heroBadge || "Dessert Cafe · Chicago";
  const titleBefore = hero.heroTitleBefore || "Sweet";
  const titleAccent = hero.heroTitleAccent || "Drip";
  const titleAfter = hero.heroTitleAfter || "Every Day.";
  const isMobile = useIsMobile();
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 600], [0, isMobile ? 0 : -150]);
  const y2 = useTransform(scrollY, [0, 600], [0, isMobile ? 0 : 120]);
  const y3 = useTransform(scrollY, [0, 600], [0, isMobile ? 0 : -80]);
  const rotateMain = useTransform(scrollY, [0, 600], [0, isMobile ? 0 : 12]);
  const scaleMain = useTransform(scrollY, [0, 600], [1, isMobile ? 1 : 0.9]);
  const heroOpacity = useTransform(scrollY, [0, 500], [1, isMobile ? 1 : 0.35]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { ref, className: "relative overflow-hidden md:min-h-[100svh]", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(HeroRotatingBackground, { slides: bgSlides }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute inset-0 z-[1] hidden md:block", children: Array.from({ length: 14 }).map((_, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "span",
      {
        className: "absolute -top-10 w-2 h-6 rounded-b-full bg-primary/60 blur-[0.5px]",
        style: {
          left: `${(i * 7 + 4) % 100}%`,
          animation: `drip ${4 + i % 5}s linear ${i * 0.4}s infinite`
        }
      },
      i
    )) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-[2] section-inner pt-24 pb-10 md:hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: { opacity: 0, y: 24 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.7, delay: 0.3 },
          className: "text-center",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-primary text-[10px] font-semibold uppercase tracking-widest", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3 h-3" }),
              " ",
              badge
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "mt-4 text-[2.35rem] leading-[1.05] font-display text-primary", children: [
              titleBefore,
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: titleAccent }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              titleAfter
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 text-base text-muted-foreground mx-auto max-w-sm", children: hero.tagline })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        motion.div,
        {
          initial: { opacity: 0, scale: 0.92 },
          animate: { opacity: 1, scale: 1 },
          transition: { duration: 0.8, delay: 0.5 },
          className: "relative mx-auto mt-4 h-[min(58vw,280px)] max-w-sm",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "img",
            {
              src: hero.image || heroDessert,
              alt: "Signature dessert",
              className: "h-full w-full object-contain drop-shadow-2xl"
            }
          )
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-col gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: "/menu",
            className: "inline-flex w-full items-center justify-center gap-2 rounded-full gradient-choco px-6 py-3.5 text-sm font-medium text-primary-foreground shadow-glow",
            children: [
              "Explore Menu ",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
            ]
          }
        ),
        isOffersSectionVisible(offersSectionVisible) && /* @__PURE__ */ jsxRuntimeExports.jsx(
          Link,
          {
            to: "/menu",
            search: { cat: OFFERS_MENU_FILTER },
            className: "inline-flex w-full items-center justify-center gap-2 rounded-full border-2 border-primary px-6 py-3.5 text-sm font-medium text-primary",
            children: "Today's Offers"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 grid grid-cols-2 gap-4 text-center text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl glass p-4 border shadow-soft", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-display text-primary", children: CAFE_HERO_OPENS }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground text-xs mt-1", children: "Opens daily" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl glass p-4 border shadow-soft", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-display text-primary", children: "★ 4.9" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground text-xs mt-1", children: "Loved locally" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-[2] section-inner hidden min-h-[calc(100svh-4rem)] grid-cols-2 items-center gap-6 pb-16 pt-28 sm:pt-32 md:grid lg:min-h-[100svh] lg:gap-10 lg:pb-20", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        motion.div,
        {
          initial: { opacity: 0, y: 40 },
          animate: { opacity: 1, y: 0 },
          transition: { duration: 0.9, delay: 0.4 },
          style: { opacity: heroOpacity },
          className: "relative max-w-xl",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-primary text-xs font-semibold uppercase tracking-widest", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5" }),
              " ",
              badge
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "mt-5 text-5xl lg:text-7xl xl:text-8xl font-display leading-[0.95] text-primary", children: [
              titleBefore,
              " ",
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: titleAccent }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
              titleAfter
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 text-lg text-muted-foreground max-w-md", children: hero.tagline }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-7 flex flex-wrap gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Link,
                {
                  to: "/menu",
                  className: "inline-flex items-center gap-2 px-7 py-3.5 rounded-full gradient-choco text-primary-foreground font-medium shadow-glow hover:scale-105 transition",
                  children: [
                    "Explore Menu ",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
                  ]
                }
              ),
              isOffersSectionVisible(offersSectionVisible) && /* @__PURE__ */ jsxRuntimeExports.jsx(
                Link,
                {
                  to: "/menu",
                  search: { cat: OFFERS_MENU_FILTER },
                  className: "inline-flex items-center gap-2 px-7 py-3.5 rounded-full border-2 border-primary text-primary font-medium hover:bg-primary hover:text-primary-foreground transition",
                  children: "Today's Offers"
                }
              )
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 flex items-center gap-8 text-sm", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-display text-primary", children: CAFE_HERO_OPENS }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground", children: "Opens daily" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-10 w-px bg-border" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-3xl font-display text-primary", children: "★ 4.9" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-muted-foreground", children: "Loved locally" })
              ] })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative flex h-[min(72vh,620px)] min-h-[420px] items-center justify-center overflow-visible", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative h-full w-full max-w-[520px] [perspective:1200px]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.img,
          {
            src: hero.image || heroDessert,
            alt: "Signature dessert",
            style: { rotate: rotateMain, scale: scaleMain },
            initial: { opacity: 0, scale: 0.6, rotate: -16 },
            animate: { opacity: 1, scale: 1, rotate: 0 },
            transition: { duration: 1.2, delay: 0.35, ease: [0.16, 1, 0.3, 1] },
            className: "absolute inset-0 m-auto h-[88%] w-[88%] object-contain drop-shadow-2xl animate-float-slow"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.img,
          {
            src: floats[0] || float1,
            alt: "",
            style: { y: y1 },
            className: "absolute left-0 top-[8%] z-10 w-24 rotate-[-12deg] drop-shadow-xl lg:w-32 xl:w-36"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.img,
          {
            src: floats[1] || float2,
            alt: "",
            style: { y: y2 },
            className: "absolute bottom-[6%] right-0 z-10 w-24 rotate-[8deg] drop-shadow-xl lg:w-32 xl:w-40"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.img,
          {
            src: floats[2] || float3,
            alt: "",
            style: { y: y3 },
            className: "absolute right-[6%] top-[28%] z-10 w-20 rotate-[14deg] drop-shadow-xl lg:w-28 xl:w-32"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          motion.div,
          {
            animate: { rotate: 360 },
            transition: { duration: 40, repeat: Infinity, ease: "linear" },
            className: "absolute -bottom-6 -left-6 h-40 w-40 rounded-full border-2 border-dashed border-primary/30 opacity-50 lg:h-48 lg:w-48"
          }
        )
      ] }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      motion.div,
      {
        initial: { opacity: 0 },
        animate: { opacity: 1 },
        transition: { delay: 1.5 },
        className: "absolute bottom-6 left-1/2 z-[2] hidden -translate-x-1/2 flex-col items-center gap-2 text-xs uppercase tracking-[0.3em] text-primary/60 md:flex",
        children: [
          "Scroll",
          /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { animate: { y: [0, 6, 0] }, transition: { duration: 1.5, repeat: Infinity }, className: "w-px h-8 bg-primary/40" })
        ]
      }
    )
  ] });
}
const FOOD_ICONS = [
  Cake,
  Coffee,
  Cookie,
  IceCreamCone,
  IceCreamCone,
  Cherry,
  Croissant,
  Candy,
  CupSoda,
  Milk,
  Sparkles
];
function IngredientsFloatingBg() {
  const items = reactExports.useMemo(
    () => Array.from({ length: 36 }, (_, i) => {
      const Icon = FOOD_ICONS[i % FOOD_ICONS.length];
      return {
        Icon,
        left: `${(i * 13.7 + 2) % 96}%`,
        top: `${(i * 19.3 + 4) % 92}%`,
        size: 14 + i % 5 * 7,
        opacity: 0.06 + i % 4 * 0.035,
        delay: i % 9 * 0.45,
        duration: 7 + i % 7 * 1.8,
        driftX: (i % 5 - 2) * 14,
        driftY: -18 - i % 6 * 6,
        rotate: i % 8 * 18 - 28,
        tint: i % 3 === 0 ? "rose" : "primary"
      };
    }),
    []
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pointer-events-none absolute inset-0 overflow-hidden", "aria-hidden": true, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -right-16 top-[10%] h-56 w-56 rounded-full bg-[oklch(0.86_0.10_350/0.12)] blur-3xl" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute -left-12 bottom-[15%] h-48 w-48 rounded-full bg-[oklch(0.90_0.07_355/0.10)] blur-3xl" }),
    items.map((item, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      motion.div,
      {
        className: item.tint === "rose" ? "absolute text-[oklch(0.72_0.12_350)]" : "absolute text-primary",
        style: {
          left: item.left,
          top: item.top,
          opacity: item.opacity
        },
        animate: {
          y: [0, item.driftY, 0],
          x: [0, item.driftX, 0],
          rotate: [item.rotate, item.rotate + 20, item.rotate - 10, item.rotate]
        },
        transition: {
          duration: item.duration,
          repeat: Infinity,
          delay: item.delay,
          ease: "easeInOut"
        },
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(item.Icon, { style: { width: item.size, height: item.size }, strokeWidth: 1.5 })
      },
      i
    ))
  ] });
}
const features = [{
  icon: Award,
  title: "Belgian Chocolate",
  desc: "Deep, silky cocoa in every bite.",
  detail: "Real Belgian chocolate in our ganache, mousse, and drizzles — rich taste without artificial fillers."
}, {
  icon: Sparkles,
  title: "Premium Pistachios",
  desc: "Nutty, fresh, and carefully picked.",
  detail: "Top-grade pistachios for our creams, pastries, and seasonal favorites — quality you can taste."
}, {
  icon: ChefHat,
  title: "Crafted Fresh Daily",
  desc: "Made in our kitchen every morning.",
  detail: "We bake and prep throughout the day so your dessert lands on the plate at its very best."
}, {
  icon: Heart,
  title: "Warm Cafe Vibes",
  desc: "A cozy spot to slow down and enjoy.",
  detail: "Hyde Park's neighborhood cafe for coffee dates, family treats, and sweet moments that linger."
}];
function Index() {
  const {
    categories,
    products,
    offers,
    offersSectionVisible
  } = useShop();
  const menuCategories = visibleCategories(categories);
  const visibleCategoryIds = new Set(menuCategories.map((c) => c.id));
  const featured = products.filter((p) => visibleCategoryIds.has(p.categoryId)).slice(0, 4);
  const liveOffers = offers.filter(isLiveOffer).slice(0, 3);
  const showOffersBlock = isOffersSectionVisible(offersSectionVisible) && liveOffers.length > 0;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Hero3D, {}),
    showOffersBlock && /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-pad bg-muted/40", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto flex max-w-5xl flex-col items-center text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] sm:text-xs font-semibold uppercase tracking-[0.25em] sm:tracking-[0.3em] text-accent mb-2 sm:mb-3", children: "Limited Time" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-3xl sm:text-4xl lg:text-5xl font-display leading-tight text-primary", children: "Today's Offers" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 sm:mt-4 text-sm sm:text-base text-muted-foreground max-w-lg", children: "Bundles too sweet to skip — order straight from here." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 flex w-full flex-wrap items-stretch justify-center gap-4 sm:gap-6", children: liveOffers.map((o, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(OfferCard, { offer: o, index: i, className: "w-full max-w-[300px] sm:max-w-[320px]" }, o.id)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", search: {
        cat: OFFERS_MENU_FILTER
      }, className: "mt-8 inline-flex rounded-full border-2 border-primary px-6 py-2.5 text-sm font-medium text-primary transition hover:bg-primary hover:text-primary-foreground", children: "View all offers" })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-pad", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Discover", title: "Sweet Categories", sub: "Pick a craving — we've got it covered." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5", children: menuCategories.map((c, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { initial: {
        opacity: 0,
        y: 30
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, transition: {
        duration: 0.5,
        delay: i * 0.07
      }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/menu", search: {
        cat: c.id
      }, className: "group relative block aspect-[4/5] rounded-3xl overflow-hidden shadow-soft", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: c.image, alt: c.name, className: "w-full h-full object-cover transition-transform duration-700 group-hover:scale-110", loading: "lazy" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overlay-pink-card absolute inset-0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-x-0 bottom-0 p-3 sm:p-6 text-primary-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-base sm:text-xl lg:text-2xl font-display", children: c.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs uppercase tracking-widest opacity-80", children: "Browse →" })
        ] })
      ] }) }, c.id)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-pad bg-muted/40", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Bestsellers", title: "House Favorites" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6", children: featured.map((p, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(ProductCard, { p, index: i }, p.id)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center mt-12", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", className: "inline-flex px-7 py-3.5 rounded-full gradient-choco text-primary-foreground font-medium hover:scale-105 transition", children: "View Full Menu" }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "section-pad bg-primary text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-10 items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center lg:text-left", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] sm:text-xs font-semibold uppercase tracking-[0.25em] sm:tracking-[0.3em] text-accent mb-2 sm:mb-3", children: "Visit Us" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-3xl sm:text-4xl lg:text-5xl font-display leading-tight", children: [
          "Find your ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: "sweet spot" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-4 sm:mt-6 opacity-80 text-sm sm:text-base max-w-md mx-auto lg:mx-0", children: [
          "Cozy corner of Hyde Park, Chicago. Open ",
          CAFE_HOURS,
          " — every single day."
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-6 sm:mt-8 space-y-3 sm:space-y-4 text-sm sm:text-base inline-block text-left", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "text-accent shrink-0 mt-0.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "1658 E 53rd St, Chicago, IL 60615" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "text-accent shrink-0" }),
            "+1 (773) 966-4332"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "text-accent shrink-0" }),
            CAFE_HOURS_FOOTER
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(MapLocationBox, { className: "w-full", showLabel: false, borderClassName: "border border-white/10" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "relative flex min-h-[100svh] flex-col justify-start overflow-hidden border-t border-border/60 gradient-hero pb-8 pt-16 text-primary sm:pb-10 sm:pt-20 lg:pb-12 lg:pt-24", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(IngredientsFloatingBg, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner relative z-[1] w-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-12 text-center md:mb-16 lg:mb-20", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-accent sm:mb-3 sm:text-xs sm:tracking-[0.3em]", children: "Why Choose Us" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-4xl font-display leading-tight sm:text-5xl lg:text-6xl xl:text-7xl", children: "Our Ingredients" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-4 max-w-2xl text-base text-muted-foreground sm:mt-6 sm:text-lg", children: "Real ingredients, made with care — here is what makes every Sweet Drip bite special." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto grid max-w-6xl grid-cols-2 gap-4 sm:gap-5 lg:grid-cols-4 lg:gap-6 xl:max-w-7xl", children: features.map((f, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
          opacity: 0,
          y: 30
        }, whileInView: {
          opacity: 1,
          y: 0
        }, viewport: {
          once: true
        }, transition: {
          duration: 0.5,
          delay: i * 0.1
        }, className: "group relative flex min-h-[11rem] flex-col overflow-hidden rounded-2xl border border-border/70 bg-card/95 p-5 shadow-soft backdrop-blur-sm transition duration-300 hover:border-accent/50 hover:shadow-glow sm:min-h-[12rem] sm:rounded-3xl sm:p-6 lg:min-h-[14rem] lg:p-7", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pointer-events-none absolute -right-4 -top-4 h-20 w-20 rounded-full bg-accent/20 blur-2xl transition duration-300 group-hover:bg-accent/30" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative mb-4 flex h-12 w-12 items-center justify-center rounded-xl gradient-gold text-primary shadow-soft sm:h-14 sm:w-14 lg:h-16 lg:w-16", children: /* @__PURE__ */ jsxRuntimeExports.jsx(f.icon, { className: "h-5 w-5 sm:h-6 sm:w-6 lg:h-7 lg:w-7" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "relative text-lg font-display leading-snug text-primary sm:text-xl lg:text-2xl", children: f.title }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "relative mt-2 text-sm font-medium text-accent sm:text-base", children: f.desc }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "relative mt-2 text-xs leading-relaxed text-muted-foreground sm:text-sm", children: f.detail })
        ] }, f.title)) })
      ] })
    ] })
  ] });
}
export {
  Index as component
};
