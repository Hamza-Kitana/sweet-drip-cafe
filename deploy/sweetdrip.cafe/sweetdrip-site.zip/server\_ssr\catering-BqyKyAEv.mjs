import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { u as useShop } from "./store-C3jzrryZ.mjs";
import { I as Input, B as Button, c as isApiMode, s as submitCatering, L as Label } from "./router-CypnlrKc.mjs";
import { T as Textarea } from "./textarea-G8B6rCe0.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as usPhoneDigits, f as formatUsPhoneLocal, a as formatUsPhoneFull } from "./phone-CFudh2dU.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { U as Users, l as Send, m as CalendarClock } from "../_libs/lucide-react.mjs";
import { o as objectType, s as stringType, c as coerce } from "../_libs/zod.mjs";
import "../_libs/zustand.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const schema = objectType({
  name: stringType().trim().min(1, "Name required").max(80),
  email: stringType().trim().email("Invalid email").max(120),
  phone: stringType().transform(usPhoneDigits).refine((digits) => digits.length === 10, "Enter a valid 10-digit US phone number").transform(formatUsPhoneFull),
  guests: coerce.number().min(1, "Must be at least 1").max(500),
  date: stringType().min(1, "Date required"),
  time: stringType().min(1, "Time required"),
  message: stringType().max(500).optional()
});
function CateringPage() {
  const addLargeOrder = useShop((s) => s.addLargeOrder);
  const [form, setForm] = reactExports.useState({
    name: "",
    email: "",
    phone: "",
    guests: "1",
    date: "",
    time: "",
    message: ""
  });
  const [sent, setSent] = reactExports.useState(false);
  const onSubmit = async (e) => {
    e.preventDefault();
    const result = schema.safeParse(form);
    if (!result.success) {
      toast.error(result.error.issues[0].message);
      return;
    }
    try {
      if (isApiMode) {
        await submitCatering(result.data);
      } else {
        addLargeOrder(result.data);
      }
      setSent(true);
      toast.success("Catering request sent! We'll contact you soon.");
      setForm({
        name: "",
        email: "",
        phone: "",
        guests: "1",
        date: "",
        time: "",
        message: ""
      });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not send request");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-10 sm:py-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-2xl px-1 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-secondary sm:mb-3 sm:tracking-[0.3em]", children: "Events & Parties" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "font-display text-4xl leading-tight text-primary sm:text-5xl lg:text-6xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: "Catering" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground sm:text-base", children: "Planning a party, office treat, or special celebration? Tell us what you need and we'll prepare a custom quote for your group." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 20
    }, animate: {
      opacity: 1,
      y: 0
    }, className: "mx-auto mt-8 max-w-2xl rounded-2xl border bg-card p-5 shadow-soft sm:rounded-3xl sm:p-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex items-center gap-3 rounded-2xl bg-muted/50 p-4 text-sm text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Users, { className: "h-5 w-5 shrink-0 text-accent" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Ideal for birthdays, weddings, corporate events, and orders of 10+ guests." })
      ] }),
      sent && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-6 rounded-2xl border border-accent/30 bg-accent/10 px-4 py-3 text-sm text-primary", children: "Thanks! Your catering request was received. Our team will reach out by email or phone." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit, className: "grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.name, onChange: (e) => setForm({
          ...form,
          name: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Email *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "email", value: form.email, onChange: (e) => setForm({
          ...form,
          email: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Phone Number *", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex overflow-hidden rounded-md border border-input bg-background shadow-sm focus-within:ring-1 focus-within:ring-ring", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex shrink-0 items-center border-r border-input bg-muted/50 px-3 text-sm font-medium text-muted-foreground", children: "+1" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "tel", inputMode: "numeric", autoComplete: "tel-national", className: "border-0 shadow-none focus-visible:ring-0", value: formatUsPhoneLocal(form.phone), placeholder: "(773) 966-4332", onChange: (e) => setForm({
            ...form,
            phone: usPhoneDigits(e.target.value)
          }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Guest Count *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: "1", value: form.guests, onChange: (e) => setForm({
          ...form,
          guests: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Date *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", value: form.date, onChange: (e) => setForm({
          ...form,
          date: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Time *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "time", value: form.time, onChange: (e) => setForm({
          ...form,
          time: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Message", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { rows: 4, value: form.message, placeholder: "Tell us about your event, preferred desserts, dietary notes…", onChange: (e) => setForm({
          ...form,
          message: e.target.value
        }) }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "submit", size: "lg", className: "sm:col-span-2 mt-1 rounded-full gradient-choco text-primary-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Send, { className: "mr-2 h-4 w-4" }),
          " Submit request"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-4 flex items-center justify-center gap-2 text-center text-xs text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(CalendarClock, { className: "h-3.5 w-3.5" }),
        "Please submit at least 48 hours before your event when possible."
      ] })
    ] })
  ] });
}
function Field({
  label,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: label }),
    children
  ] });
}
export {
  CateringPage as component
};
