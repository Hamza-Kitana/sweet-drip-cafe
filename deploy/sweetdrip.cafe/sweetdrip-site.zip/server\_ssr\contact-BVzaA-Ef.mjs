import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { M as MapLocationBox } from "./MapLocationBox-BWvUIGZ5.mjs";
import { C as CAFE_EMAIL, d as CAFE_HOURS } from "./router-CypnlrKc.mjs";
import "../_libs/sonner.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { a as MapPin, P as Phone, h as Mail, C as Clock, I as Instagram, F as Facebook } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "./store-C3jzrryZ.mjs";
import "../_libs/zustand.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/zod.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function ContactPage() {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-10 sm:py-16", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center mb-8 sm:mb-12 px-1", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] sm:text-xs font-semibold uppercase tracking-[0.25em] sm:tracking-[0.3em] text-secondary mb-2 sm:mb-3", children: "Get in Touch" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-4xl sm:text-5xl lg:text-6xl font-display text-primary leading-tight", children: [
        "Say ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: "hello" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 20
    }, animate: {
      opacity: 1,
      y: 0
    }, className: "grid w-full grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(InfoCard, { icon: MapPin, title: "Visit us", lines: ["1658 E 53rd St", "Chicago, IL 60615"] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(InfoCard, { icon: Phone, title: "Call", lines: ["+1 (773) 966-4332"] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(InfoCard, { icon: Mail, title: "Email", lines: [CAFE_EMAIL] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(InfoCard, { icon: Clock, title: "Hours", lines: ["Monday to Sunday", CAFE_HOURS] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 sm:mt-12 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] sm:text-xs font-semibold uppercase tracking-[0.25em] sm:tracking-[0.3em] text-secondary mb-4 sm:mb-5", children: "Follow us" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap justify-center gap-4 sm:gap-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Social, { href: "https://www.instagram.com/sweetdrip_desserts/", Icon: Instagram, label: "Instagram" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Social, { href: "https://www.facebook.com/profile.php?id=61557068464580", Icon: Facebook, label: "Facebook" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Social, { href: "https://www.tiktok.com/@sweet.drip.cafe", Icon: TikTokIcon, label: "TikTok" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 sm:mt-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-4 text-center text-2xl font-display text-primary sm:text-3xl", children: "Our location" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(MapLocationBox, { aspectClassName: "aspect-[4/3] lg:aspect-[21/9]", borderClassName: "border" })
    ] })
  ] });
}
function InfoCard({
  icon: Icon,
  title,
  lines
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4 rounded-2xl border bg-card p-5 shadow-soft", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex h-11 w-11 shrink-0 items-center justify-center rounded-xl gradient-choco text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-5 w-5" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold", children: title }),
      lines.map((l, i) => /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: l }, i))
    ] })
  ] });
}
function Social({
  href,
  Icon,
  label
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("a", { href, target: "_blank", rel: "noreferrer", "aria-label": label, className: "inline-flex h-16 w-16 items-center justify-center rounded-2xl border bg-card text-primary shadow-soft transition hover:border-[oklch(0.68_0.11_350)] hover:bg-[oklch(0.72_0.1_350)] hover:text-white hover:shadow-glow sm:h-[4.5rem] sm:w-[4.5rem] sm:rounded-3xl", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: "h-8 w-8 sm:h-9 sm:w-9" }) });
}
function TikTokIcon({
  className = ""
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 24 24", fill: "currentColor", className, "aria-hidden": true, children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M19.5 6.6a5.6 5.6 0 0 1-3.3-1V15a5.7 5.7 0 1 1-5.7-5.7c.3 0 .6 0 .9.1v2.9a2.8 2.8 0 1 0 2 2.7V2h2.8a5.6 5.6 0 0 0 3.3 4.6Z" }) });
}
export {
  ContactPage as component
};
