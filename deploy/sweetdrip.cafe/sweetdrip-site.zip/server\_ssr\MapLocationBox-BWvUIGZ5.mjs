import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { P as CAFE_ADDRESS, N as CAFE_MAPS_URL, U as CAFE_MAP_EMBED } from "./router-CypnlrKc.mjs";
import { a as MapPin, a4 as ExternalLink } from "../_libs/lucide-react.mjs";
function MapLocationBox({
  className = "",
  aspectClassName = "aspect-[4/3]",
  borderClassName = "border border-border",
  showLabel = true
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className, children: [
    showLabel && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-3 flex flex-wrap items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "inline-flex items-center gap-2 text-sm font-medium text-primary", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-4 w-4 shrink-0 text-accent" }),
        CAFE_ADDRESS
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "a",
        {
          href: CAFE_MAPS_URL,
          target: "_blank",
          rel: "noopener noreferrer",
          className: "inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground transition hover:text-primary",
          children: [
            "Open in Google Maps",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "h-3.5 w-3.5" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `relative min-h-[280px] w-full overflow-hidden rounded-2xl bg-muted shadow-glow sm:min-h-[340px] sm:rounded-3xl lg:min-h-[400px] ${borderClassName} ${aspectClassName}`,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "iframe",
          {
            title: "Sweet Drip on Google Maps",
            src: CAFE_MAP_EMBED,
            className: "absolute inset-0 z-[1] h-full w-full touch-auto border-0",
            loading: "eager",
            referrerPolicy: "no-referrer-when-downgrade",
            allow: "fullscreen; geolocation",
            allowFullScreen: true
          }
        )
      }
    )
  ] });
}
export {
  MapLocationBox as M
};
