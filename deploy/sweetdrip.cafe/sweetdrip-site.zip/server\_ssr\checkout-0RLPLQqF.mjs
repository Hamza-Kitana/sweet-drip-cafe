import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { E as Elements, u as useStripe, a as useElements, P as PaymentElement } from "../_libs/stripe__react-stripe-js.mjs";
import { l as loadStripe } from "../_libs/stripe__stripe-js.mjs";
import { a as useCart, u as useShop, c as calcOrderTotal, f as fmt } from "./store-C3jzrryZ.mjs";
import { c as isApiMode, g as checkoutOrder, I as Input, B as Button, L as Label, e as cn, h as confirmOrderPayment } from "./router-CypnlrKc.mjs";
import { c as createServerFn, T as TSS_SERVER_FUNCTION, g as getServerFnById } from "./server-wmVDca3q.mjs";
import { R as Root, C as CollapsibleTrigger$1, a as CollapsibleContent$1 } from "../_libs/radix-ui__react-collapsible.mjs";
import { T as Textarea } from "./textarea-G8B6rCe0.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { u as usPhoneDigits, f as formatUsPhoneLocal, a as formatUsPhoneFull } from "./phone-CFudh2dU.mjs";
import "../_libs/seroval.mjs";
import { i as ChevronLeft, b as LoaderCircle, Z as Zap, j as ChevronDown, k as CreditCard } from "../_libs/lucide-react.mjs";
import { o as objectType, s as stringType, n as numberType, a as arrayType } from "../_libs/zod.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/prop-types.mjs";
import "../_libs/zustand.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/framer-motion.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:stream/promises";
import "node:https";
import "node:http2";
var createSsrRpc = (functionId) => {
  const url = "/_serverFn/" + functionId;
  const serverFnMeta = { id: functionId };
  const fn = async (...args) => {
    return (await getServerFnById(functionId))(...args);
  };
  return Object.assign(fn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
const paymentItemSchema = objectType({
  productId: stringType(),
  name: stringType().min(1).max(120),
  price: numberType().positive().max(1e4),
  qty: numberType().int().positive().max(99)
});
const createPaymentIntentSchema = objectType({
  items: arrayType(paymentItemSchema).min(1).max(50),
  tip: numberType().min(0).max(1e4),
  taxRatePercent: numberType().min(0).max(100),
  customer: objectType({
    name: stringType().min(1).max(80),
    email: stringType().email().max(120)
  })
});
const createStripePaymentIntent = createServerFn({
  method: "POST"
}).inputValidator(createPaymentIntentSchema).handler(createSsrRpc("2b18546985cda1bbb95ca0c0de06a097fc763f8bd3a0a479e262b67c203c3b70"));
const Collapsible = Root;
const CollapsibleTrigger = CollapsibleTrigger$1;
const CollapsibleContent = CollapsibleContent$1;
function StripePaymentForm({ total, customerEmail, onSuccess }) {
  const stripe = useStripe();
  const elements = useElements();
  const [submitting, setSubmitting] = reactExports.useState(false);
  const [error, setError] = reactExports.useState(null);
  const [linkOpen, setLinkOpen] = reactExports.useState(false);
  const [elementKey, setElementKey] = reactExports.useState(0);
  const toggleLink = (open) => {
    setLinkOpen(open);
    setElementKey((k) => k + 1);
  };
  const onSubmit = async (e) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setSubmitting(true);
    setError(null);
    const { error: stripeError, paymentIntent } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: `${window.location.origin}/invoice`,
        receipt_email: customerEmail
      },
      redirect: "if_required"
    });
    if (stripeError) {
      setError(stripeError.message ?? "Payment failed. Please try again.");
      setSubmitting(false);
      return;
    }
    if (paymentIntent?.status === "succeeded") {
      onSuccess(paymentIntent.id);
      return;
    }
    setError("Payment was not completed. Please try again.");
    setSubmitting(false);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit, className: "space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Collapsible, { open: linkOpen, onOpenChange: toggleLink, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CollapsibleTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
        "button",
        {
          type: "button",
          className: "flex w-full items-center justify-between gap-3 rounded-2xl border border-[oklch(0.72_0.09_350/0.22)] bg-muted/20 px-4 py-3 text-left text-sm transition hover:bg-muted/40",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Zap, { className: "h-4 w-4 text-primary" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: "Pay faster next time with Link" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2 rounded-full bg-muted px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-muted-foreground", children: "Optional" })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: cn("h-4 w-4 shrink-0 text-muted-foreground transition-transform", linkOpen && "rotate-180") })
          ]
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(CollapsibleContent, { className: "px-1 pt-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs leading-relaxed text-muted-foreground", children: "Enable Stripe Link to save your card securely for faster checkout on your next visit. Extra fields will appear below the card form." }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      PaymentElement,
      {
        options: {
          layout: "tabs",
          wallets: {
            link: linkOpen ? "auto" : "never",
            applePay: "never",
            googlePay: "never"
          }
        }
      },
      elementKey
    ),
    error && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "rounded-xl border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm text-destructive", children: error }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      Button,
      {
        type: "submit",
        size: "lg",
        disabled: !stripe || !elements || submitting,
        className: "w-full rounded-full gradient-choco text-primary-foreground",
        children: submitting ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "mr-2 h-4 w-4 animate-spin" }),
          "Processing…"
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(CreditCard, { className: "mr-2 h-4 w-4" }),
          "Pay ",
          fmt(total)
        ] })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-xs text-muted-foreground", children: "Secure payment powered by Stripe" })
  ] });
}
const schema = objectType({
  name: stringType().trim().min(1, "Name required").max(80),
  email: stringType().trim().email("Invalid email").max(120),
  phone: stringType().transform(usPhoneDigits).refine((digits) => digits.length === 10, "Enter a valid 10-digit US phone number").transform(formatUsPhoneFull),
  date: stringType().min(1, "Date required"),
  time: stringType().min(1, "Time required"),
  message: stringType().max(500).optional()
});
const stripePublishableKey = "pk_live_51Ontg5KWw72MSwIvNnfj86dg9bJG3vY3YhohEOhFiOIpimD8InWSe2N6JndS9uj59wlRdv4ohulMla1LA92ip1q000JYCBi3L1"?.trim() || "";
const stripePromise = stripePublishableKey ? loadStripe(stripePublishableKey) : null;
const isLiveStripe = stripePublishableKey.startsWith("pk_live_");
function parseTipInput(value) {
  if (value === "" || value === ".") return 0;
  const n = parseFloat(value);
  return Number.isNaN(n) || n < 0 ? 0 : +n.toFixed(2);
}
function CheckoutPage() {
  const {
    items,
    tip,
    setTip,
    clear,
    setLastOrderId
  } = useCart();
  const setDrawerOpen = useCart((s) => s.setDrawerOpen);
  const taxRatePercent = useShop((s) => s.taxRatePercent);
  const navigate = useNavigate();
  const [step, setStep] = reactExports.useState("details");
  const [tipInput, setTipInput] = reactExports.useState(tip > 0 ? String(tip) : "");
  const [form, setForm] = reactExports.useState({
    name: "",
    email: "",
    phone: "",
    date: "",
    time: "",
    message: ""
  });
  const [clientSecret, setClientSecret] = reactExports.useState(null);
  const [pendingOrderId, setPendingOrderId] = reactExports.useState(null);
  const [paymentLoading, setPaymentLoading] = reactExports.useState(false);
  const [paymentError, setPaymentError] = reactExports.useState(null);
  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const tipAmount = parseTipInput(tipInput);
  const totals = reactExports.useMemo(() => calcOrderTotal(subtotal, tipAmount, taxRatePercent), [subtotal, tipAmount, taxRatePercent]);
  const applyTip = (value) => {
    setTipInput(value);
    setTip(parseTipInput(value));
  };
  const stripeEnabled = Boolean(stripePublishableKey);
  const initPayment = reactExports.useCallback(async (customer) => {
    if (!stripeEnabled) return;
    setPaymentLoading(true);
    setPaymentError(null);
    setClientSecret(null);
    try {
      if (isApiMode) {
        const result = await checkoutOrder({
          items: items.map((i) => ({
            productId: i.productId,
            name: i.name,
            price: i.price,
            qty: i.qty,
            note: i.note,
            noteChoice: i.noteChoice,
            image: i.image
          })),
          tip: tipAmount,
          customer: {
            name: customer.name,
            email: customer.email,
            phone: customer.phone,
            date: customer.date,
            time: customer.time,
            message: customer.message
          }
        });
        setPendingOrderId(result.orderId);
        setClientSecret(result.clientSecret);
      } else {
        const result = await createStripePaymentIntent({
          data: {
            items: items.map((i) => ({
              productId: i.productId,
              name: i.name,
              price: i.price,
              qty: i.qty
            })),
            tip: tipAmount,
            taxRatePercent,
            customer: {
              name: customer.name,
              email: customer.email
            }
          }
        });
        setPendingOrderId(null);
        setClientSecret(result.clientSecret);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not start payment";
      setPaymentError(message);
      toast.error(message);
    } finally {
      setPaymentLoading(false);
    }
  }, [items, stripeEnabled, taxRatePercent, tipAmount]);
  reactExports.useEffect(() => {
    if (step !== "payment" || !stripeEnabled) return;
    const parsed = schema.safeParse(form);
    if (!parsed.success) return;
    void initPayment(parsed.data);
  }, [step, stripeEnabled, form, initPayment]);
  if (items.length === 0) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-20 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Your cart is empty." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", className: "text-primary underline", children: "Browse menu" })
    ] });
  }
  const onSubmitDetails = (e) => {
    e.preventDefault();
    const r = schema.safeParse(form);
    if (!r.success) {
      toast.error(r.error.issues[0].message);
      return;
    }
    setTip(tipAmount);
    setStep("payment");
  };
  const onPaymentSuccess = async (paymentIntentId) => {
    try {
      if (isApiMode && pendingOrderId) {
        const order2 = await confirmOrderPayment(pendingOrderId, paymentIntentId);
        setLastOrderId(order2.id);
        clear();
        toast.success("Payment successful");
        navigate({
          to: "/invoice",
          search: {
            payment: paymentIntentId
          }
        });
        return;
      }
      const data = schema.parse(form);
      const order = useShop.getState().addOrder({
        items,
        customer: data,
        subtotal,
        tip: tipAmount,
        tax: totals.tax,
        taxRate: taxRatePercent,
        total: totals.total
      });
      setLastOrderId(order.id);
      clear();
      toast.success("Payment successful");
      navigate({
        to: "/invoice",
        search: {
          payment: paymentIntentId
        }
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Could not confirm payment";
      toast.error(message);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-8 sm:py-12", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => {
      if (step === "payment") {
        setStep("details");
        setClientSecret(null);
        setPendingOrderId(null);
        setPaymentError(null);
      } else {
        setDrawerOpen(true);
        navigate({
          to: "/menu"
        });
      }
    }, className: "mb-4 inline-flex items-center text-sm text-muted-foreground hover:text-primary sm:mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" }),
      " Back"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mb-6 font-display text-3xl text-primary sm:mb-8 sm:text-4xl", children: step === "details" ? "Your details" : "Payment" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-6 lg:grid-cols-[1fr_360px] lg:gap-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "rounded-2xl border bg-card p-4 shadow-soft sm:rounded-3xl sm:p-6", children: step === "details" ? /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: onSubmitDetails, className: "grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: form.name, onChange: (e) => setForm({
          ...form,
          name: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Email *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "email", value: form.email, onChange: (e) => setForm({
          ...form,
          email: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Phone Number *", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex overflow-hidden rounded-md border border-input bg-background shadow-sm focus-within:ring-1 focus-within:ring-ring", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex shrink-0 items-center border-r border-input bg-muted/50 px-3 text-sm font-medium text-muted-foreground", children: "+1" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "tel", inputMode: "numeric", autoComplete: "tel-national", className: "border-0 shadow-none focus-visible:ring-0", value: formatUsPhoneLocal(form.phone), placeholder: "(773) 966-4332", onChange: (e) => setForm({
            ...form,
            phone: usPhoneDigits(e.target.value)
          }) })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Date *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "date", value: form.date, onChange: (e) => setForm({
          ...form,
          date: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Time *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "time", value: form.time, onChange: (e) => setForm({
          ...form,
          time: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Message", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { rows: 3, value: form.message, onChange: (e) => setForm({
          ...form,
          message: e.target.value
        }) }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "submit", size: "lg", className: "mt-2 rounded-full gradient-choco text-primary-foreground sm:col-span-2", children: "Continue to payment" })
      ] }) : !stripeEnabled ? /* @__PURE__ */ jsxRuntimeExports.jsx(StripeSetupNotice, { missing: "publishable" }) : paymentLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col items-center justify-center gap-3 py-16 text-muted-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "h-8 w-8 animate-spin text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Preparing secure checkout…" })
      ] }) : paymentError ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(StripeSetupNotice, { missing: "server", message: paymentError }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { type: "button", variant: "outline", className: "rounded-full", onClick: () => {
          const parsed = schema.safeParse(form);
          if (parsed.success) void initPayment(parsed.data);
        }, children: "Try again" })
      ] }) : clientSecret && stripePromise ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
        isLiveStripe && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-amber-400/40 bg-amber-50 px-4 py-3 text-sm text-amber-950", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: "Live payment mode" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-amber-900/90", children: [
            "Test cards like ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "rounded bg-amber-100 px-1", children: "4242 4242 4242 4242" }),
            " will not work. Use a real card, or switch to Stripe ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "test keys" }),
            " (",
            /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "rounded bg-amber-100 px-1", children: "pk_test_" }),
            " /",
            " ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "rounded bg-amber-100 px-1", children: "sk_test_" }),
            ") in your ",
            /* @__PURE__ */ jsxRuntimeExports.jsx("code", { children: ".env" }),
            " while testing."
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Elements, { stripe: stripePromise, options: {
          clientSecret,
          appearance: {
            theme: "stripe",
            variables: {
              colorPrimary: "#5c3d2e",
              borderRadius: "12px"
            }
          }
        }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(StripePaymentForm, { total: totals.total, customerEmail: form.email, onSuccess: onPaymentSuccess }) }, clientSecret)
      ] }) : null }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("aside", { className: "h-fit rounded-2xl border bg-card p-5 shadow-soft sm:rounded-3xl sm:p-6 lg:sticky lg:top-28", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "mb-4 font-display text-xl text-primary", children: "Order summary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "max-h-60 space-y-2 overflow-auto pr-2 text-sm", children: items.map((i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex justify-between gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            i.qty,
            "× ",
            i.name
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: fmt(i.price * i.qty) })
        ] }, i.uid)) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 rounded-2xl border border-[oklch(0.72_0.09_350/0.22)] bg-muted/25 p-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "tip-amount", className: "mb-2 block text-sm font-medium", children: "Add a tip for the staff" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground", children: "$" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { id: "tip-amount", className: "pl-7", placeholder: "0.00", inputMode: "decimal", value: tipInput, onChange: (e) => applyTip(e.target.value) })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 space-y-1 border-t pt-4 text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Subtotal" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: fmt(subtotal) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Tip" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: fmt(tipAmount) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              "Tax (",
              taxRatePercent,
              "%)"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: fmt(totals.tax) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-2 flex justify-between border-t pt-2 font-display text-lg", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Total" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-primary", children: fmt(totals.total) })
          ] })
        ] })
      ] })
    ] })
  ] });
}
function StripeSetupNotice({
  missing,
  message
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-[oklch(0.72_0.09_350/0.28)] bg-muted/30 p-5 text-sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold text-primary", children: "Stripe setup required" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-muted-foreground", children: message ?? (missing === "publishable" ? "Add VITE_STRIPE_PUBLISHABLE_KEY to your .env file and restart the dev server." : "Add STRIPE_SECRET_KEY on the server and restart the app.") }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-3 list-disc space-y-1 pl-5 text-muted-foreground", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Copy .env.example to .env in the project root" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Paste your Stripe test keys from dashboard.stripe.com/apikeys" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Restart with bun run dev" })
    ] })
  ] });
}
function Field({
  label,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: label }),
    children
  ] });
}
export {
  CheckoutPage as component
};
