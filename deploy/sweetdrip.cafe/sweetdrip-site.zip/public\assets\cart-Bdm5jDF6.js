import{e as a,a as n,r as s}from"./index-qGfLXggG.js";function u(){const e=a(r=>r.setDrawerOpen),t=n();return s.useEffect(()=>{e(!0),t({to:"/menu",replace:!0})},[t,e]),null}export{u as component};
