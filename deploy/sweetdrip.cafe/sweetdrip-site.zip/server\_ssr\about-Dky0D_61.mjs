import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useShop } from "./store-C3jzrryZ.mjs";
import { M as logo, N as CAFE_MAPS_URL, P as CAFE_ADDRESS, Q as CAFE_HOURS_FOOTER } from "./router-CypnlrKc.mjs";
import { S as SectionHeading } from "./SectionHeading-C_mqZXgB.mjs";
import "../_libs/sonner.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { D as ArrowRight, a as MapPin, G as Heart, J as Leaf, N as Award, O as Star, Q as Cake, V as IceCreamCone, W as Coffee, c as Sparkles, C as Clock } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/zod.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
const values = [{
  icon: Heart,
  title: "Made with love",
  desc: "Every dessert is prepared by hand, fresh throughout the day."
}, {
  icon: Leaf,
  title: "Real ingredients",
  desc: "Belgian chocolate, premium pistachios, and real cream — never shortcuts."
}, {
  icon: Award,
  title: "Neighborhood favorite",
  desc: "A cozy Hyde Park spot locals return to for birthdays, dates, and slow afternoons."
}, {
  icon: Star,
  title: "Warm hospitality",
  desc: "Great service is part of the recipe — we want you to feel at home."
}];
const highlights = [{
  icon: Cake,
  label: "Signature cakes & slices"
}, {
  icon: IceCreamCone,
  label: "Scoops, sundaes & seasonal flavors"
}, {
  icon: Coffee,
  label: "Espresso drinks & iced lattes"
}, {
  icon: Sparkles,
  label: "Limited-time bundles & offers"
}];
const milestones = [{
  year: "2019",
  title: "The first drip",
  desc: "Sweet Drip opened on E 53rd St with a small menu and a big dream."
}, {
  year: "2021",
  title: "Growing the menu",
  desc: "Added pistachio favorites, ice cream bar treats, and weekend specials."
}, {
  year: "Today",
  title: "Your sweet escape",
  desc: "Still family-run, still baking daily — now a staple of Hyde Park dessert culture."
}];
const aboutSection = "flex min-h-[100svh] flex-col justify-center section-pad";
function AboutPage() {
  const {
    hero
  } = useShop();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: "flex flex-col items-center justify-center px-4 pb-6 pt-10 text-center sm:pb-8 sm:pt-14 md:pt-16", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
      opacity: 0,
      y: 16
    }, animate: {
      opacity: 1,
      y: 0
    }, transition: {
      duration: 0.7,
      ease: [0.16, 1, 0.3, 1]
    }, className: "flex max-w-2xl flex-col items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: "Sweet Drip", className: "h-36 w-auto drop-shadow-md sm:h-44 md:h-52 lg:h-60" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-6 font-display text-2xl leading-snug text-primary sm:mt-8 sm:text-3xl md:text-4xl", children: [
        "Every drip tells a story of",
        " ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: "sweetness" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-3 max-w-md text-sm leading-relaxed text-muted-foreground sm:mt-4 sm:text-base", children: "Handcrafted desserts, warm smiles, and a cozy corner in Hyde Park where ordinary days turn into sweet memories." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-[10px] font-semibold uppercase tracking-[0.28em] text-secondary sm:text-xs", children: "Est. 2019 · Chicago" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: aboutSection, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-center gap-8 lg:grid-cols-2 lg:gap-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        x: -20
      }, animate: {
        opacity: 1,
        x: 0
      }, transition: {
        duration: 0.6
      }, className: "order-2 text-center lg:order-1 lg:text-left", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-2 text-[10px] font-semibold uppercase tracking-[0.25em] text-secondary sm:mb-3 sm:tracking-[0.3em]", children: "Our Story" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "font-display text-4xl leading-tight text-primary sm:text-5xl lg:text-6xl", children: [
          "A little café with a ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: "big heart" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-base leading-relaxed text-muted-foreground sm:mt-6 sm:text-lg", children: "Sweet Drip began as a love letter to slow afternoons, warm chocolate, and people you want to linger with. We craft every dessert from the very best ingredients and serve them in a space designed to feel like home." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 leading-relaxed text-muted-foreground", children: "From our kitchen in Hyde Park, Chicago, we've shared thousands of sweet moments — birthdays, study breaks, first dates, and quiet treats just because. We can't wait to share one with you." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 flex flex-wrap items-center justify-center gap-3 lg:justify-start", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/menu", className: "inline-flex items-center gap-2 rounded-full gradient-choco px-6 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft transition hover:scale-[1.02]", children: [
            "Explore our menu ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("a", { href: CAFE_MAPS_URL, target: "_blank", rel: "noreferrer", className: "inline-flex items-center gap-2 rounded-full border border-border bg-card px-5 py-2.5 text-sm font-medium text-primary transition hover:border-accent hover:text-accent", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-4 w-4" }),
            " Get directions"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { initial: {
        opacity: 0,
        scale: 0.96
      }, animate: {
        opacity: 1,
        scale: 1
      }, transition: {
        duration: 0.7
      }, className: "order-1 lg:order-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative mx-auto w-full max-w-xl overflow-hidden rounded-2xl shadow-glow ring-1 ring-border/50 sm:rounded-3xl", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: hero.aboutImage, alt: "Inside Sweet Drip cafe", className: "h-52 w-full object-cover sm:h-60 lg:h-72" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-primary/80 to-transparent px-4 py-4 text-left text-primary-foreground sm:px-5 sm:py-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-semibold uppercase tracking-[0.2em] text-accent", children: "Hyde Park · Chicago" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 font-display text-lg sm:text-xl", children: "Where every bite is a sweet escape" })
        ] })
      ] }) })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: `${aboutSection} border-y border-border/60 bg-muted/40`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner w-full", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "What we stand for", title: "More than dessert", sub: "Four promises we keep every single day." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 sm:gap-6", children: values.map((v, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        y: 20
      }, whileInView: {
        opacity: 1,
        y: 0
      }, viewport: {
        once: true
      }, transition: {
        delay: i * 0.08
      }, className: "rounded-2xl border bg-card p-6 text-center shadow-soft sm:rounded-3xl sm:p-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl gradient-choco text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(v.icon, { className: "h-5 w-5" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold", children: v.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-relaxed text-muted-foreground", children: v.desc })
      ] }, v.title)) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: aboutSection, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 gap-10 lg:grid-cols-2 lg:items-center lg:gap-14", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "On the menu", title: "Cravings we love", sub: "A taste of what you'll find when you walk in." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mx-auto grid max-w-md gap-3 sm:max-w-none", children: highlights.map((item, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.li, { initial: {
          opacity: 0,
          x: -12
        }, whileInView: {
          opacity: 1,
          x: 0
        }, viewport: {
          once: true
        }, transition: {
          delay: i * 0.06
        }, className: "flex items-center gap-4 rounded-2xl border bg-card px-4 py-3.5 shadow-soft sm:px-5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/25 text-primary", children: /* @__PURE__ */ jsxRuntimeExports.jsx(item.icon, { className: "h-5 w-5" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium sm:text-base", children: item.label })
        ] }, item.label)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Our journey", title: "How we got here" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative mx-auto max-w-md space-y-6 sm:max-w-none", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute bottom-2 left-[1.125rem] top-2 w-px bg-border sm:left-5", "aria-hidden": true }),
          milestones.map((m, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
            opacity: 0,
            y: 16
          }, whileInView: {
            opacity: 1,
            y: 0
          }, viewport: {
            once: true
          }, transition: {
            delay: i * 0.1
          }, className: "relative flex gap-4 sm:gap-5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "relative z-[1] flex h-9 w-9 shrink-0 items-center justify-center rounded-full gradient-gold text-xs font-bold text-primary shadow-soft sm:h-10 sm:w-10", children: m.year.slice(2) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border bg-card p-4 shadow-soft sm:p-5", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-semibold uppercase tracking-[0.2em] text-secondary", children: m.year }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mt-1 font-semibold text-primary", children: m.title }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-sm leading-relaxed text-muted-foreground", children: m.desc })
            ] })
          ] }, m.year))
        ] })
      ] })
    ] }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("section", { className: `${aboutSection} bg-primary text-primary-foreground`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mx-auto max-w-3xl rounded-3xl border border-white/10 bg-white/5 p-8 text-center backdrop-blur-sm sm:p-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] font-semibold uppercase tracking-[0.28em] text-accent", children: "Visit us" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "mt-3 font-display text-3xl sm:text-4xl", children: [
        "Pull up a chair at ",
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-script text-gradient-gold", children: "Sweet Drip" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-4 max-w-lg text-sm leading-relaxed opacity-85 sm:text-base", children: "We're open seven days a week in the heart of Hyde Park — perfect for a post-dinner treat, a study break, or a celebration with someone special." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-6 inline-flex flex-col gap-3 text-left text-sm sm:text-base", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-4 w-4 shrink-0 text-accent" }),
          CAFE_ADDRESS
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Clock, { className: "h-4 w-4 shrink-0 text-accent" }),
          CAFE_HOURS_FOOTER
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-wrap justify-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/contact", className: "inline-flex items-center gap-2 rounded-full gradient-gold px-6 py-2.5 text-sm font-semibold text-primary shadow-soft transition hover:scale-[1.02]", children: [
          "Contact us ",
          /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "h-4 w-4" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", className: "inline-flex items-center gap-2 rounded-full border border-white/20 px-6 py-2.5 text-sm font-medium transition hover:border-accent hover:text-accent", children: "View menu" })
      ] })
    ] }) }) })
  ] });
}
export {
  AboutPage as component
};
