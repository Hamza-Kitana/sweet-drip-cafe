function usPhoneDigits(value) {
  let digits = value.replace(/\D/g, "");
  if (digits.startsWith("1") && digits.length > 10) digits = digits.slice(1);
  return digits.slice(0, 10);
}
function formatUsPhoneLocal(digits) {
  const d = usPhoneDigits(digits);
  if (!d) return "";
  if (d.length <= 3) return `(${d}`;
  if (d.length <= 6) return `(${d.slice(0, 3)}) ${d.slice(3)}`;
  return `(${d.slice(0, 3)}) ${d.slice(3, 6)}-${d.slice(6)}`;
}
function formatUsPhoneFull(digits) {
  const d = usPhoneDigits(digits);
  if (d.length !== 10) return "";
  return `+1 ${formatUsPhoneLocal(d)}`;
}
export {
  formatUsPhoneFull as a,
  formatUsPhoneLocal as f,
  usPhoneDigits as u
};
