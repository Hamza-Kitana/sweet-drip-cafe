import { T as TSS_SERVER_FUNCTION, c as createServerFn } from "./server-wmVDca3q.mjs";
import { n as normalizeTaxRate, c as calcOrderTotal } from "./store-C3jzrryZ.mjs";
import { S as Stripe } from "../_libs/stripe.mjs";
import "../_libs/seroval.mjs";
import "../_libs/react.mjs";
import { o as objectType, n as numberType, s as stringType, a as arrayType } from "../_libs/zod.mjs";
import "node:async_hooks";
import "../_libs/h3-v2.mjs";
import "../_libs/rou3.mjs";
import "../_libs/srvx.mjs";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "../_libs/tanstack__react-router.mjs";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
import "events";
import "http";
import "https";
import "os";
var createServerRpc = (serverFnMeta, splitImportFn) => {
  const url = "/_serverFn/" + serverFnMeta.id;
  return Object.assign(splitImportFn, {
    url,
    serverFnMeta,
    [TSS_SERVER_FUNCTION]: true
  });
};
function getStripeSecretKey() {
  return process.env.STRIPE_SECRET_KEY?.trim() || "";
}
function isStripeConfigured() {
  return Boolean(getStripeSecretKey());
}
function getStripeClient() {
  const secretKey = getStripeSecretKey();
  if (!secretKey) {
    throw new Error("STRIPE_SECRET_KEY is not configured");
  }
  return new Stripe(secretKey, {
    apiVersion: "2026-05-27.dahlia"
  });
}
const paymentItemSchema = objectType({
  productId: stringType(),
  name: stringType().min(1).max(120),
  price: numberType().positive().max(1e4),
  qty: numberType().int().positive().max(99)
});
const createPaymentIntentSchema = objectType({
  items: arrayType(paymentItemSchema).min(1).max(50),
  tip: numberType().min(0).max(1e4),
  taxRatePercent: numberType().min(0).max(100),
  customer: objectType({
    name: stringType().min(1).max(80),
    email: stringType().email().max(120)
  })
});
const createStripePaymentIntent_createServerFn_handler = createServerRpc({
  id: "2b18546985cda1bbb95ca0c0de06a097fc763f8bd3a0a479e262b67c203c3b70",
  name: "createStripePaymentIntent",
  filename: "src/lib/api/payment.functions.ts"
}, (opts) => createStripePaymentIntent.__executeServer(opts));
const createStripePaymentIntent = createServerFn({
  method: "POST"
}).inputValidator(createPaymentIntentSchema).handler(createStripePaymentIntent_createServerFn_handler, async ({
  data
}) => {
  if (!isStripeConfigured()) {
    throw new Error("Stripe is not configured on the server. Add STRIPE_SECRET_KEY to your environment.");
  }
  const taxRatePercent = normalizeTaxRate(data.taxRatePercent);
  const subtotal = +data.items.reduce((sum, item) => sum + item.price * item.qty, 0).toFixed(2);
  const tip = +Math.max(0, data.tip).toFixed(2);
  const {
    tax,
    total
  } = calcOrderTotal(subtotal, tip, taxRatePercent);
  if (total < 0.5) {
    throw new Error("Order total must be at least $0.50");
  }
  const stripe = getStripeClient();
  const amountCents = Math.round(total * 100);
  const paymentIntent = await stripe.paymentIntents.create({
    amount: amountCents,
    currency: "usd",
    automatic_payment_methods: {
      enabled: true
    },
    receipt_email: data.customer.email,
    metadata: {
      customer_name: data.customer.name.slice(0, 500),
      customer_email: data.customer.email.slice(0, 500),
      item_count: String(data.items.reduce((n, i) => n + i.qty, 0)),
      subtotal: String(subtotal),
      tip: String(tip),
      tax: String(tax),
      tax_rate: String(taxRatePercent)
    }
  });
  if (!paymentIntent.client_secret) {
    throw new Error("Stripe did not return a client secret");
  }
  return {
    clientSecret: paymentIntent.client_secret,
    paymentIntentId: paymentIntent.id,
    subtotal,
    tip,
    tax,
    taxRatePercent,
    total,
    amountCents
  };
});
export {
  createStripePaymentIntent_createServerFn_handler
};
