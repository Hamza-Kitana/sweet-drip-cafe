import { c as create, p as persist } from "../_libs/zustand.mjs";
const heroDessert = "/assets/hero-dessert-CzX58s3V.jpg";
const aboutCafe = "/assets/about-cafe-DhJZOrMN.jpg";
const float1 = "/assets/float-1-Ci-SjRl3.png";
const float2 = "/assets/float-2-BepYAW2s.png";
const float3 = "/assets/float-3-BSPRS65G.png";
const DEFAULT_ADMIN_USERNAME = "admin";
const DEFAULT_ADMIN_PASSWORD = "admin123";
const seedCategories = [
  { id: "cakes", name: "Cakes", image: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=800" },
  { id: "icecream", name: "Ice Cream", image: "https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?w=800" },
  { id: "drinks", name: "Drinks", image: "https://images.unsplash.com/photo-1517701604599-bb29b565090c?w=800" },
  { id: "pastries", name: "Pastries", image: "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=800" }
];
const seedProducts = [
  { id: "p1", categoryId: "cakes", name: "Belgian Chocolate Cake", description: "Rich layered cake with Belgian chocolate ganache and fresh berries.", price: 8.5, image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=900", notes: "Sweetness", noteChoices: ["Regular sugar", "Less sugar", "No sugar"] },
  { id: "p2", categoryId: "cakes", name: "Pistachio Dream", description: "Layers of pistachio cream with a hint of rose.", price: 7.5, image: "https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=900", notes: "Sweetness", noteChoices: ["Regular", "Less sweet", "Extra sweet"] },
  { id: "p3", categoryId: "icecream", name: "Triple Scoop Cone", description: "Three premium scoops in a fresh waffle cone.", price: 6, image: "https://images.unsplash.com/photo-1488900128323-21503983a07e?w=900", notes: "Flavors", noteChoices: ["Choco/Vanilla/Pistachio", "Strawberry/Vanilla/Choco", "Surprise me"] },
  { id: "p4", categoryId: "icecream", name: "Chocolate Sundae", description: "Vanilla ice cream drowned in warm chocolate sauce.", price: 5.5, image: "https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=900", notes: "Toppings", noteChoices: ["With nuts", "Without nuts", "Extra chocolate"] },
  { id: "p5", categoryId: "drinks", name: "Iced Caramel Latte", description: "Espresso, milk, caramel and ice. Smooth and sweet.", price: 4.5, image: "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?w=900", notes: "Sugar", noteChoices: ["Regular", "Less sugar", "No sugar"] },
  { id: "p6", categoryId: "drinks", name: "Hot Chocolate", description: "Velvety dark hot chocolate with whipped cream.", price: 4, image: "https://images.unsplash.com/photo-1517578239113-b03992dcdd25?w=900", notes: "Style", noteChoices: ["Classic", "With marshmallows", "Spicy"] },
  { id: "p7", categoryId: "pastries", name: "Butter Croissant", description: "Flaky, golden, perfectly buttery.", price: 3.5, image: "https://images.unsplash.com/photo-1555507036-ab1f4038808a?w=900", notes: "Filling", noteChoices: ["Plain", "Chocolate", "Almond"] },
  { id: "p8", categoryId: "pastries", name: "Cinnamon Roll", description: "Warm, gooey, swirled with cinnamon glaze.", price: 4, image: "https://images.unsplash.com/photo-1509365465985-25d11c17e812?w=900", notes: "Glaze", noteChoices: ["Regular", "Extra glaze", "No glaze"] }
];
const HERO_SLIDE_COUNT = 5;
const FLOAT_IMAGE_COUNT = 3;
const defaultBackgroundSlideUrls = [
  heroDessert,
  aboutCafe,
  "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=1400&q=80",
  "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=1400&q=80",
  "https://images.unsplash.com/photo-1488900128323-21503983a07e?w=1400&q=80"
];
const defaultFloatingImages = [float1, float2, float3];
function normalizeBackgroundSlides(slides) {
  let parsed;
  if (!slides?.length) {
    parsed = defaultBackgroundSlideUrls.map((image) => ({ image, caption: "" }));
  } else if (typeof slides[0] === "string") {
    parsed = slides.map((image) => ({ image: image ?? "", caption: "" }));
  } else {
    parsed = slides.map((s) => ({
      image: s.image ?? "",
      caption: s.caption ?? ""
    }));
  }
  const padded = [...parsed];
  while (padded.length < HERO_SLIDE_COUNT) padded.push({ image: "", caption: "" });
  return padded.slice(0, HERO_SLIDE_COUNT);
}
function activeBackgroundSlides(slides) {
  const normalized = normalizeBackgroundSlides(slides);
  const filled = normalized.filter((s) => s.image);
  if (filled.length > 0) return filled;
  return defaultBackgroundSlideUrls.map((image) => ({ image, caption: "" }));
}
function normalizeFloatingImages(images) {
  const source = images?.length ? [...images] : [...defaultFloatingImages];
  const padded = [...source];
  while (padded.length < FLOAT_IMAGE_COUNT) padded.push("");
  return padded.slice(0, FLOAT_IMAGE_COUNT);
}
const seedHero = {
  image: heroDessert,
  floatingImages: defaultFloatingImages,
  aboutImage: aboutCafe,
  tagline: "Where every bite is a sweet escape.",
  backgroundSlides: defaultBackgroundSlideUrls.map((image) => ({ image, caption: "" })),
  heroBadge: "Dessert Cafe · Chicago",
  heroTitleBefore: "Sweet",
  heroTitleAccent: "Drip",
  heroTitleAfter: "Every Day."
};
const seedOffers = [
  {
    id: "o1",
    title: "Sweet Trio",
    description: "1 Cake slice + 1 Drink + 1 Ice cream scoop",
    price: 12,
    image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=900",
    productIds: ["p1", "p5", "p3"],
    active: true
  },
  {
    id: "o2",
    title: "Coffee & Croissant",
    description: "Any hot drink + butter croissant",
    price: 6,
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?w=900",
    productIds: ["p6", "p7"],
    active: true
  }
];
function normalizeTaxRate(rate) {
  const n = Number(rate);
  if (Number.isNaN(n) || n < 0) return 0;
  if (n > 100) return 100;
  return +n.toFixed(2);
}
function calcTaxAmount(subtotal, tip, taxRatePercent) {
  const base = subtotal + tip;
  return +(base * (normalizeTaxRate(taxRatePercent) / 100)).toFixed(2);
}
function calcOrderTotal(subtotal, tip, taxRatePercent) {
  const tax = calcTaxAmount(subtotal, tip, taxRatePercent);
  const total = +(subtotal + tip + tax).toFixed(2);
  return { tax, total };
}
const id = () => Math.random().toString(36).slice(2, 10);
function cartLineKey(item) {
  return [item.productId, item.price, item.noteChoice ?? "", (item.note ?? "").trim()].join("|");
}
function groupCartItems(items) {
  const grouped = /* @__PURE__ */ new Map();
  for (const item of items) {
    const key = cartLineKey(item);
    const existing = grouped.get(key);
    if (existing) {
      grouped.set(key, { ...existing, qty: existing.qty + item.qty });
    } else {
      grouped.set(key, { ...item });
    }
  }
  return [...grouped.values()];
}
const SHOP_STORAGE_KEY = "sweetdrip-shop";
const SHOP_SYNC_CHANNEL = "sweetdrip-shop-sync";
function notifyNewOrder(order) {
  if (typeof window === "undefined") return;
  try {
    new BroadcastChannel(SHOP_SYNC_CHANNEL).postMessage({ type: "new-order", orderId: order.id });
  } catch {
  }
}
function notifyNewLargeOrder(request) {
  if (typeof window === "undefined") return;
  try {
    new BroadcastChannel(SHOP_SYNC_CHANNEL).postMessage({ type: "new-large-order", requestId: request.id });
  } catch {
  }
}
function initShopSync() {
  if (typeof window === "undefined") return;
  const flag = "__sweetdripShopSyncInit";
  if (window[flag]) return;
  window[flag] = true;
  const rehydrate = () => {
    void useShop.persist.rehydrate();
  };
  window.addEventListener("storage", (event) => {
    if (event.key === SHOP_STORAGE_KEY) rehydrate();
  });
  try {
    const channel = new BroadcastChannel(SHOP_SYNC_CHANNEL);
    channel.onmessage = (event) => {
      if (event.data?.type === "new-order" || event.data?.type === "new-large-order") rehydrate();
    };
  } catch {
  }
}
const useShop = create()(
  persist(
    (set, get) => ({
      categories: seedCategories,
      products: seedProducts,
      offers: seedOffers,
      orders: [],
      largeOrders: [],
      hero: seedHero,
      taxRatePercent: 10.25,
      offersSectionVisible: true,
      addCategory: (c) => set({
        categories: [...get().categories, { ...c, id: id(), visible: c.visible ?? true }]
      }),
      updateCategory: (cid, c) => set({ categories: get().categories.map((x) => x.id === cid ? { ...x, ...c } : x) }),
      deleteCategory: (cid) => set({ categories: get().categories.filter((x) => x.id !== cid), products: get().products.filter((p) => p.categoryId !== cid) }),
      addProduct: (p) => set({ products: [...get().products, { ...p, id: id() }] }),
      updateProduct: (pid, p) => set({ products: get().products.map((x) => x.id === pid ? { ...x, ...p } : x) }),
      deleteProduct: (pid) => set({ products: get().products.filter((x) => x.id !== pid) }),
      addOffer: (o) => set({ offers: [...get().offers, { ...o, id: id() }] }),
      updateOffer: (oid, o) => set({ offers: get().offers.map((x) => x.id === oid ? { ...x, ...o } : x) }),
      deleteOffer: (oid) => set({ offers: get().offers.filter((x) => x.id !== oid) }),
      addOrder: (o) => {
        const order = {
          ...o,
          items: groupCartItems(o.items.map((item) => ({ ...item }))),
          customer: { ...o.customer },
          id: "SD-" + Date.now().toString().slice(-6),
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          status: "new"
        };
        set({ orders: [order, ...get().orders] });
        notifyNewOrder(order);
        return order;
      },
      updateOrderStatus: (oid, s) => set({ orders: get().orders.map((x) => x.id === oid ? { ...x, status: s } : x) }),
      addLargeOrder: (o) => {
        const request = {
          ...o,
          id: "LO-" + Date.now().toString().slice(-6),
          createdAt: (/* @__PURE__ */ new Date()).toISOString(),
          status: "new"
        };
        set({ largeOrders: [request, ...get().largeOrders] });
        notifyNewLargeOrder(request);
        return request;
      },
      updateLargeOrderStatus: (id2, s) => set({ largeOrders: get().largeOrders.map((x) => x.id === id2 ? { ...x, status: s } : x) }),
      setHero: (h) => {
        const current = get().hero;
        set({
          hero: {
            ...current,
            ...h,
            backgroundSlides: h.backgroundSlides ? normalizeBackgroundSlides(h.backgroundSlides) : normalizeBackgroundSlides(current.backgroundSlides),
            floatingImages: h.floatingImages ? normalizeFloatingImages(h.floatingImages) : normalizeFloatingImages(current.floatingImages)
          }
        });
      },
      setTaxRatePercent: (rate) => set({ taxRatePercent: normalizeTaxRate(rate) }),
      setOffersSectionVisible: (visible) => set({ offersSectionVisible: visible })
    }),
    {
      name: SHOP_STORAGE_KEY,
      merge: (persisted, current) => {
        const state = { ...current, ...persisted };
        const persistedHero = persisted?.hero;
        state.hero = {
          ...seedHero,
          ...current.hero,
          ...persistedHero,
          backgroundSlides: normalizeBackgroundSlides(
            persistedHero?.backgroundSlides ?? current.hero.backgroundSlides
          ),
          floatingImages: normalizeFloatingImages(
            persistedHero?.floatingImages ?? current.hero.floatingImages
          )
        };
        state.largeOrders = persisted?.largeOrders ?? current.largeOrders ?? [];
        state.taxRatePercent = normalizeTaxRate(
          persisted?.taxRatePercent ?? current.taxRatePercent
        );
        state.orders = (state.orders ?? []).map((o) => ({
          ...o,
          tax: o.tax ?? Math.max(0, +(o.total - o.subtotal - o.tip).toFixed(2))
        }));
        return state;
      }
    }
  )
);
const useAdmin = create()(
  persist(
    (set, get) => ({
      isAdmin: false,
      username: DEFAULT_ADMIN_USERNAME,
      password: DEFAULT_ADMIN_PASSWORD,
      setAdmin: (v) => set({ isAdmin: v }),
      login: (username, password) => {
        const state = get();
        if (username === state.username && password === state.password) {
          set({ isAdmin: true });
          return true;
        }
        return false;
      },
      updateCredentials: ({ username, password, currentPassword }) => {
        const state = get();
        if (currentPassword !== state.password) {
          return { ok: false, error: "Current password is incorrect" };
        }
        const nextUsername = username.trim();
        const nextPassword = password.trim();
        if (!nextUsername) {
          return { ok: false, error: "Username is required" };
        }
        if (nextPassword.length < 6) {
          return { ok: false, error: "Password must be at least 6 characters" };
        }
        set({ username: nextUsername, password: nextPassword });
        return { ok: true };
      }
    }),
    {
      name: "sweetdrip-admin",
      merge: (persisted, current) => {
        const saved = persisted;
        return {
          ...current,
          ...saved,
          username: saved.username ?? DEFAULT_ADMIN_USERNAME,
          password: saved.password ?? DEFAULT_ADMIN_PASSWORD
        };
      }
    }
  )
);
const useCart = create()(
  persist(
    (set, get) => ({
      items: [],
      tip: 0,
      lastOrderId: null,
      drawerOpen: false,
      add: (i) => {
        const items = get().items;
        const incoming = { ...i, qty: i.qty || 1 };
        const match = items.find((x) => cartLineKey(x) === cartLineKey(incoming));
        if (match) {
          set({
            items: items.map(
              (x) => x.uid === match.uid ? { ...x, qty: x.qty + incoming.qty } : x
            ),
            drawerOpen: true
          });
          return;
        }
        set({ items: [...items, { ...incoming, uid: id() }], drawerOpen: true });
      },
      remove: (uid) => set({ items: get().items.filter((x) => x.uid !== uid) }),
      setQty: (uid, qty) => set({ items: get().items.map((x) => x.uid === uid ? { ...x, qty: Math.max(1, qty) } : x) }),
      setTip: (tip) => set({ tip: Math.max(0, Math.round((Number(tip) || 0) * 100) / 100) }),
      clear: () => set({ items: [], tip: 0 }),
      setLastOrderId: (id2) => set({ lastOrderId: id2 }),
      setDrawerOpen: (open) => set({ drawerOpen: open })
    }),
    {
      name: "sweetdrip-cart",
      partialize: (state) => ({
        items: state.items,
        tip: state.tip,
        lastOrderId: state.lastOrderId
      })
    }
  )
);
const fmt = (n) => "$" + n.toFixed(2);
export {
  FLOAT_IMAGE_COUNT as F,
  HERO_SLIDE_COUNT as H,
  useCart as a,
  useAdmin as b,
  calcOrderTotal as c,
  normalizeFloatingImages as d,
  normalizeBackgroundSlides as e,
  fmt as f,
  groupCartItems as g,
  activeBackgroundSlides as h,
  initShopSync as i,
  heroDessert as j,
  float1 as k,
  float2 as l,
  float3 as m,
  normalizeTaxRate as n,
  aboutCafe as o,
  useShop as u
};
