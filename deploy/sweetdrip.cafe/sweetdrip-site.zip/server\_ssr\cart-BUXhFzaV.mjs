import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { r as reactExports } from "../_libs/react.mjs";
import { a as useCart } from "./store-C3jzrryZ.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
function CartRedirect() {
  const setDrawerOpen = useCart((s) => s.setDrawerOpen);
  const navigate = useNavigate();
  reactExports.useEffect(() => {
    setDrawerOpen(true);
    navigate({
      to: "/menu",
      replace: true
    });
  }, [navigate, setDrawerOpen]);
  return null;
}
export {
  CartRedirect as component
};
