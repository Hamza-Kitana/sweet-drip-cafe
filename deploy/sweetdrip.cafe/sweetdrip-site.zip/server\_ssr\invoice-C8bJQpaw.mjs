import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { a as useCart, u as useShop, g as groupCartItems, f as fmt } from "./store-C3jzrryZ.mjs";
import { c as isApiMode, f as fetchOrder, B as Button } from "./router-CypnlrKc.mjs";
import "../_libs/sonner.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { f as Check, g as Printer, a as MapPin, P as Phone } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/zod.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function InvoicePage() {
  const lastOrderId = useCart((s) => s.lastOrderId);
  const orders = useShop((s) => s.orders);
  const [fetchedOrder, setFetchedOrder] = reactExports.useState(null);
  const order = orders.find((o) => o.id === lastOrderId) ?? fetchedOrder;
  const invoiceItems = order ? groupCartItems(order.items) : [];
  reactExports.useEffect(() => {
    if (!isApiMode || !lastOrderId || orders.some((o) => o.id === lastOrderId)) return;
    void fetchOrder().then(setFetchedOrder).catch(() => setFetchedOrder(null));
  }, [lastOrderId, orders]);
  if (!order) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-20 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "No recent order found." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", className: "text-primary underline", children: "Browse menu" })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-12 max-w-3xl mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { initial: {
      scale: 0
    }, animate: {
      scale: 1
    }, transition: {
      type: "spring",
      delay: 0.1
    }, className: "mx-auto w-20 h-20 rounded-full gradient-gold flex items-center justify-center text-primary shadow-glow", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-9 h-9", strokeWidth: 3 }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "mt-6 text-4xl font-display text-center text-primary", children: [
      "Thank you, ",
      order.customer.name.split(" ")[0],
      "!"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-muted-foreground mt-2", children: "Save this invoice — please present it when you arrive." }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 rounded-3xl bg-card border shadow-glow overflow-hidden print:shadow-none", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "gradient-choco text-primary-foreground p-6 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-widest opacity-80", children: "Invoice" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-2xl font-display", children: [
            "#",
            order.id
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right text-sm opacity-90", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: new Date(order.createdAt).toLocaleString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "capitalize", children: order.paymentStatus === "paid" ? "paid" : order.status })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 grid sm:grid-cols-2 gap-4 text-sm border-b", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Customer" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "font-semibold", children: order.customer.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: order.customer.email }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: order.customer.phone })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "Reservation" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
            order.customer.date,
            " · ",
            order.customer.time
          ] }),
          order.customer.guests != null && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { children: [
            "Guests: ",
            order.customer.guests
          ] }),
          order.customer.message && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "italic mt-1", children: [
            "“",
            order.customer.message,
            "”"
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "text-muted-foreground text-left", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "py-2", children: "Item" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { children: "Qty" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "text-right", children: "Total" })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { children: invoiceItems.map((i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { className: "border-t", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "py-2", children: [
              i.name,
              i.noteChoice && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: i.noteChoice }),
              i.note && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground italic", children: [
                "“",
                i.note,
                "”"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { children: i.qty }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "text-right", children: fmt(i.price * i.qty) })
          ] }, i.uid)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-4 space-y-1 text-sm border-t pt-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Subtotal", value: fmt(order.subtotal) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Tip", value: fmt(order.tip) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: order.taxRate != null ? `Tax (${order.taxRate}%)` : "Tax", value: fmt(order.tax ?? Math.max(0, order.total - order.subtotal - order.tip)) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Row, { label: "Total", value: fmt(order.total), bold: true })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex flex-wrap gap-3 justify-center print:hidden", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => window.print(), variant: "outline", className: "rounded-full", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Printer, { className: "mr-2 h-4 w-4" }),
        " Print"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { asChild: true, className: "rounded-full gradient-choco text-primary-foreground", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", children: "Order again" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-10 text-center text-sm text-muted-foreground print:mt-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center justify-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "h-4 w-4" }),
        " Sweet Drip Dessert Cafe"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "flex items-center justify-center gap-2 mt-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Phone, { className: "h-4 w-4" }),
        " Present this invoice at pickup"
      ] })
    ] })
  ] });
}
function Row({
  label,
  value,
  bold
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex justify-between ${bold ? "font-display text-lg text-primary pt-2" : ""}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: value })
  ] });
}
export {
  InvoicePage as component
};
