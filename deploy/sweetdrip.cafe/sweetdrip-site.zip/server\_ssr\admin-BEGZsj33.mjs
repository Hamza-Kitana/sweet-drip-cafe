import { j as jsxRuntimeExports, r as reactExports } from "../_libs/react.mjs";
import { N as Navigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { b as useAdmin, u as useShop, i as initShopSync, f as fmt, g as groupCartItems, d as normalizeFloatingImages, e as normalizeBackgroundSlides, H as HERO_SLIDE_COUNT, F as FLOAT_IMAGE_COUNT, n as normalizeTaxRate } from "./store-C3jzrryZ.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { c as isApiMode, l as hydrateShopFromApi, r as refreshAdminDataFromApi, B as Button, D as setAdminToken, L as Label, I as Input, E as isCategoryVisible, F as updateAdminCredentials, e as cn, u as updateOrderStatusApi, j as updateCateringStatusApi, k as updateCategory, m as deleteCategoryApi, n as deleteProductApi, G as Dialog, H as DialogContent, J as DialogHeader, K as DialogTitle, o as updateProduct, p as createProduct, q as saveOffersVisible, t as updateOffer, w as deleteOfferApi, x as createOffer, y as saveTaxRate, z as createCategory, A as saveHero } from "./router-CypnlrKc.mjs";
import { T as Textarea } from "./textarea-G8B6rCe0.mjs";
import { R as Root2, V as Value, T as Trigger, I as Icon, P as Portal, C as Content2, a as Viewport, b as Item, c as ItemIndicator, d as ItemText, S as ScrollUpButton, e as ScrollDownButton, L as Label$1, f as Separator } from "../_libs/radix-ui__react-select.mjs";
import { R as Root, T as Thumb } from "../_libs/radix-ui__react-switch.mjs";
import { H as House, R as Receipt, n as UtensilsCrossed, o as Package, p as Tag, q as Layers, r as Settings, s as LogOut, t as CalendarDays, u as Search, X, e as Plus, E as Eye, v as EyeOff, w as Image, T as Trash2, x as Pencil, y as Percent, K as KeyRound, j as ChevronDown, f as Check, z as Upload, A as ImagePlus, B as ChevronUp } from "../_libs/lucide-react.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/framer-motion.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
import "../_libs/zod.mjs";
import "../_libs/radix-ui__number.mjs";
import "../_libs/radix-ui__react-collection.mjs";
import "../_libs/radix-ui__react-direction.mjs";
import "../_libs/radix-ui__react-popper.mjs";
import "../_libs/floating-ui__react-dom.mjs";
import "../_libs/floating-ui__dom.mjs";
import "../_libs/floating-ui__core.mjs";
import "../_libs/floating-ui__utils.mjs";
import "../_libs/radix-ui__react-arrow.mjs";
import "../_libs/radix-ui__react-use-size.mjs";
import "../_libs/radix-ui__react-use-previous.mjs";
import "../_libs/@radix-ui/react-visually-hidden+[...].mjs";
function AdminGuard({ children }) {
  const { isAdmin } = useAdmin();
  if (!isAdmin) return /* @__PURE__ */ jsxRuntimeExports.jsx(Navigate, { to: "/" });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children });
}
const MAX_BYTES = 3 * 1024 * 1024;
function readImageAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Please choose an image file (JPG, PNG, WebP…)"));
      return;
    }
    if (file.size > MAX_BYTES) {
      reject(new Error("Image must be under 3 MB"));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read image"));
    reader.readAsDataURL(file);
  });
}
function ImageDropzone({
  value,
  onChange,
  onClear,
  hint = "Drag & drop or click to upload",
  className,
  previewClassName = "aspect-video"
}) {
  const inputRef = reactExports.useRef(null);
  const [dragging, setDragging] = reactExports.useState(false);
  const pickFile = async (file) => {
    if (!file) return;
    try {
      onChange(await readImageAsDataUrl(file));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed");
    }
  };
  const onDrop = (event) => {
    event.preventDefault();
    setDragging(false);
    void pickFile(event.dataTransfer.files[0]);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      role: "button",
      tabIndex: 0,
      onClick: () => inputRef.current?.click(),
      onKeyDown: (e) => e.key === "Enter" && inputRef.current?.click(),
      onDragOver: (e) => {
        e.preventDefault();
        setDragging(true);
      },
      onDragLeave: () => setDragging(false),
      onDrop,
      className: cn(
        "relative overflow-hidden rounded-2xl border-2 border-dashed transition",
        dragging ? "border-accent bg-accent/10" : "border-border bg-muted/30 hover:border-accent/50 hover:bg-muted/50",
        value ? "p-2" : "flex min-h-[120px] cursor-pointer flex-col items-center justify-center gap-2 p-4 text-center"
      ),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            ref: inputRef,
            type: "file",
            accept: "image/*",
            className: "sr-only",
            onChange: (e) => {
              void pickFile(e.target.files?.[0]);
              e.target.value = "";
            }
          }
        ),
        value ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: value, alt: "", className: cn("w-full rounded-xl object-cover", previewClassName) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-0 flex items-center justify-center gap-2 rounded-2xl bg-primary/0 opacity-0 transition hover:bg-primary/40 hover:opacity-100", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "inline-flex items-center gap-1.5 rounded-full bg-background/90 px-3 py-1.5 text-xs font-medium text-primary", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Upload, { className: "h-3.5 w-3.5" }),
            " Replace"
          ] }) }),
          onClear && /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: (e) => {
                e.stopPropagation();
                onClear();
              },
              className: "absolute right-3 top-3 flex h-8 w-8 items-center justify-center rounded-full bg-background/90 text-primary shadow-sm transition hover:bg-destructive hover:text-destructive-foreground",
              "aria-label": "Remove image",
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" })
            }
          )
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ImagePlus, { className: "h-8 w-8 text-muted-foreground" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground", children: hint })
        ] })
      ]
    }
  ) });
}
const Select = Root2;
const SelectValue = Value;
const SelectTrigger = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
  Trigger,
  {
    ref,
    className: cn(
      "flex h-9 w-full items-center justify-between whitespace-nowrap rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm ring-offset-background cursor-pointer data-[placeholder]:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-ring disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1",
      className
    ),
    ...props,
    children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4 opacity-50" }) })
    ]
  }
));
SelectTrigger.displayName = Trigger.displayName;
const SelectScrollUpButton = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  ScrollUpButton,
  {
    ref,
    className: cn("flex cursor-default items-center justify-center py-1", className),
    ...props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "h-4 w-4" })
  }
));
SelectScrollUpButton.displayName = ScrollUpButton.displayName;
const SelectScrollDownButton = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  ScrollDownButton,
  {
    ref,
    className: cn("flex cursor-default items-center justify-center py-1", className),
    ...props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "h-4 w-4" })
  }
));
SelectScrollDownButton.displayName = ScrollDownButton.displayName;
const SelectContent = reactExports.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(Portal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
  Content2,
  {
    ref,
    className: cn(
      "relative z-50 max-h-(--radix-select-content-available-height) min-w-[8rem] overflow-y-auto overflow-x-hidden rounded-md border bg-popover text-popover-foreground shadow-md data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-select-content-transform-origin)",
      position === "popper" && "data-[side=bottom]:translate-y-1 data-[side=left]:-translate-x-1 data-[side=right]:translate-x-1 data-[side=top]:-translate-y-1",
      className
    ),
    position,
    ...props,
    children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SelectScrollUpButton, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Viewport,
        {
          className: cn(
            "p-1",
            position === "popper" && "h-[var(--radix-select-trigger-height)] w-full min-w-[var(--radix-select-trigger-width)]"
          ),
          children
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SelectScrollDownButton, {})
    ]
  }
) }));
SelectContent.displayName = Content2.displayName;
const SelectLabel = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Label$1,
  {
    ref,
    className: cn("px-2 py-1.5 text-sm font-semibold", className),
    ...props
  }
));
SelectLabel.displayName = Label$1.displayName;
const SelectItem = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
  Item,
  {
    ref,
    className: cn(
      "relative flex w-full cursor-default select-none items-center rounded-sm py-1.5 pl-2 pr-8 text-sm outline-none focus:bg-accent focus:text-accent-foreground data-[disabled]:pointer-events-none data-[disabled]:opacity-50",
      className
    ),
    ...props,
    children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute right-2 flex h-3.5 w-3.5 items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ItemIndicator, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "h-4 w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ItemText, { children })
    ]
  }
));
SelectItem.displayName = Item.displayName;
const SelectSeparator = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Separator,
  {
    ref,
    className: cn("-mx-1 my-1 h-px bg-muted", className),
    ...props
  }
));
SelectSeparator.displayName = Separator.displayName;
const Switch = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Root,
  {
    className: cn(
      "peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input",
      className
    ),
    ...props,
    ref,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Thumb,
      {
        className: cn(
          "pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0"
        )
      }
    )
  }
));
Switch.displayName = Root.displayName;
const ANALYTICS_RANGE_OPTIONS = [
  { value: "today", label: "Today" },
  { value: "yesterday", label: "Yesterday" },
  { value: "7d", label: "Last 7 days" },
  { value: "30d", label: "Last 30 days" },
  { value: "all", label: "All time" }
];
function toDayKey(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}
function getTodayKey() {
  return toDayKey(/* @__PURE__ */ new Date());
}
function getYesterdayKey() {
  const d = /* @__PURE__ */ new Date();
  d.setDate(d.getDate() - 1);
  return toDayKey(d);
}
function getOrderDayKey(createdAt) {
  return toDayKey(new Date(createdAt));
}
function formatDayLabel(dayKey) {
  const today = getTodayKey();
  const yesterday = getYesterdayKey();
  if (dayKey === today) return "Today";
  if (dayKey === yesterday) return "Yesterday";
  const [y, m, d] = dayKey.split("-").map(Number);
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString(void 0, {
    weekday: "short",
    month: "short",
    day: "numeric",
    ...y !== (/* @__PURE__ */ new Date()).getFullYear() ? { year: "numeric" } : {}
  });
}
function getDistinctOrderDays(orders) {
  const keys = new Set(orders.map((o) => getOrderDayKey(o.createdAt)));
  return [...keys].sort((a, b) => b.localeCompare(a));
}
function buildOrderDayOptions(orders) {
  const today = getTodayKey();
  const yesterday = getYesterdayKey();
  const options = [
    { value: "today", label: "Today" },
    { value: "yesterday", label: "Yesterday" }
  ];
  for (const day of getDistinctOrderDays(orders)) {
    if (day === today || day === yesterday) continue;
    options.push({ value: day, label: formatDayLabel(day) });
  }
  options.push({ value: "all", label: "All days" });
  return options;
}
function resolveOrderDayFilter(filter) {
  if (filter === "all") return "all";
  if (filter === "today") return getTodayKey();
  if (filter === "yesterday") return getYesterdayKey();
  return filter;
}
function filterOrdersByDay(orders, filter) {
  const resolved = resolveOrderDayFilter(filter);
  const filtered = resolved === "all" ? [...orders] : orders.filter((o) => getOrderDayKey(o.createdAt) === resolved);
  return filtered.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}
function filterOrdersByAnalyticsRange(orders, range) {
  const today = getTodayKey();
  const yesterday = getYesterdayKey();
  const now = Date.now();
  const filtered = orders.filter((o) => {
    const dayKey = getOrderDayKey(o.createdAt);
    if (range === "all") return true;
    if (range === "today") return dayKey === today;
    if (range === "yesterday") return dayKey === yesterday;
    const ageMs = now - new Date(o.createdAt).getTime();
    const maxMs = range === "7d" ? 7 * 864e5 : 30 * 864e5;
    return ageMs >= 0 && ageMs <= maxMs;
  });
  return filtered.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}
function orderAnalytics(orders) {
  const revenue = orders.reduce((s, o) => s + o.total, 0);
  const count = orders.length;
  const newCount = orders.filter((o) => o.status === "new").length;
  const doneCount = orders.filter((o) => o.status === "done").length;
  const avg = count > 0 ? revenue / count : 0;
  return { revenue, count, newCount, doneCount, avg };
}
async function saveTaxRateToApi(taxRatePercent) {
  if (!isApiMode) {
    useShop.getState().setTaxRatePercent(taxRatePercent);
    return;
  }
  await saveTaxRate(taxRatePercent);
  await hydrateShopFromApi();
}
async function saveOffersVisibleToApi(visible) {
  if (!isApiMode) {
    useShop.getState().setOffersSectionVisible(visible);
    return;
  }
  await saveOffersVisible(visible);
  await hydrateShopFromApi();
}
async function saveHeroToApi(hero) {
  if (!isApiMode) {
    useShop.getState().setHero(hero);
    return;
  }
  await saveHero(hero);
  await hydrateShopFromApi();
}
async function patchCategory(id, data) {
  if (!isApiMode) {
    useShop.getState().updateCategory(id, data);
    return;
  }
  const category = useShop.getState().categories.find((c) => c.id === id);
  if (!category) return;
  await updateCategory({ ...category, ...data });
  await hydrateShopFromApi();
}
async function saveCategory(editing, data) {
  if (!isApiMode) {
    useShop.getState().addCategory(data);
    return;
  }
  {
    await createCategory(data);
  }
  await hydrateShopFromApi();
}
async function removeCategory(id) {
  if (!isApiMode) {
    useShop.getState().deleteCategory(id);
    return;
  }
  await deleteCategoryApi(id);
  await hydrateShopFromApi();
}
async function saveProduct(editing, data) {
  if (!isApiMode) {
    if (editing) useShop.getState().updateProduct(editing.id, data);
    else useShop.getState().addProduct(data);
    return;
  }
  if (editing) {
    await updateProduct({ ...editing, ...data });
  } else {
    await createProduct(data);
  }
  await hydrateShopFromApi();
}
async function removeProduct(id) {
  if (!isApiMode) {
    useShop.getState().deleteProduct(id);
    return;
  }
  await deleteProductApi(id);
  await hydrateShopFromApi();
}
async function saveOffer(editing, data) {
  if (!isApiMode) {
    if (editing) useShop.getState().updateOffer(editing.id, data);
    else useShop.getState().addOffer(data);
    return;
  }
  if (editing) {
    await updateOffer({ ...editing, ...data });
  } else {
    await createOffer(data);
  }
  await hydrateShopFromApi();
}
async function patchOffer(id, data) {
  if (!isApiMode) {
    useShop.getState().updateOffer(id, data);
    return;
  }
  const offer = useShop.getState().offers.find((o) => o.id === id);
  if (!offer) return;
  await updateOffer({ ...offer, ...data });
  await hydrateShopFromApi();
}
async function removeOffer(id) {
  if (!isApiMode) {
    useShop.getState().deleteOffer(id);
    return;
  }
  await deleteOfferApi(id);
  await hydrateShopFromApi();
}
async function patchOrderStatus(orderId, status) {
  if (!isApiMode) {
    useShop.getState().updateOrderStatus(orderId, status);
    return;
  }
  await updateOrderStatusApi(orderId, status);
  await refreshAdminDataFromApi();
}
async function patchCateringStatus(id, status) {
  if (!isApiMode) {
    useShop.getState().updateLargeOrderStatus(id, status);
    return;
  }
  await updateCateringStatusApi(id, status);
  await refreshAdminDataFromApi();
}
function Dashboard() {
  const {
    setAdmin
  } = useAdmin();
  const isAdmin = useAdmin((s) => s.isAdmin);
  const orders = useShop((s) => s.orders);
  const largeOrders = useShop((s) => s.largeOrders);
  const newOrderCount = orders.filter((o) => o.status === "new").length;
  const newCateringCount = largeOrders.filter((o) => o.status === "new").length;
  const [tab, setTab] = reactExports.useState("overview");
  const lastSeenOrderId = reactExports.useRef(null);
  const lastSeenCateringId = reactExports.useRef(null);
  reactExports.useEffect(() => {
    initShopSync();
    if (isApiMode) {
      void hydrateShopFromApi();
      if (isAdmin) void refreshAdminDataFromApi();
    }
  }, [isAdmin]);
  reactExports.useEffect(() => {
    if (!isAdmin) return;
    const latest = orders[0];
    if (!latest) {
      lastSeenOrderId.current = null;
      return;
    }
    if (lastSeenOrderId.current === null) {
      lastSeenOrderId.current = latest.id;
      return;
    }
    if (latest.id !== lastSeenOrderId.current && latest.status === "new") {
      lastSeenOrderId.current = latest.id;
      toast.success(`New order #${latest.id} · ${latest.customer.name}`, {
        description: `${fmt(latest.total)} · ${latest.customer.date} ${latest.customer.time}`
      });
      setTab("orders");
    }
  }, [isAdmin, orders]);
  reactExports.useEffect(() => {
    if (!isAdmin) return;
    const latest = largeOrders[0];
    if (!latest) {
      lastSeenCateringId.current = null;
      return;
    }
    if (lastSeenCateringId.current === null) {
      lastSeenCateringId.current = latest.id;
      return;
    }
    if (latest.id !== lastSeenCateringId.current && latest.status === "new") {
      lastSeenCateringId.current = latest.id;
      toast.success(`New catering request #${latest.id} · ${latest.name}`, {
        description: `${latest.date} ${latest.time} · ${latest.guests} guests`
      });
      setTab("catering");
    }
  }, [isAdmin, largeOrders]);
  const NAV = [{
    id: "overview",
    label: "Overview",
    icon: House
  }, {
    id: "orders",
    label: "Orders",
    icon: Receipt
  }, {
    id: "catering",
    label: "Catering",
    icon: UtensilsCrossed
  }, {
    id: "products",
    label: "Products",
    icon: Package
  }, {
    id: "offers",
    label: "Offers",
    icon: Tag
  }, {
    id: "site",
    label: "Site",
    icon: Layers
  }, {
    id: "settings",
    label: "Settings",
    icon: Settings
  }];
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid lg:grid-cols-[minmax(17rem,280px)_1fr] gap-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("aside", { className: "lg:sticky lg:top-28 lg:max-h-[calc(100svh-8rem)] lg:overflow-y-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "admin-sidebar rounded-3xl p-5 shadow-soft", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-3 text-xs uppercase tracking-widest text-[var(--footer-muted)]", children: "Admin" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("nav", { className: "space-y-1", children: NAV.map((n) => /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => setTab(n.id), className: `w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm transition ${tab === n.id ? "bg-sidebar-primary text-sidebar-primary-foreground shadow-sm" : "text-[var(--footer-muted)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"}`, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(n.icon, { className: "w-4 h-4" }),
        " ",
        n.label,
        n.id === "orders" && newOrderCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1.5 text-[10px] font-bold text-primary", children: newOrderCount }),
        n.id === "catering" && newCateringCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-accent px-1.5 text-[10px] font-bold text-primary", children: newCateringCount })
      ] }, n.id)) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { variant: "outline", className: "mt-4 w-full border-sidebar-border bg-transparent text-[var(--footer-muted)] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground", onClick: () => {
        setAdminToken(null);
        setAdmin(false);
        toast.success("Signed out");
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "w-4 h-4 mr-2" }),
        "Sign out"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/", className: "mt-3 block text-center text-xs text-[var(--footer-muted)] transition hover:text-[var(--footer-fg)]", children: "View site →" })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("main", { className: "min-w-0", children: [
      tab === "overview" && /* @__PURE__ */ jsxRuntimeExports.jsx(Overview, {}),
      tab === "orders" && /* @__PURE__ */ jsxRuntimeExports.jsx(OrdersPanel, {}),
      tab === "catering" && /* @__PURE__ */ jsxRuntimeExports.jsx(CateringPanel, {}),
      tab === "products" && /* @__PURE__ */ jsxRuntimeExports.jsx(ProductsPanel, {}),
      tab === "offers" && /* @__PURE__ */ jsxRuntimeExports.jsx(OffersPanel, {}),
      tab === "site" && /* @__PURE__ */ jsxRuntimeExports.jsx(SitePanel, {}),
      tab === "settings" && /* @__PURE__ */ jsxRuntimeExports.jsx(SettingsPanel, {})
    ] })
  ] }) });
}
function SettingsPanel() {
  const {
    taxRatePercent
  } = useShop();
  const {
    username,
    updateCredentials
  } = useAdmin();
  const [taxRate, setTaxRate] = reactExports.useState(String(taxRatePercent));
  const [account, setAccount] = reactExports.useState({
    username,
    password: "",
    confirm: "",
    currentPassword: ""
  });
  reactExports.useEffect(() => {
    setAccount((a) => ({
      ...a,
      username
    }));
  }, [username]);
  reactExports.useEffect(() => {
    setTaxRate(String(taxRatePercent));
  }, [taxRatePercent]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "max-w-3xl space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Percent, { className: "h-5 w-5 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl text-primary", children: "Sales tax" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-4 text-sm text-muted-foreground", children: "Tax is calculated on subtotal + tip at checkout and shown in the order summary." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Tax rate (%)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", min: 0, max: 100, step: 0.01, value: taxRate, onChange: (e) => setTaxRate(e.target.value), placeholder: "10.25", className: "max-w-xs" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "mt-4 rounded-full", onClick: async () => {
        const parsed = normalizeTaxRate(parseFloat(taxRate));
        try {
          await saveTaxRateToApi(parsed);
          setTaxRate(String(parsed));
          toast.success(`Tax rate set to ${parsed}%`);
        } catch (err) {
          toast.error(err instanceof Error ? err.message : "Could not save tax rate");
        }
      }, children: "Save tax rate" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(KeyRound, { className: "h-5 w-5 text-primary" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl text-primary", children: "Admin login" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-4 text-sm text-muted-foreground", children: "Change dashboard username and password. Current password is required to save changes." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Username", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: account.username, onChange: (e) => setAccount({
          ...account,
          username: e.target.value
        }), autoComplete: "username" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Current password *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: account.currentPassword, onChange: (e) => setAccount({
          ...account,
          currentPassword: e.target.value
        }), autoComplete: "current-password" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "New password *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: account.password, onChange: (e) => setAccount({
          ...account,
          password: e.target.value
        }), autoComplete: "new-password" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Confirm password *", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "password", value: account.confirm, onChange: (e) => setAccount({
          ...account,
          confirm: e.target.value
        }), autoComplete: "new-password" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "mt-4 rounded-full", onClick: async () => {
        if (account.password !== account.confirm) {
          toast.error("New passwords do not match");
          return;
        }
        try {
          if (isApiMode) {
            await updateAdminCredentials({
              username: account.username,
              password: account.password,
              currentPassword: account.currentPassword
            });
          } else {
            const result = updateCredentials({
              username: account.username,
              password: account.password,
              currentPassword: account.currentPassword
            });
            if (!result.ok) {
              toast.error(result.error);
              return;
            }
          }
          toast.success("Admin login updated");
          setAccount({
            username: account.username,
            password: "",
            confirm: "",
            currentPassword: ""
          });
        } catch (err) {
          toast.error(err instanceof Error ? err.message : "Could not update credentials");
        }
      }, children: "Save admin login" })
    ] })
  ] });
}
function Card({
  children,
  className = ""
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-3xl bg-card border shadow-soft p-6 ${className}`, children });
}
function StatCard({
  label,
  value
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "border-[oklch(0.72_0.09_350/0.28)] bg-gradient-to-br from-[oklch(0.98_0.02_350)] to-card", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-medium text-muted-foreground", children: label }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-1 text-3xl font-display text-primary", children: value })
  ] });
}
function SalesSummaryBar({
  orders
}) {
  const {
    revenue,
    count,
    newCount,
    doneCount,
    avg
  } = orderAnalytics(orders);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2 rounded-2xl border border-[oklch(0.72_0.09_350/0.22)] bg-muted/30 px-4 py-3 text-sm", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-primary", children: [
      count,
      " order",
      count === 1 ? "" : "s"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "·" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-primary", children: [
      fmt(revenue),
      " revenue"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "·" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground", children: [
      fmt(avg),
      " avg"
    ] }),
    newCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "·" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-accent", children: [
        newCount,
        " new"
      ] })
    ] }),
    doneCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground", children: "·" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground", children: [
        doneCount,
        " completed"
      ] })
    ] })
  ] });
}
function Overview() {
  const {
    orders,
    products,
    categories,
    offers
  } = useShop();
  const [range, setRange] = reactExports.useState("today");
  const filtered = reactExports.useMemo(() => filterOrdersByAnalyticsRange(orders, range), [orders, range]);
  const {
    revenue,
    count,
    newCount,
    avg
  } = orderAnalytics(filtered);
  const rangeLabel = ANALYTICS_RANGE_OPTIONS.find((o) => o.value === range)?.label ?? "Period";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-end justify-between gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-display text-primary", children: "Welcome back" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-sm text-muted-foreground", children: [
          "Sales insights for ",
          rangeLabel.toLowerCase(),
          "."
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-[200px]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-xs font-medium text-muted-foreground", children: "Analytics period" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: range, onValueChange: (v) => setRange(v), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectTrigger, { className: "rounded-xl", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CalendarDays, { className: "mr-2 h-4 w-4 shrink-0 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {})
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ANALYTICS_RANGE_OPTIONS.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.value, children: o.label }, o.value)) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(SalesSummaryBar, { orders: filtered }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground", children: "Sales" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Revenue", value: fmt(revenue) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Orders", value: count }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Avg order", value: fmt(avg) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "New pending", value: newCount }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Unpaid", value: filtered.filter((o) => o.paymentStatus && o.paymentStatus !== "paid").length })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mb-3 text-xs font-semibold uppercase tracking-[0.2em] text-muted-foreground", children: "Catalog" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-4 sm:grid-cols-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Products", value: products.length }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Categories", value: categories.length }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(StatCard, { label: "Active Offers", value: offers.filter((o) => o.active).length })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "font-display text-xl text-primary", children: [
          "Orders · ",
          rangeLabel
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-sm text-muted-foreground", children: [
          count,
          " in period"
        ] })
      ] }),
      filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "No orders in this period." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "divide-y", children: filtered.slice(0, 8).map((o) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { className: "flex flex-wrap items-center justify-between gap-2 py-3 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium", children: [
            "#",
            o.id,
            " · ",
            o.customer.name
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2 text-xs capitalize text-muted-foreground", children: o.status }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
            new Date(o.createdAt).toLocaleString(),
            " · Pickup ",
            o.customer.date,
            " ",
            o.customer.time
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-display text-lg text-primary", children: fmt(o.total) })
      ] }, o.id)) })
    ] })
  ] });
}
function paymentBadge(o) {
  if (!o.paymentStatus) return null;
  const styles = o.paymentStatus === "paid" ? "bg-emerald-500/10 text-emerald-700" : o.paymentStatus === "failed" ? "bg-destructive/10 text-destructive" : "bg-amber-500/10 text-amber-700";
  return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `mt-1 inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${styles}`, children: o.paymentStatus === "paid" ? "Paid" : o.paymentStatus === "failed" ? "Payment failed" : "Unpaid" });
}
function OrdersPanel() {
  const {
    orders
  } = useShop();
  const dayOptions = reactExports.useMemo(() => buildOrderDayOptions(orders), [orders]);
  const [dayFilter, setDayFilter] = reactExports.useState("today");
  const filtered = reactExports.useMemo(() => filterOrdersByDay(orders, dayFilter), [orders, dayFilter]);
  const {
    newCount
  } = orderAnalytics(filtered);
  const periodLabel = dayFilter === "all" ? "All days" : formatDayLabel(resolveOrderDayFilter(dayFilter));
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-start justify-between gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl text-primary", children: "Orders" }),
        newCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-sm text-accent", children: [
          newCount,
          " new order(s) in this view"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "w-full sm:w-[240px]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-xs font-medium text-muted-foreground", children: "View orders for" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: dayFilter, onValueChange: (v) => setDayFilter(v), children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(SelectTrigger, { className: "rounded-xl", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(CalendarDays, { className: "mr-2 h-4 w-4 shrink-0 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {})
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: dayOptions.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: o.value, children: o.label }, o.value)) })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-5 space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-medium text-primary", children: periodLabel }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SalesSummaryBar, { orders: filtered })
    ] }),
    filtered.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-2xl border border-dashed bg-muted/20 px-4 py-10 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-muted-foreground", children: [
        "No orders for ",
        periodLabel.toLowerCase(),
        "."
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Choose another day from the menu above." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: filtered.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `border rounded-2xl p-4 ${o.status === "new" ? "border-accent/50 bg-accent/5" : ""} ${o.paymentStatus === "failed" || o.paymentStatus === "pending" ? "border-amber-400/40" : ""}`, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap justify-between gap-2 items-start", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-semibold", children: [
            "#",
            o.id,
            " · ",
            o.customer.name
          ] }),
          paymentBadge(o),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
            new Date(o.createdAt).toLocaleString(),
            " · ",
            o.customer.phone,
            " · ",
            o.customer.email
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
            "Pickup: ",
            o.customer.date,
            " ",
            o.customer.time,
            o.customer.guests != null ? ` · ${o.customer.guests} guests` : ""
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-right", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-display text-xl", children: fmt(o.total) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: o.status, onValueChange: (v) => void patchOrderStatus(o.id, v), children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "w-36 mt-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ["new", "preparing", "ready", "done", "cancelled"].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: s, className: "capitalize", children: s }, s)) })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("ul", { className: "mt-3 text-sm text-muted-foreground", children: groupCartItems(o.items).map((i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
        "• ",
        i.qty,
        "× ",
        i.name,
        i.noteChoice ? ` (${i.noteChoice})` : ""
      ] }, i.uid)) })
    ] }, o.id)) })
  ] });
}
function CateringPanel() {
  const {
    largeOrders
  } = useShop();
  const newCount = largeOrders.filter((o) => o.status === "new").length;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex flex-wrap items-center justify-between gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl text-primary", children: "Catering" }),
        newCount > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-sm text-accent", children: [
          newCount,
          " new request(s) waiting"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-muted-foreground", children: [
        largeOrders.length,
        " total"
      ] })
    ] }),
    largeOrders.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "No catering requests yet." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: largeOrders.map((r) => /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `rounded-2xl border p-4 ${r.status === "new" ? "border-accent/50 bg-accent/5" : ""}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-start justify-between gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-semibold", children: [
          "#",
          r.id,
          " · ",
          r.name
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
          new Date(r.createdAt).toLocaleString(),
          " · ",
          r.phone,
          " · ",
          r.email
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground", children: [
          "Event: ",
          r.date,
          " ",
          r.time,
          " · ",
          r.guests,
          " guests"
        ] }),
        r.message && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-2 text-sm italic text-muted-foreground", children: [
          "“",
          r.message,
          "”"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: r.status, onValueChange: (v) => void patchCateringStatus(r.id, v), children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { className: "mt-1 w-36", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: ["new", "contacted", "done"].map((s) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: s, className: "capitalize", children: s }, s)) })
      ] })
    ] }) }, r.id)) })
  ] });
}
function productMatchesQuery(product, query) {
  const haystack = [product.name, product.description, product.notes, fmt(product.price), String(product.price)].join(" ").toLowerCase();
  return haystack.includes(query);
}
function ProductsPanel() {
  const {
    products,
    categories
  } = useShop();
  const [editing, setEditing] = reactExports.useState(null);
  const [open, setOpen] = reactExports.useState(false);
  const [activeCategoryId, setActiveCategoryId] = reactExports.useState("");
  const [sectionName, setSectionName] = reactExports.useState("");
  const [sectionImage, setSectionImage] = reactExports.useState("");
  const [search, setSearch] = reactExports.useState("");
  const query = search.trim().toLowerCase();
  const filteredSections = reactExports.useMemo(() => {
    return categories.map((cat) => {
      const sectionProducts = products.filter((p) => p.categoryId === cat.id);
      if (!query) return {
        cat,
        products: sectionProducts
      };
      const sectionMatch = cat.name.toLowerCase().includes(query);
      const matchedProducts = sectionProducts.filter((p) => productMatchesQuery(p, query));
      if (sectionMatch) return {
        cat,
        products: sectionProducts,
        sectionMatch: true
      };
      if (matchedProducts.length > 0) return {
        cat,
        products: matchedProducts,
        sectionMatch: false
      };
      return null;
    }).filter((entry) => entry !== null);
  }, [categories, products, query]);
  const resultCount = filteredSections.reduce((sum, s) => sum + s.products.length, 0);
  const startNewProduct = (categoryId) => {
    setEditing(null);
    setActiveCategoryId(categoryId);
    setOpen(true);
  };
  const startEditProduct = (p) => {
    setEditing(p);
    setActiveCategoryId(p.categoryId);
    setOpen(true);
  };
  const addSection = async () => {
    if (!sectionName.trim()) {
      toast.error("Enter a section name");
      return;
    }
    try {
      await saveCategory(null, {
        name: sectionName.trim(),
        image: sectionImage || "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=800",
        visible: true
      });
      setSectionName("");
      setSectionImage("");
      toast.success("Section added");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not add section");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl text-primary", children: "Products" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-sm text-muted-foreground", children: "Add a menu section first, then add products inside each section." }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative mt-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: search, onChange: (e) => setSearch(e.target.value), placeholder: "Search sections or products…", className: "h-11 rounded-2xl border-border/80 bg-background pl-10 pr-10" }),
        search && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => setSearch(""), className: "absolute right-2 top-1/2 flex h-7 w-7 -translate-y-1/2 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted hover:text-foreground", "aria-label": "Clear search", children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "h-4 w-4" }) })
      ] }),
      query && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 text-xs text-muted-foreground", children: filteredSections.length === 0 ? "No sections or products match your search." : `${filteredSections.length} section(s) · ${resultCount} product(s) found` }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 rounded-2xl border bg-muted/30 p-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "mb-3 text-sm font-semibold text-primary", children: "Add section" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-2 sm:grid-cols-[1fr_1fr_auto]", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Section name (e.g. Cakes)", value: sectionName, onChange: (e) => setSectionName(e.target.value) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { placeholder: "Image URL (optional)", value: sectionImage, onChange: (e) => setSectionImage(e.target.value) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: addSection, className: "gradient-choco text-primary-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "mr-1 h-4 w-4" }),
            "Add section"
          ] })
        ] })
      ] })
    ] }),
    categories.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground", children: "No sections yet. Add your first section above." }) }) : query && filteredSections.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-center text-muted-foreground", children: [
      "Nothing found for “",
      search.trim(),
      "”"
    ] }) }) : filteredSections.map(({
      cat,
      products: sectionProducts,
      sectionMatch
    }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: !isCategoryVisible(cat) ? "opacity-60" : "", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-5 flex flex-wrap items-start justify-between gap-4 border-b pb-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex min-w-0 flex-1 flex-wrap items-center gap-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-16 w-24 shrink-0 overflow-hidden rounded-xl bg-muted", children: cat.image && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: cat.image, alt: cat.name, className: "h-full w-full object-cover" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { className: "max-w-xs font-semibold", defaultValue: cat.name, onBlur: (e) => void patchCategory(cat.id, {
              name: e.target.value
            }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "mt-1 text-xs text-muted-foreground", children: [
              sectionProducts.length,
              " product(s)",
              query && !sectionMatch && " · filtered",
              !isCategoryVisible(cat) && " · Hidden on site"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-full border px-3 py-1.5", children: [
            isCategoryVisible(cat) ? /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3.5 w-3.5 text-accent" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-3.5 w-3.5 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: isCategoryVisible(cat), onCheckedChange: (v) => void patchCategory(cat.id, {
              visible: v
            }), "aria-label": `Show ${cat.name} on website` }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium", children: isCategoryVisible(cat) ? "Visible" : "Hidden" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => {
            const url = prompt("New image URL", cat.image);
            if (url) void patchCategory(cat.id, {
              image: url
            });
          }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Image, { className: "h-3 w-3" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => {
            if (confirm(`Delete "${cat.name}" and all its products?`)) void removeCategory(cat.id).catch((err) => toast.error(err instanceof Error ? err.message : "Delete failed"));
          }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3 w-3" }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: () => startNewProduct(cat.id), className: "rounded-full gradient-choco text-primary-foreground", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "mr-1 h-4 w-4" }),
          "Add product"
        ] })
      ] }),
      sectionProducts.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-muted-foreground", children: "No products in this section yet." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3", children: sectionProducts.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "overflow-hidden rounded-2xl border", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "aspect-video bg-muted", children: (p.image || cat.image) && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: p.image || cat.image, alt: p.name, className: "h-full w-full object-cover" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "truncate font-semibold", children: p.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: fmt(p.price) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-3 flex gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => startEditProduct(p), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "h-3 w-3" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => {
              if (confirm("Delete product?")) void removeProduct(p.id).catch((err) => toast.error(err instanceof Error ? err.message : "Delete failed"));
            }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "h-3 w-3" }) })
          ] })
        ] })
      ] }, p.id)) })
    ] }, cat.id)),
    /* @__PURE__ */ jsxRuntimeExports.jsx(ProductDialog, { open, onOpenChange: setOpen, editing, categories, defaultCategoryId: activeCategoryId, onSave: async (data) => {
      try {
        await saveProduct(editing, data);
        toast.success("Saved");
        setOpen(false);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not save product");
      }
    } })
  ] });
}
function categoryImage(categories, categoryId) {
  return categories.find((c) => c.id === categoryId)?.image ?? "";
}
function ProductDialog({
  open,
  onOpenChange,
  editing,
  categories,
  defaultCategoryId,
  onSave
}) {
  const initialCategoryId = editing?.categoryId ?? defaultCategoryId ?? categories[0]?.id ?? "";
  const productImageFor = (categoryId, existing) => existing?.trim() || categoryImage(categories, categoryId);
  const [f, setF] = reactExports.useState({
    name: editing?.name ?? "",
    description: editing?.description ?? "",
    price: editing?.price ?? 0,
    image: editing ? productImageFor(initialCategoryId, editing.image) : categoryImage(categories, initialCategoryId),
    categoryId: initialCategoryId,
    notes: editing?.notes ?? "Sweetness",
    noteChoices: editing?.noteChoices ?? ["Regular", "Less sugar", "No sugar"]
  });
  const [choicesText, setChoicesText] = reactExports.useState(f.noteChoices.join("\n"));
  const resetForm = () => {
    const categoryId = editing?.categoryId ?? defaultCategoryId ?? categories[0]?.id ?? "";
    setF({
      name: editing?.name ?? "",
      description: editing?.description ?? "",
      price: editing?.price ?? 0,
      image: editing ? productImageFor(categoryId, editing.image) : categoryImage(categories, categoryId),
      categoryId,
      notes: editing?.notes ?? "Sweetness",
      noteChoices: editing?.noteChoices ?? ["Regular", "Less sugar", "No sugar"]
    });
    setChoicesText((editing?.noteChoices ?? ["Regular", "Less sugar", "No sugar"]).join("\n"));
  };
  const handleCategoryChange = (nextCategoryId) => {
    const prevCategoryImage = categoryImage(categories, f.categoryId);
    const inheritsSectionImage = f.image === "" || f.image === prevCategoryImage;
    setF({
      ...f,
      categoryId: nextCategoryId,
      image: inheritsSectionImage ? categoryImage(categories, nextCategoryId) : f.image
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange: (v) => {
    onOpenChange(v);
    if (v) resetForm();
  }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-2xl max-h-[90vh] overflow-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { children: [
      editing ? "Edit" : "New",
      " product"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid sm:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Name", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.name, onChange: (e) => setF({
        ...f,
        name: e.target.value
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Price", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.01", value: f.price, onChange: (e) => setF({
        ...f,
        price: +e.target.value
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Description", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { rows: 2, value: f.description, onChange: (e) => setF({
        ...f,
        description: e.target.value
      }) }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Section", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Select, { value: f.categoryId, onValueChange: handleCategoryChange, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectTrigger, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(SelectValue, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContent, { children: categories.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectItem, { value: c.id, children: c.name }, c.id)) })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Field, { label: "Image URL", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.image, onChange: (e) => setF({
          ...f,
          image: e.target.value
        }), placeholder: categoryImage(categories, f.categoryId) || "Uses section image by default" }),
        f.image && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: f.image, alt: "", className: "mt-2 max-h-24 rounded-lg border object-cover" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Note label (e.g. Sweetness)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.notes, onChange: (e) => setF({
        ...f,
        notes: e.target.value
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Note choices (one per line)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { rows: 3, value: choicesText, onChange: (e) => setChoicesText(e.target.value) }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "w-full mt-4 rounded-full gradient-choco text-primary-foreground", onClick: () => onSave({
      ...f,
      image: (f.image ?? "").trim() || categoryImage(categories, f.categoryId),
      noteChoices: choicesText.split("\n").map((s) => s.trim()).filter(Boolean)
    }), children: "Save product" })
  ] }) });
}
function OffersPanel() {
  const {
    offers,
    offersSectionVisible
  } = useShop();
  const [open, setOpen] = reactExports.useState(false);
  const [editing, setEditing] = reactExports.useState(null);
  const startNew = () => {
    setEditing(null);
    setOpen(true);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6 flex flex-wrap items-center justify-between gap-4 rounded-2xl border bg-muted/30 p-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-primary", children: "Offers section on website" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 text-xs text-muted-foreground", children: "Hides the whole offers area (menu tab, homepage block). Individual offers can still be turned off below." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 rounded-full border px-3 py-1.5", children: [
        offersSectionVisible ? /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "h-3.5 w-3.5 text-accent" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(EyeOff, { className: "h-3.5 w-3.5 text-muted-foreground" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: offersSectionVisible, onCheckedChange: (v) => void saveOffersVisibleToApi(v).catch((err) => toast.error(err instanceof Error ? err.message : "Could not save")), "aria-label": "Show offers section on website" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium", children: offersSectionVisible ? "Visible" : "Hidden" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl text-primary", children: "Offers" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: startNew, className: "rounded-full gradient-choco text-primary-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4 mr-1" }),
        "Add offer"
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: offers.map((o) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "border rounded-2xl p-4 flex flex-wrap gap-3 items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: o.image, alt: o.title, className: "w-20 h-20 rounded-xl object-cover" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-[200px]", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-semibold", children: [
          o.title,
          " ",
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-primary", children: [
            "· ",
            fmt(o.price)
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-xs text-muted-foreground", children: o.description }),
        (o.startAt || o.endAt) && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-muted-foreground mt-1", children: [
          o.startAt || "—",
          " → ",
          o.endAt || "—"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-muted-foreground hidden sm:inline", children: o.active ? "Live" : "Off" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: o.active, onCheckedChange: (v) => void patchOffer(o.id, {
          active: v
        }).catch((err) => toast.error(err instanceof Error ? err.message : "Could not save")), "aria-label": `${o.active ? "Disable" : "Enable"} ${o.title}` }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => {
          setEditing(o);
          setOpen(true);
        }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Pencil, { className: "w-3 h-3" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { size: "sm", variant: "outline", onClick: () => {
          if (confirm("Delete?")) void removeOffer(o.id).catch((err) => toast.error(err instanceof Error ? err.message : "Delete failed"));
        }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3 h-3" }) })
      ] })
    ] }, o.id)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(OfferDialog, { open, onOpenChange: setOpen, editing, onSave: async (d) => {
      try {
        await saveOffer(editing, d);
        toast.success("Saved");
        setOpen(false);
      } catch (err) {
        toast.error(err instanceof Error ? err.message : "Could not save offer");
      }
    } })
  ] });
}
function OfferDialog({
  open,
  onOpenChange,
  editing,
  onSave
}) {
  const {
    products
  } = useShop();
  const [f, setF] = reactExports.useState({
    title: "",
    description: "",
    price: 0,
    image: "",
    productIds: [],
    active: true,
    startAt: "",
    endAt: ""
  });
  const toggleProduct = (productId) => {
    setF((prev) => ({
      ...prev,
      productIds: prev.productIds?.includes(productId) ? prev.productIds.filter((id) => id !== productId) : [...prev.productIds ?? [], productId]
    }));
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Dialog, { open, onOpenChange: (v) => {
    onOpenChange(v);
    if (v) setF({
      title: editing?.title ?? "",
      description: editing?.description ?? "",
      price: editing?.price ?? 0,
      image: editing?.image ?? "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=900",
      productIds: editing?.productIds ?? [],
      active: editing?.active ?? true,
      startAt: editing?.startAt ?? "",
      endAt: editing?.endAt ?? ""
    });
  }, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogContent, { className: "max-w-lg max-h-[90vh] overflow-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(DialogHeader, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(DialogTitle, { children: [
      editing ? "Edit" : "New",
      " offer"
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Title", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.title, onChange: (e) => setF({
        ...f,
        title: e.target.value
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Description", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { rows: 2, value: f.description, onChange: (e) => setF({
        ...f,
        description: e.target.value
      }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Price", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "number", step: "0.01", value: f.price, onChange: (e) => setF({
          ...f,
          price: +e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Image URL", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.image, onChange: (e) => setF({
          ...f,
          image: e.target.value
        }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Included products", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "max-h-40 space-y-2 overflow-auto rounded-xl border p-3", children: products.map((p) => /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex cursor-pointer items-center gap-2 text-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("input", { type: "checkbox", checked: f.productIds?.includes(p.id) ?? false, onChange: () => toggleProduct(p.id), className: "rounded border-border" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: p.name })
      ] }, p.id)) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Starts (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "datetime-local", value: f.startAt, onChange: (e) => setF({
          ...f,
          startAt: e.target.value
        }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Ends (optional)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { type: "datetime-local", value: f.endAt, onChange: (e) => setF({
          ...f,
          endAt: e.target.value
        }) }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Switch, { checked: f.active, onCheckedChange: (v) => setF({
          ...f,
          active: v
        }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm", children: "Active" })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "w-full mt-4 rounded-full gradient-choco text-primary-foreground", onClick: () => onSave(f), children: "Save" })
  ] }) });
}
function SitePanel() {
  const {
    hero
  } = useShop();
  const [f, setF] = reactExports.useState(() => ({
    ...hero,
    backgroundSlides: normalizeBackgroundSlides(hero.backgroundSlides),
    floatingImages: normalizeFloatingImages(hero.floatingImages)
  }));
  const slides = normalizeBackgroundSlides(f.backgroundSlides);
  const floats = normalizeFloatingImages(f.floatingImages);
  const updateSlideImage = (index, value) => {
    const next = slides.map((slide, i) => i === index ? {
      ...slide,
      image: value
    } : slide);
    setF({
      ...f,
      backgroundSlides: next
    });
  };
  const updateSlideCaption = (index, caption) => {
    const next = slides.map((slide, i) => i === index ? {
      ...slide,
      caption
    } : slide);
    setF({
      ...f,
      backgroundSlides: next
    });
  };
  const clearSlide = (index) => {
    const next = slides.map((slide, i) => i === index ? {
      ...slide,
      image: ""
    } : slide);
    setF({
      ...f,
      backgroundSlides: next
    });
  };
  const updateFloat = (index, value) => {
    const next = [...floats];
    next[index] = value;
    setF({
      ...f,
      floatingImages: next
    });
  };
  const clearFloat = (index) => {
    const next = [...floats];
    next[index] = "";
    setF({
      ...f,
      floatingImages: next
    });
  };
  const saveHero2 = async () => {
    try {
      await saveHeroToApi({
        tagline: f.tagline,
        image: f.image,
        floatingImages: normalizeFloatingImages(f.floatingImages),
        aboutImage: f.aboutImage,
        backgroundSlides: normalizeBackgroundSlides(f.backgroundSlides),
        heroBadge: f.heroBadge,
        heroTitleBefore: f.heroTitleBefore,
        heroTitleAccent: f.heroTitleAccent,
        heroTitleAfter: f.heroTitleAfter
      });
      toast.success("Saved");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Could not save");
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-6 max-w-3xl", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-display text-2xl text-primary mb-4", children: "Site Images & Hero" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Hero headline" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 mb-3 text-xs text-muted-foreground", children: "Text beside the moving photo on the homepage." }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid gap-3 sm:grid-cols-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Badge", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.heroBadge, onChange: (e) => setF({
            ...f,
            heroBadge: e.target.value
          }), placeholder: "Dessert Cafe · Chicago" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Tagline", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.tagline, onChange: (e) => setF({
            ...f,
            tagline: e.target.value
          }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Title — first word", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.heroTitleBefore, onChange: (e) => setF({
            ...f,
            heroTitleBefore: e.target.value
          }), placeholder: "Sweet" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Title — accent (script)", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.heroTitleAccent, onChange: (e) => setF({
            ...f,
            heroTitleAccent: e.target.value
          }), placeholder: "Drip" }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "sm:col-span-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Title — last line", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: f.heroTitleAfter, onChange: (e) => setF({
            ...f,
            heroTitleAfter: e.target.value
          }), placeholder: "Every Day." }) }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-sm font-medium", children: [
          "Rotating background (",
          HERO_SLIDE_COUNT,
          " images)"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 mb-3 text-xs text-muted-foreground", children: "Homepage slideshow behind the hero — drag & drop photos and add optional text on each slide." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-4 sm:grid-cols-2", children: slides.map((slide, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "rounded-xl border bg-muted/20 p-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mb-2 block text-xs font-medium text-muted-foreground", children: [
            "Slide ",
            i + 1
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ImageDropzone, { value: slide.image, onChange: (v) => updateSlideImage(i, v), onClear: () => clearSlide(i), previewClassName: "aspect-[4/3]" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Field, { label: "Text on slide", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Input, { value: slide.caption, onChange: (e) => updateSlideCaption(i, e.target.value), placeholder: "Optional caption shown on this photo" }) }) })
        ] }, i)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "Main moving hero image" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 mb-2 text-xs text-muted-foreground", children: "The large dessert photo that floats beside the headline on desktop." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ImageDropzone, { value: f.image, onChange: (v) => setF({
          ...f,
          image: v
        }), onClear: () => setF({
          ...f,
          image: ""
        }), previewClassName: "aspect-square max-h-52" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Label, { className: "text-sm font-medium", children: [
          "Floating side images (",
          FLOAT_IMAGE_COUNT,
          ")"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 mb-3 text-xs text-muted-foreground", children: "Small decorative photos that move around the main hero image on desktop." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid gap-3 sm:grid-cols-3", children: floats.map((src, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "mb-1.5 block text-xs font-medium text-muted-foreground", children: [
            "Float ",
            i + 1
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(ImageDropzone, { value: src, onChange: (v) => updateFloat(i, v), onClear: () => clearFloat(i), previewClassName: "aspect-square" })
        ] }, i)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "text-sm font-medium", children: "About page image" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-1 mb-2 text-xs text-muted-foreground", children: "Photo on the About page." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ImageDropzone, { value: f.aboutImage, onChange: (v) => setF({
          ...f,
          aboutImage: v
        }), onClear: () => setF({
          ...f,
          aboutImage: ""
        }), previewClassName: "aspect-video" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { className: "rounded-full gradient-choco text-primary-foreground", onClick: saveHero2, children: "Save changes" })
    ] })
  ] }) });
}
function Field({
  label,
  children
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-1.5 block text-sm", children: label }),
    children
  ] });
}
const SplitComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsx(AdminGuard, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Dashboard, {}) });
export {
  SplitComponent as component
};
