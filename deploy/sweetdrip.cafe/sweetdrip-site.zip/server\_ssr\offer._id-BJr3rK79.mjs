import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { f as useParams, e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { P as ProductCard } from "./ProductCard-BalCHwJH.mjs";
import { V as resolveOfferProducts, i as isLiveOffer, O as OFFERS_MENU_FILTER, B as Button, T as offerCartProductId } from "./router-CypnlrKc.mjs";
import { a as useCart, u as useShop, f as fmt } from "./store-C3jzrryZ.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { i as ChevronLeft, S as ShoppingBag } from "../_libs/lucide-react.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/zod.mjs";
import "../_libs/zustand.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function OfferPage() {
  const {
    id
  } = useParams({
    from: "/offer/$id"
  });
  const navigate = useNavigate();
  const add = useCart((s) => s.add);
  const {
    offers,
    products
  } = useShop();
  const offer = offers.find((o) => o.id === id);
  const included = offer ? resolveOfferProducts(offer, products) : [];
  if (!offer || !isLiveOffer(offer)) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-20 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl font-display text-primary mb-4", children: "Offer not found" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", search: {
        cat: OFFERS_MENU_FILTER
      }, className: "text-primary underline", children: "Back to offers" })
    ] });
  }
  const onAdd = () => {
    add({
      productId: offerCartProductId(offer.id),
      name: offer.title,
      price: offer.price,
      qty: 1,
      image: offer.image
    });
    toast.success(`${offer.title} added to cart`);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-8 sm:py-12", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { type: "button", onClick: () => navigate({
      to: "/menu",
      search: {
        cat: OFFERS_MENU_FILTER
      }
    }), className: "mb-4 inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary sm:mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "h-4 w-4" }),
      " Back to offers"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 items-start gap-6 md:grid-cols-2 md:gap-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { initial: {
        opacity: 0,
        scale: 0.95
      }, animate: {
        opacity: 1,
        scale: 1
      }, transition: {
        duration: 0.5
      }, className: "gradient-hero mx-auto aspect-square w-full max-h-[min(85vw,28rem)] overflow-hidden rounded-2xl shadow-glow sm:rounded-3xl md:max-h-none", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: offer.image, alt: offer.title, className: "h-full w-full object-cover" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        x: 20
      }, animate: {
        opacity: 1,
        x: 0
      }, transition: {
        duration: 0.5,
        delay: 0.1
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.3em] text-accent", children: "Limited Time Offer" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "mt-2 font-display text-3xl text-primary sm:text-4xl lg:text-5xl", children: offer.title }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 text-2xl font-display text-gradient-gold sm:mt-3 sm:text-3xl", children: fmt(offer.price) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 leading-relaxed text-muted-foreground", children: offer.description }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { type: "button", onClick: onAdd, size: "lg", className: "mt-6 w-full rounded-full gradient-choco text-primary-foreground hover:opacity-90 sm:mt-8 sm:w-auto sm:px-8", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingBag, { className: "mr-2 h-4 w-4" }),
          "Order bundle · ",
          fmt(offer.price)
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { className: "mt-12 sm:mt-16", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-center font-display text-2xl text-primary sm:text-3xl", children: "Included in this offer" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mx-auto mt-2 max-w-lg text-center text-sm text-muted-foreground sm:text-base", children: "Everything you get in this bundle — tap any item for full details." }),
      included.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-8 text-center text-muted-foreground", children: "Products for this offer are being updated." }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-8 grid grid-cols-2 gap-3 sm:gap-6 lg:grid-cols-4", children: included.map((p, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(ProductCard, { p, index: i }, p.id)) })
    ] })
  ] });
}
export {
  OfferPage as component
};
