globalThis.__nitro_main__ = import.meta.url;
import { N as NodeResponse, s as serve } from "./_libs/srvx.mjs";
import { H as HTTPError, d as defineHandler, t as toEventHandler, a as defineLazyEventHandler, b as H3Core } from "./_libs/h3.mjs";
import { d as decodePath, w as withLeadingSlash, a as withoutTrailingSlash, j as joinURL } from "./_libs/ufo.mjs";
import { promises } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, resolve } from "node:path";
import "node:http";
import "node:stream";
import "node:stream/promises";
import "node:https";
import "node:http2";
import "./_libs/rou3.mjs";
function lazyService(loader) {
  let promise, mod;
  return {
    fetch(req) {
      if (mod) {
        return mod.fetch(req);
      }
      if (!promise) {
        promise = loader().then((_mod) => mod = _mod.default || _mod);
      }
      return promise.then((mod2) => mod2.fetch(req));
    }
  };
}
const services = {
  ["ssr"]: lazyService(() => import("./_ssr/index.mjs"))
};
globalThis.__nitro_vite_envs__ = services;
const errorHandler$1 = (error, event) => {
  const res = defaultHandler(error, event);
  return new NodeResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
  const unhandled = error.unhandled ?? !HTTPError.isError(error);
  const { status = 500, statusText = "" } = unhandled ? {} : error;
  if (status === 404) {
    const url = event.url || new URL(event.req.url);
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      return {
        status: 302,
        headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
      };
    }
  }
  const headers2 = new Headers(unhandled ? {} : error.headers);
  headers2.set("content-type", "application/json; charset=utf-8");
  const jsonBody = unhandled ? {
    status,
    unhandled: true
  } : typeof error.toJSON === "function" ? error.toJSON() : {
    status,
    statusText,
    message: error.message
  };
  return {
    status,
    statusText,
    headers: headers2,
    body: {
      error: true,
      ...jsonBody
    }
  };
}
const errorHandlers = [errorHandler$1];
async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      const response = await handler(error, event, { defaultHandler });
      if (response) {
        return response;
      }
    } catch (error2) {
      console.error(error2);
    }
  }
}
const headers = ((m) => function headersRouteRule(event) {
  for (const [key2, value] of Object.entries(m.options || {})) {
    event.res.headers.set(key2, value);
  }
});
const assets = {
  "/assets/about-M44KRyYG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"2880-63yuTYG1NQnC94j9ajg7qmh9PbQ"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 10368,
    "path": "../public/assets/about-M44KRyYG.js"
  },
  "/assets/cart-Bdm5jDF6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"c5-5XAAaFo7N8cSHAPX4N2B1iF2gnA"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 197,
    "path": "../public/assets/cart-Bdm5jDF6.js"
  },
  "/assets/check-C4I7eUie.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7d-oX/EtvSRbkIR0FUvAoRGaXUX/Mg"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 125,
    "path": "../public/assets/check-C4I7eUie.js"
  },
  "/assets/about-cafe-DhJZOrMN.jpg": {
    "type": "image/jpeg",
    "etag": '"23ded-VLdEVmHKrNe1bJgUARgagxmNaKg"',
    "mtime": "2026-06-05T18:16:44.098Z",
    "size": 146925,
    "path": "../public/assets/about-cafe-DhJZOrMN.jpg"
  },
  "/assets/catering-BdIG47YL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"14be-lOTZbjjD7Xsbo4tfXQlXfz/mHK8"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 5310,
    "path": "../public/assets/catering-BdIG47YL.js"
  },
  "/assets/admin-_p3T83dd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"18301-AA0qVUiBRWVp8Q5gXfni93me0mk"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 99073,
    "path": "../public/assets/admin-_p3T83dd.js"
  },
  "/assets/chevron-down-HU70yQmj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"81-OSe+0GyE302LIhLQ9APnJEUKyTk"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 129,
    "path": "../public/assets/chevron-down-HU70yQmj.js"
  },
  "/assets/chevron-left-Cyqm34F2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"83-JJ6kXI+4q0NjnSKY9e/rjMMiWkc"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 131,
    "path": "../public/assets/chevron-left-Cyqm34F2.js"
  },
  "/assets/contact-CovrB8Yg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"ca6-1F46FFXH43iDvbdGLBsgmr7gPo8"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 3238,
    "path": "../public/assets/contact-CovrB8Yg.js"
  },
  "/assets/checkout-DKpJTEdf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7c22-wBzheswBj+3NdQ99pcw0gguC09s"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 31778,
    "path": "../public/assets/checkout-DKpJTEdf.js"
  },
  "/assets/hero-dessert-CzX58s3V.jpg": {
    "type": "image/jpeg",
    "etag": '"11746-SWYQR8mmpYdoIrFL31RBnxavKao"',
    "mtime": "2026-06-05T18:16:44.094Z",
    "size": 71494,
    "path": "../public/assets/hero-dessert-CzX58s3V.jpg"
  },
  "/assets/ice-cream-cone-CQvhtKAv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5ee-FJFz9NGkfsoDiiaTTuMCOMOAdEo"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 1518,
    "path": "../public/assets/ice-cream-cone-CQvhtKAv.js"
  },
  "/assets/index-BKqFEbzq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"7067-ZSy+zgHmUM+CZqBfLnU+FphB3YA"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 28775,
    "path": "../public/assets/index-BKqFEbzq.js"
  },
  "/assets/invoice-9vrz3HUx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"12b3-XwyOmtvGNDyUDBxjIj1FOrcA3vE"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 4787,
    "path": "../public/assets/invoice-9vrz3HUx.js"
  },
  "/assets/float-2-BepYAW2s.png": {
    "type": "image/png",
    "etag": '"401ea-bpkd1Wz1QhAs8TMJTUUVx3OXgBQ"',
    "mtime": "2026-06-05T18:16:44.098Z",
    "size": 262634,
    "path": "../public/assets/float-2-BepYAW2s.png"
  },
  "/assets/MapLocationBox-B1cgkkpA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"556-wC4w4C7hOayISu7jqGjpIz3qHbQ"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 1366,
    "path": "../public/assets/MapLocationBox-B1cgkkpA.js"
  },
  "/assets/menu-BX_FhEPl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"d37-FIJljKxBrnOK5afs0YwylhYRw6E"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 3383,
    "path": "../public/assets/menu-BX_FhEPl.js"
  },
  "/assets/offer._id-Bx3rAgod.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"b68-Ip0CfsyAy5nw02PskjdRMjPGePM"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 2920,
    "path": "../public/assets/offer._id-Bx3rAgod.js"
  },
  "/assets/OfferCard-Burp6LFB.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"6fc-daYXTmPJhdNG45ozMWjyNxldbkE"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 1788,
    "path": "../public/assets/OfferCard-Burp6LFB.js"
  },
  "/assets/float-1-Ci-SjRl3.png": {
    "type": "image/png",
    "etag": '"69505-94GR9DNIhsW9VbutG/AC/Fs1X3k"',
    "mtime": "2026-06-05T18:16:44.098Z",
    "size": 431365,
    "path": "../public/assets/float-1-Ci-SjRl3.png"
  },
  "/assets/phone-Dx286fFs.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"165-YfoqwnJ1Z+4QtGbN7mRCe9OpEvo"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 357,
    "path": "../public/assets/phone-Dx286fFs.js"
  },
  "/assets/privacy-DaT7XOdo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"5e4-VAQOmUAIRRtHerm/XHfSnHEgzvE"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 1508,
    "path": "../public/assets/privacy-DaT7XOdo.js"
  },
  "/assets/product._id-DQ8IxW2Q.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"9d-Bq2WIjdmxHb3Tzz6ih79nrSu4Ww"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 157,
    "path": "../public/assets/product._id-DQ8IxW2Q.js"
  },
  "/assets/float-3-BSPRS65G.png": {
    "type": "image/png",
    "etag": '"9cf2a-FSiCrU7T3/c1ZEhzsqJ6zTzoaZM"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 642858,
    "path": "../public/assets/float-3-BSPRS65G.png"
  },
  "/assets/index-qGfLXggG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"a5575-WGbNVyGw2Zd2ofk3UawtBFnHAj8"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 677237,
    "path": "../public/assets/index-qGfLXggG.js"
  },
  "/assets/product._id-LgGaDGGa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"df9-v1t7if+2aWCboyU0pftSB/X/Kik"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 3577,
    "path": "../public/assets/product._id-LgGaDGGa.js"
  },
  "/assets/SectionHeading-CqDYGNyc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"228-a7Kt/+GXoXhYfSBHpjjC2RT8g00"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 552,
    "path": "../public/assets/SectionHeading-CqDYGNyc.js"
  },
  "/assets/ProductCard-BrxjCtts.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"81d-mbrpWDWwhA73S7V4YJoIGDC45zU"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 2077,
    "path": "../public/assets/ProductCard-BrxjCtts.js"
  },
  "/assets/terms-DHfwHoIm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"4d9-RsAH5sO+K69sYdBKAC5MYmUgn3I"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 1241,
    "path": "../public/assets/terms-DHfwHoIm.js"
  },
  "/assets/textarea-B3I0sekg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": '"1c7-5UzVnxOrVCfnRw3XRoU6tO/aCu8"',
    "mtime": "2026-06-05T18:16:44.099Z",
    "size": 455,
    "path": "../public/assets/textarea-B3I0sekg.js"
  },
  "/assets/styles-DpG5_lBQ.css": {
    "type": "text/css; charset=utf-8",
    "etag": '"1e3ab-aJ3Fam000/lKLPegRM5QAbT9Huc"',
    "mtime": "2026-06-05T18:16:44.098Z",
    "size": 123819,
    "path": "../public/assets/styles-DpG5_lBQ.css"
  },
  "/assets/Sweet_Drip_Logo.-C69f0URr.png": {
    "type": "image/png",
    "etag": '"12ae7-bdWCVaZaVaQzO4CE/Vf3hoL4J7w"',
    "mtime": "2026-06-05T18:16:44.098Z",
    "size": 76519,
    "path": "../public/assets/Sweet_Drip_Logo.-C69f0URr.png"
  }
};
function readAsset(id) {
  const serverDir = dirname(fileURLToPath(globalThis.__nitro_main__));
  return promises.readFile(resolve(serverDir, assets[id].path));
}
const publicAssetBases = {};
function isPublicAssetURL(id = "") {
  if (assets[id]) {
    return true;
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) {
      return true;
    }
  }
  return false;
}
function getAsset(id) {
  return assets[id];
}
const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = {
  gzip: ".gz",
  br: ".br",
  zstd: ".zst"
};
const _PQhfm7 = defineHandler((event) => {
  if (event.req.method && !METHODS.has(event.req.method)) {
    return;
  }
  let id = decodePath(withLeadingSlash(withoutTrailingSlash(event.url.pathname)));
  let asset;
  const encodingHeader = event.req.headers.get("accept-encoding") || "";
  const encodings = [...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(), ""];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      event.res.headers.delete("Cache-Control");
      throw new HTTPError({ status: 404 });
    }
    return;
  }
  if (encodings.length > 1) {
    event.res.headers.append("Vary", "Accept-Encoding");
  }
  const ifNotMatch = event.req.headers.get("if-none-match") === asset.etag;
  if (ifNotMatch) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  const ifModifiedSinceH = event.req.headers.get("if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    event.res.status = 304;
    event.res.statusText = "Not Modified";
    return "";
  }
  if (asset.type) {
    event.res.headers.set("Content-Type", asset.type);
  }
  if (asset.etag && !event.res.headers.has("ETag")) {
    event.res.headers.set("ETag", asset.etag);
  }
  if (asset.mtime && !event.res.headers.has("Last-Modified")) {
    event.res.headers.set("Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !event.res.headers.has("Content-Encoding")) {
    event.res.headers.set("Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !event.res.headers.has("Content-Length")) {
    event.res.headers.set("Content-Length", asset.size.toString());
  }
  return readAsset(id);
});
const findRouteRules = /* @__PURE__ */ (() => {
  const $0 = [{ name: "headers", route: "/assets/**", handler: headers, options: { "cache-control": "public, max-age=31536000, immutable" } }];
  return (m, p) => {
    let r = [];
    if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
    let s = p.split("/"), l = s.length;
    if (l > 1) {
      if (s[1] === "assets") {
        r.unshift({ data: $0, params: { "_": s.slice(2).join("/") } });
      }
    }
    return r;
  };
})();
const _lazy_ffqqip = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
const findRoute = /* @__PURE__ */ (() => {
  const data = { route: "/**", handler: _lazy_ffqqip };
  return ((_m, p) => {
    return { data, params: { "_": p.slice(1) } };
  });
})();
const globalMiddleware = [
  toEventHandler(_PQhfm7)
].filter(Boolean);
const APP_ID = "default";
function useNitroApp() {
  let instance = useNitroApp._instance;
  if (instance) {
    return instance;
  }
  instance = useNitroApp._instance = createNitroApp();
  globalThis.__nitro__ = globalThis.__nitro__ || {};
  globalThis.__nitro__[APP_ID] = instance;
  return instance;
}
function createNitroApp() {
  const hooks = void 0;
  const captureError = (error, errorCtx) => {
    if (errorCtx?.event) {
      const errors = errorCtx.event.req.context?.nitro?.errors;
      if (errors) {
        errors.push({
          error,
          context: errorCtx
        });
      }
    }
  };
  const h3App = createH3App({ onError(error, event) {
    return errorHandler(error, event);
  } });
  let appHandler = (req) => {
    req.context ||= {};
    req.context.nitro = req.context.nitro || { errors: [] };
    return h3App.fetch(req);
  };
  const app = {
    fetch: appHandler,
    h3: h3App,
    hooks,
    captureError
  };
  return app;
}
function createH3App(config) {
  const h3App = new H3Core(config);
  h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
  h3App["~middleware"].push(...globalMiddleware);
  {
    h3App["~getMiddleware"] = (event, route) => {
      const pathname = event.url.pathname;
      const method = event.req.method;
      const middleware = [];
      {
        const routeRules = getRouteRules(method, pathname);
        event.context.routeRules = routeRules?.routeRules;
        if (routeRules?.routeRuleMiddleware.length) {
          middleware.push(...routeRules.routeRuleMiddleware);
        }
      }
      middleware.push(...h3App["~middleware"]);
      if (route?.data?.middleware?.length) {
        middleware.push(...route.data.middleware);
      }
      return middleware;
    };
  }
  return h3App;
}
function getRouteRules(method, pathname) {
  const m = findRouteRules(method, pathname);
  if (!m?.length) {
    return { routeRuleMiddleware: [] };
  }
  const routeRules = {};
  for (const layer of m) {
    for (const rule of layer.data) {
      const currentRule = routeRules[rule.name];
      if (currentRule) {
        if (rule.options === false) {
          delete routeRules[rule.name];
          continue;
        }
        if (typeof currentRule.options === "object" && typeof rule.options === "object") {
          currentRule.options = {
            ...currentRule.options,
            ...rule.options
          };
        } else {
          currentRule.options = rule.options;
        }
        currentRule.route = rule.route;
        currentRule.params = {
          ...currentRule.params,
          ...layer.params
        };
      } else if (rule.options !== false) {
        routeRules[rule.name] = {
          ...rule,
          params: layer.params
        };
      }
    }
  }
  const middleware = [];
  const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
  for (const rule of orderedRules) {
    if (rule.options === false || !rule.handler) {
      continue;
    }
    middleware.push(rule.handler(rule));
  }
  return {
    routeRules,
    routeRuleMiddleware: middleware
  };
}
function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError?.(error, { tags: [type] });
}
function trapUnhandledErrors() {
  process.on("unhandledRejection", (error) => _captureError(error, "unhandledRejection"));
  process.on("uncaughtException", (error) => _captureError(error, "uncaughtException"));
}
const tracingSrvxPlugins = [];
const _parsedPort = Number.parseInt(process.env.NITRO_PORT ?? process.env.PORT ?? "");
const port = Number.isNaN(_parsedPort) ? 3e3 : _parsedPort;
const host = process.env.NITRO_HOST || process.env.HOST;
const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
serve({
  port,
  hostname: host,
  tls: cert && key ? {
    cert,
    key
  } : void 0,
  fetch: nitroApp.fetch,
  plugins: [...tracingSrvxPlugins]
});
trapUnhandledErrors();
const nodeServer = {};
export {
  nodeServer as default
};
