import{j as o}from"./index-qGfLXggG.js";const n=()=>o.jsx("div",{className:"p-12 text-center",children:"Product not found"});export{n as notFoundComponent};
