import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { f as useParams, e as useNavigate, L as Link } from "../_libs/tanstack__react-router.mjs";
import { u as useShop, a as useCart, f as fmt } from "./store-C3jzrryZ.mjs";
import { L as Label, B as Button } from "./router-CypnlrKc.mjs";
import { T as Textarea } from "./textarea-G8B6rCe0.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { i as ChevronLeft, d as Minus, e as Plus, S as ShoppingBag } from "../_libs/lucide-react.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/zod.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function ProductPage() {
  const {
    id
  } = useParams({
    from: "/product/$id"
  });
  const navigate = useNavigate();
  const {
    products,
    categories
  } = useShop();
  const add = useCart((s) => s.add);
  const product = products.find((p) => p.id === id);
  const [qty, setQty] = reactExports.useState(1);
  const [choice, setChoice] = reactExports.useState(void 0);
  const [note, setNote] = reactExports.useState("");
  if (!product) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-20 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl mb-4", children: "Product not found" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Link, { to: "/menu", className: "text-primary underline", children: "Back to menu" })
    ] });
  }
  const cat = categories.find((c) => c.id === product.categoryId);
  const img = product.image || cat?.image;
  const onAdd = () => {
    add({
      productId: product.id,
      name: product.name,
      price: product.price,
      qty,
      image: img,
      noteChoice: choice,
      note
    });
    toast.success("Added to cart");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-8 sm:py-12", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("button", { onClick: () => navigate({
      to: "/menu"
    }), className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-primary mb-4 sm:mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronLeft, { className: "w-4 h-4" }),
      " Back to menu"
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-12", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { initial: {
        opacity: 0,
        scale: 0.95
      }, animate: {
        opacity: 1,
        scale: 1
      }, transition: {
        duration: 0.5
      }, className: "aspect-square max-h-[min(85vw,28rem)] md:max-h-none mx-auto w-full rounded-2xl sm:rounded-3xl overflow-hidden shadow-glow gradient-hero", children: img && /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: img, alt: product.name, className: "w-full h-full object-cover" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(motion.div, { initial: {
        opacity: 0,
        x: 20
      }, animate: {
        opacity: 1,
        x: 0
      }, transition: {
        duration: 0.5,
        delay: 0.1
      }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs uppercase tracking-[0.3em] text-secondary", children: cat?.name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-3xl sm:text-4xl lg:text-5xl font-display text-primary mt-2", children: product.name }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 sm:mt-3 text-2xl sm:text-3xl font-display text-gradient-gold", children: fmt(product.price) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-5 text-muted-foreground leading-relaxed", children: product.description }),
        product.noteChoices.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { className: "mb-3 block font-semibold", children: product.notes }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: product.noteChoices.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setChoice(c), className: `px-4 py-2 rounded-full text-sm border-2 transition ${choice === c ? "border-primary bg-primary text-primary-foreground" : "border-border hover:border-primary/50"}`, children: c }, c)) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "note", className: "mb-2 block font-semibold", children: "Extra note (optional)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Textarea, { id: "note", value: note, onChange: (e) => setNote(e.target.value), placeholder: "Allergies, special instructions...", rows: 3 })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-6 sm:mt-8 flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-3 border-2 border-border rounded-full p-1 self-start", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setQty(Math.max(1, qty - 1)), className: "w-9 h-9 rounded-full hover:bg-muted flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Minus, { className: "w-4 h-4" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-6 text-center font-semibold", children: qty }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: () => setQty(qty + 1), className: "w-9 h-9 rounded-full hover:bg-muted flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Plus, { className: "w-4 h-4" }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { onClick: onAdd, size: "lg", className: "w-full sm:w-auto rounded-full gradient-choco text-primary-foreground hover:opacity-90 px-6 sm:px-8", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingBag, { className: "w-4 h-4 mr-2" }),
            " Add to cart · ",
            fmt(product.price * qty)
          ] })
        ] })
      ] })
    ] })
  ] });
}
export {
  ProductPage as component
};
