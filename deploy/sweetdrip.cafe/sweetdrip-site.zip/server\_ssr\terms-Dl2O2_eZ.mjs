import { j as jsxRuntimeExports } from "../_libs/react.mjs";
const H = ({
  children
}) => /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-display text-primary mt-8 mb-3", children });
const P = ({
  children
}) => /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground leading-relaxed", children });
const SplitComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-16 max-w-3xl mx-auto", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-4xl font-display text-primary mb-6", children: "Terms & Conditions" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mb-6", children: "By accessing or using the Sweet Drip Dessert Cafe website, you agree to be bound by these terms. If you do not agree, please do not use our site." }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(H, { children: "Use of Our Site" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(P, { children: "All content on this site is provided for informational purposes. We reserve the right to modify the site and these terms at any time." }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(H, { children: "Intellectual Property" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(P, { children: "All logos, text and graphics are the property of Sweet Drip Dessert Cafe unless otherwise noted. Unauthorized use is prohibited." }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(H, { children: "Limitation of Liability" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(P, { children: "Sweet Drip Dessert Cafe is not liable for any damages arising from the use of this website. Your use of the site is at your own risk." })
] });
export {
  SplitComponent as component
};
