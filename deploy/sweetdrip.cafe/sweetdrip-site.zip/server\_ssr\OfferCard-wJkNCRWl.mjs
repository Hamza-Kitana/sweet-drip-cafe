import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a as useCart, f as fmt } from "./store-C3jzrryZ.mjs";
import { B as Button, T as offerCartProductId } from "./router-CypnlrKc.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { S as ShoppingBag } from "../_libs/lucide-react.mjs";
function OfferCard({ offer, index = 0, className = "" }) {
  const add = useCart((s) => s.add);
  const onAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    add({
      productId: offerCartProductId(offer.id),
      name: offer.title,
      price: offer.price,
      qty: 1,
      image: offer.image
    });
    toast.success(`${offer.title} added to cart`);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.article,
    {
      initial: { opacity: 0, y: 30 },
      whileInView: { opacity: 1, y: 0 },
      viewport: { once: true },
      transition: { duration: 0.5, delay: index * 0.08 },
      className: `relative flex w-full flex-col overflow-hidden rounded-2xl bg-card shadow-soft group sm:rounded-3xl ${className}`,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Link,
          {
            to: "/offer/$id",
            params: { id: offer.id },
            className: "block flex-1 transition hover:opacity-95",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-[4/3] overflow-hidden", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: offer.image,
                    alt: offer.title,
                    className: "h-full w-full object-cover transition duration-700 group-hover:scale-105",
                    loading: "lazy"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overlay-pink-card absolute inset-0" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "absolute left-4 top-4 rounded-full bg-accent px-3 py-1 text-[10px] font-bold uppercase tracking-wide text-primary sm:text-xs", children: "Offer" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-5 sm:p-6", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-display text-primary sm:text-2xl", children: offer.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-2 line-clamp-2 text-sm text-muted-foreground", children: offer.description })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-end justify-between gap-3 px-5 pb-5 sm:px-6 sm:pb-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-2xl font-display text-gradient-gold sm:text-3xl", children: fmt(offer.price) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              type: "button",
              onClick: onAdd,
              className: "shrink-0 rounded-full gradient-choco px-4 text-primary-foreground hover:opacity-90 sm:px-5",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingBag, { className: "mr-1.5 h-4 w-4" }),
                "Order"
              ]
            }
          )
        ] })
      ]
    }
  );
}
export {
  OfferCard as O
};
