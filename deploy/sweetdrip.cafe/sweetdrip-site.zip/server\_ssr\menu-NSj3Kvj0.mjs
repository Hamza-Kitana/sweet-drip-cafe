import { r as reactExports, j as jsxRuntimeExports } from "../_libs/react.mjs";
import { e as useNavigate } from "../_libs/tanstack__react-router.mjs";
import { u as useShop } from "./store-C3jzrryZ.mjs";
import { O as OfferCard } from "./OfferCard-wJkNCRWl.mjs";
import { P as ProductCard } from "./ProductCard-BalCHwJH.mjs";
import { S as SectionHeading } from "./SectionHeading-C_mqZXgB.mjs";
import { R as Route$a, v as visibleCategories, i as isLiveOffer, O as OFFERS_MENU_FILTER, a as isOffersMenuFilter, b as isOffersSectionVisible } from "./router-CypnlrKc.mjs";
import "../_libs/sonner.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import "../_libs/tanstack__router-core.mjs";
import "../_libs/tanstack__history.mjs";
import "../_libs/cookie-es.mjs";
import "../_libs/seroval.mjs";
import "../_libs/seroval-plugins.mjs";
import "node:stream/web";
import "node:stream";
import "../_libs/react-dom.mjs";
import "util";
import "async_hooks";
import "stream";
import "crypto";
import "../_libs/isbot.mjs";
import "../_libs/zustand.mjs";
import "../_libs/lucide-react.mjs";
import "../_libs/tanstack__query-core.mjs";
import "../_libs/tanstack__react-query.mjs";
import "../_libs/radix-ui__react-dialog.mjs";
import "../_libs/radix-ui__primitive.mjs";
import "../_libs/radix-ui__react-compose-refs.mjs";
import "../_libs/radix-ui__react-context.mjs";
import "../_libs/radix-ui__react-id.mjs";
import "../_libs/@radix-ui/react-use-layout-effect+[...].mjs";
import "../_libs/@radix-ui/react-use-controllable-state+[...].mjs";
import "../_libs/@radix-ui/react-dismissable-layer+[...].mjs";
import "../_libs/radix-ui__react-primitive.mjs";
import "../_libs/radix-ui__react-slot.mjs";
import "../_libs/@radix-ui/react-use-callback-ref+[...].mjs";
import "../_libs/@radix-ui/react-use-escape-keydown+[...].mjs";
import "../_libs/radix-ui__react-focus-scope.mjs";
import "../_libs/radix-ui__react-portal.mjs";
import "../_libs/radix-ui__react-presence.mjs";
import "../_libs/radix-ui__react-focus-guards.mjs";
import "../_libs/react-remove-scroll.mjs";
import "tslib";
import "../_libs/react-remove-scroll-bar.mjs";
import "../_libs/react-style-singleton.mjs";
import "../_libs/get-nonce.mjs";
import "../_libs/use-sidecar.mjs";
import "../_libs/use-callback-ref.mjs";
import "../_libs/aria-hidden.mjs";
import "../_libs/clsx.mjs";
import "../_libs/tailwind-merge.mjs";
import "../_libs/class-variance-authority.mjs";
import "../_libs/radix-ui__react-label.mjs";
import "../_libs/zod.mjs";
import "../_libs/motion-dom.mjs";
import "../_libs/motion-utils.mjs";
function MenuPage() {
  const {
    categories,
    products,
    offers,
    offersSectionVisible
  } = useShop();
  const {
    cat
  } = Route$a.useSearch();
  const navigate = useNavigate();
  const menuCategories = visibleCategories(categories);
  const visibleCategoryIds = new Set(menuCategories.map((c) => c.id));
  const offersOnSite = isOffersSectionVisible(offersSectionVisible);
  const showOffers = offersOnSite && isOffersMenuFilter(cat);
  const liveOffers = offers.filter(isLiveOffer);
  const filtered = showOffers ? [] : cat ? products.filter((p) => p.categoryId === cat && visibleCategoryIds.has(cat)) : products.filter((p) => visibleCategoryIds.has(p.categoryId));
  const sentinelRef = reactExports.useRef(null);
  const barRef = reactExports.useRef(null);
  const [stuck, setStuck] = reactExports.useState(false);
  const [barHeight, setBarHeight] = reactExports.useState(0);
  reactExports.useEffect(() => {
    const bar = barRef.current;
    if (!bar) return;
    const syncHeight = () => setBarHeight(bar.offsetHeight);
    syncHeight();
    const ro = new ResizeObserver(syncHeight);
    ro.observe(bar);
    window.addEventListener("resize", syncHeight);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", syncHeight);
    };
  }, []);
  reactExports.useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel) return;
    const update = () => {
      const headerH = parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--site-header-height")) || 88;
      setStuck(sentinel.getBoundingClientRect().top <= headerH + 1);
    };
    update();
    window.addEventListener("scroll", update, {
      passive: true
    });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);
  const hiddenCategorySelected = typeof cat === "string" && cat !== OFFERS_MENU_FILTER && !visibleCategoryIds.has(cat);
  reactExports.useEffect(() => {
    if (!offersOnSite && isOffersMenuFilter(cat)) {
      navigate({
        to: "/menu",
        search: {},
        replace: true
      });
    } else if (hiddenCategorySelected) {
      navigate({
        to: "/menu",
        search: {},
        replace: true
      });
    }
  }, [cat, offersOnSite, hiddenCategorySelected, navigate]);
  const filterBtn = (active) => active ? "gradient-choco text-primary-foreground shadow-soft" : "bg-muted hover:bg-muted/70 text-foreground";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner pt-10 sm:pt-16", children: /* @__PURE__ */ jsxRuntimeExports.jsx(SectionHeading, { eyebrow: "Our Menu", title: "Sweet Selection", sub: "From rich chocolate cakes to creamy ice creams." }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: sentinelRef, className: "h-px", "aria-hidden": true }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "menu-filter-bar-wrap", style: {
      height: stuck ? barHeight : void 0
    }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: barRef, className: `menu-filter-bar ${stuck ? "is-stuck py-2" : "py-1"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `menu-filter-bar-surface mx-auto w-fit max-w-full ${stuck ? "is-stuck" : ""}`, children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mobile-scroll-x gap-2 sm:flex sm:flex-wrap sm:justify-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => navigate({
        to: "/menu",
        search: {}
      }), className: `shrink-0 rounded-full px-4 py-2 text-sm font-medium transition sm:px-5 ${filterBtn(!cat)}`, children: "All" }),
      menuCategories.map((c) => /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => navigate({
        to: "/menu",
        search: {
          cat: c.id
        }
      }), className: `shrink-0 rounded-full px-4 py-2 text-sm font-medium transition sm:px-5 ${filterBtn(cat === c.id)}`, children: c.name }, c.id)),
      offersOnSite && /* @__PURE__ */ jsxRuntimeExports.jsx("button", { type: "button", onClick: () => navigate({
        to: "/menu",
        search: {
          cat: OFFERS_MENU_FILTER
        }
      }), className: `shrink-0 rounded-full px-4 py-2 text-sm font-medium transition sm:px-5 ${filterBtn(showOffers)}`, children: "Offers" })
    ] }) }) }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "section-inner pb-10 sm:pb-16 pt-4 sm:pt-6", children: showOffers ? liveOffers.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-muted-foreground py-12", children: "No active offers right now. Check back soon!" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { layout: true, className: "mx-auto grid max-w-5xl grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 sm:gap-6", children: liveOffers.map((o, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(OfferCard, { offer: o, index: i }, o.id)) }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(motion.div, { layout: true, className: "grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6", children: filtered.map((p, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(ProductCard, { p, index: i }, p.id)) }),
      filtered.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-center text-muted-foreground py-12", children: "Nothing here yet. Check back soon!" })
    ] }) })
  ] });
}
export {
  MenuPage as component
};
