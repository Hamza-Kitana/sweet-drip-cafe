import { j as jsxRuntimeExports } from "../_libs/react.mjs";
import { L as Link } from "../_libs/tanstack__react-router.mjs";
import { t as toast } from "../_libs/sonner.mjs";
import { a as useCart, u as useShop, f as fmt } from "./store-C3jzrryZ.mjs";
import { m as motion } from "../_libs/framer-motion.mjs";
import { S as ShoppingBag } from "../_libs/lucide-react.mjs";
function ProductCard({ p, index = 0 }) {
  const add = useCart((s) => s.add);
  const categories = useShop((s) => s.categories);
  const img = p.image || categories.find((c) => c.id === p.categoryId)?.image;
  const onAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    add({
      productId: p.id,
      name: p.name,
      price: p.price,
      qty: 1,
      image: img,
      noteChoice: p.noteChoices[0]
    });
    toast.success(`${p.name} added to cart`);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    motion.div,
    {
      initial: { opacity: 0, y: 30 },
      whileInView: { opacity: 1, y: 0 },
      viewport: { once: true, amount: 0.2 },
      transition: { duration: 0.5, delay: index % 8 * 0.05 },
      className: "group",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative aspect-square overflow-hidden rounded-2xl bg-muted shadow-soft sm:rounded-3xl", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/product/$id", params: { id: p.id }, className: "block h-full", children: [
            img && /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: img,
                alt: p.name,
                className: "h-full w-full object-cover transition-transform duration-700 group-hover:scale-110",
                loading: "lazy"
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overlay-pink-card-hover absolute inset-x-0 bottom-0 hidden h-1/2 opacity-0 transition group-hover:opacity-100 sm:block" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "pointer-events-none absolute right-2 top-2 z-[1] rounded-full glass px-2 py-0.5 text-xs font-semibold text-primary sm:right-3 sm:top-3 sm:px-3 sm:py-1 sm:text-sm", children: fmt(p.price) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              type: "button",
              onClick: onAdd,
              className: "absolute bottom-2 left-2 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-[oklch(0.78_0.11_350)] to-[oklch(0.64_0.12_348)] text-white shadow-soft transition hover:scale-105 hover:from-[oklch(0.74_0.12_350)] hover:to-[oklch(0.6_0.13_346)] sm:bottom-3 sm:left-3 sm:h-10 sm:w-10",
              "aria-label": `Add ${p.name} to cart`,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(ShoppingBag, { className: "h-4 w-4 sm:h-[1.125rem] sm:w-[1.125rem]" })
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Link, { to: "/product/$id", params: { id: p.id }, className: "mt-2 block sm:mt-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "line-clamp-2 text-sm font-semibold transition group-hover:text-primary sm:text-lg", children: p.name }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-0.5 line-clamp-2 text-xs text-muted-foreground hidden sm:block", children: p.description })
        ] })
      ]
    }
  );
}
export {
  ProductCard as P
};
