import { j as jsxRuntimeExports } from "../_libs/react.mjs";
const H = ({
  children
}) => /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-display text-primary mt-8 mb-3", children });
const P = ({
  children
}) => /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground leading-relaxed", children });
const SplitComponent = () => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "section-inner py-16 max-w-3xl mx-auto prose-content", children: [
  /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-4xl font-display text-primary mb-6", children: "Privacy Policy" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-muted-foreground mb-6", children: 'This Privacy Policy explains how Sweet Drip Dessert Cafe ("we", "us", or "our") collects and uses information when you visit our website.' }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(H, { children: "Information We Collect" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(P, { children: "We use the TikTok Pixel to gather data about how visitors interact with our site. This tool collects information such as page views, clicks, conversions and your IP address. The data helps us understand the effectiveness of our advertising and improve user experience." }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(H, { children: "How We Use the Data" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(P, { children: "Information collected through the TikTok Pixel may be shared with TikTok and used to optimize our marketing campaigns. We do not sell your personal information. Data is retained only for as long as necessary to fulfill these purposes or to comply with legal obligations." }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(H, { children: "Your Choices" }),
  /* @__PURE__ */ jsxRuntimeExports.jsx(P, { children: "You may adjust your browser settings to manage cookies or opt out of targeted advertising through your TikTok account settings." })
] });
export {
  SplitComponent as component
};
